Below is a clean master‐spec you can drop straight into README.md (or replit.md).
It lists every metric the calculator now produces, shows the corrected reimbursement logic, and flags which inputs are user-editable.

MatrixHealth Revenue-Calculator v2  — What It Computes
1 · Clinical / Treatment Math
Variable	Default	Editable?	Formula	Output
Graft area (cm²)	16 cm² (4 × 4)	✅	length × width	16
CMS rate ($/cm²)	$2 500	✅	—	$2 500
Graft value	—	—	area × rate	$40 000
Follow-up dressing fee	$500/wk × 5 wks	✅	—	$2 500
Total billable per patient	—	—	graft value + follow-ups	$42 500

2 · Revenue-Split Engine
(adds to 100 %)

Stakeholder	Share	Formula	Output on $42 500
Distributor (you)	15 %	patient_rev × 0.15	$6 375
Provider	50 %	× 0.50	$21 250
Manufacturer	35 %	× 0.35	$14 875

3 · Dual-Channel Marketing Funnel
(runs in parallel for Digital + OOH; each input editable per channel)

Stage	Digital Default	OOH Default	Formula
Impressions	500 000	250 000	user
Clicks / Responses	CTR 1.2 %	Resp 0.07 %	impr × rate
Leads	0.4 % of clicks	8.5 % of responses	clicks × rate
Appointments	7.5 %	7.5 %	leads × rate
Graftable patients	60 %	55 %	appts × rate
Channel revenue	—	—	patients × 42 500

Cost engine

Variable	Digital	OOH
CPM (editable)	$8.35	$12.00
Spend	(impr ÷ 1 000) × cpm	same

Performance metrics automatically returned

Cost-per-patient (CAC)

ROI: $ return, %, and multiple (e.g., “4.2× / 320 %”)

Patients-per-$1 000 spend

4 · Three Practice Scenarios (pre-loaded templates)
Solo — $7 175/mo budget → 0.7–1.0 pts/mo

Small Group — $21 525/mo → ~3 pts/mo

Hospital System — $65 750/mo → 9–10 pts/mo

(Each template auto-fills impressions & spend and pushes through the funnel.)

5 · Multi-Year Growth Module
Parameter	Default
Monthly growth rate (volume)	5 %
Annual conversion-lift ceiling	3 × baseline
CAC decline	12 %/yr

Outputs:

Year-1, Year-3, Year-5: patients, gross billings, your 15 % revenue

Charts of volume vs CAC vs ROI (optional toggle)

6 · Marketing-Mix Optimiser
Three quick toggles: Digital-Heavy • Balanced • OOH-Heavy
Shows side-by-side: impressions, patients, gross $, CAC, your take.

Error-Checks Built In
Revenue split must sum to 1.0 – throws alert otherwise

CPM ↔ spend ↔ impressions live-linked (edit any one, the other two recalc)

Conversion ceilings to prevent unrealistic Year-5 projections