import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User, Users, Building2, Settings } from "lucide-react";
import { formatCurrency, formatNumber } from "@/lib/utils";

interface DoctorScenariosProps {
  currentScenario: string;
  onScenarioSelect: (scenario: 'solo_practitioner' | 'small_group' | 'hospital_system' | 'custom') => void;
  doctorScenarios: any;
  results?: any; // Add results to calculate anticipated revenue
}

export function DoctorScenarios({ currentScenario, onScenarioSelect, doctorScenarios, results }: DoctorScenariosProps) {
  
  // Calculate anticipated revenue for each scenario
  const calculateAnticipatedRevenue = (scenario: any) => {
    // Basic revenue calculation using Medicare treatment parameters
    const treatmentArea = 4 * 4; // 4x4 cm default
    const treatmentWeeks = 6; // 6 week duration
    const reimbursementPerCm = 2500; // $2,500 per sq cm
    const treatmentRevenue = treatmentArea * reimbursementPerCm; // $40,000 per patient
    
    // Calculate total patients from marketing
    const digitalClicks = (scenario.digitalImpressions * scenario.digitalCtr) / 100;
    const digitalLeads = (digitalClicks * scenario.digitalLeadConv) / 100;
    const digitalAppts = (digitalLeads * scenario.digitalApptConv) / 100;
    const digitalPatients = (digitalAppts * scenario.digitalPatientConv) / 100;
    
    const oohResponses = (scenario.oohImpressions * scenario.oohResponse) / 100;
    const oohLeads = (oohResponses * scenario.oohLeadConv) / 100;
    const oohAppts = (oohLeads * scenario.oohApptConv) / 100;
    const oohPatients = (oohAppts * scenario.oohPatientConv) / 100;
    
    const totalPatients = digitalPatients + oohPatients;
    return totalPatients * treatmentRevenue;
  };
  const scenarios = [
    {
      key: 'solo_practitioner',
      icon: User,
      title: "Solo Practitioner",
      subtitle: "Independent physician practice",
      budget: "Limited budget, focused targeting",
      monthlySpend: doctorScenarios.solo_practitioner.digitalSpendOnImpressions + doctorScenarios.solo_practitioner.oohSpendOnImpressions,
      impressions: doctorScenarios.solo_practitioner.digitalImpressions + doctorScenarios.solo_practitioner.oohImpressions,
      anticipatedRevenue: calculateAnticipatedRevenue(doctorScenarios.solo_practitioner),
      color: "blue"
    },
    {
      key: 'small_group',
      icon: Users,
      title: "Small Group Practice",
      subtitle: "2-5 physicians collaborative practice",
      budget: "Moderate investment, balanced approach",
      monthlySpend: doctorScenarios.small_group.digitalSpendOnImpressions + doctorScenarios.small_group.oohSpendOnImpressions,
      impressions: doctorScenarios.small_group.digitalImpressions + doctorScenarios.small_group.oohImpressions,
      anticipatedRevenue: calculateAnticipatedRevenue(doctorScenarios.small_group),
      color: "purple"
    },
    {
      key: 'hospital_system',
      icon: Building2,
      title: "Hospital System",
      subtitle: "Large healthcare organization",
      budget: "Substantial budget, comprehensive strategy",
      monthlySpend: doctorScenarios.hospital_system.digitalSpendOnImpressions + doctorScenarios.hospital_system.oohSpendOnImpressions,
      impressions: doctorScenarios.hospital_system.digitalImpressions + doctorScenarios.hospital_system.oohImpressions,
      anticipatedRevenue: calculateAnticipatedRevenue(doctorScenarios.hospital_system),
      color: "green"
    },
    {
      key: 'custom',
      icon: Settings,
      title: "Custom Configuration",
      subtitle: "Personalized settings",
      budget: "Tailored to your specific needs",
      monthlySpend: null,
      impressions: null,
      anticipatedRevenue: results?.totalMonthlyRevenue || null,
      color: "gray"
    }
  ];

  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <User className="w-5 h-5 text-primary" />
          <span>Choose Your Practice Type</span>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Select a practice scenario to auto-configure marketing parameters based on typical practice patterns
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {scenarios.map((scenario) => {
            const Icon = scenario.icon;
            const isActive = currentScenario === scenario.key;
            
            return (
              <div
                key={scenario.key}
                className={`relative p-4 rounded-lg border-2 cursor-pointer transition-all hover:shadow-md ${
                  isActive 
                    ? 'border-primary bg-primary/5 shadow-md' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => onScenarioSelect(scenario.key as any)}
                data-testid={`button-scenario-${scenario.key}`}
              >
                {isActive && (
                  <Badge className="absolute -top-2 -right-2 bg-primary text-white">
                    Active
                  </Badge>
                )}
                
                <div className="flex flex-col items-center text-center space-y-3">
                  <Icon className={`w-8 h-8 ${isActive ? 'text-primary' : 'text-gray-500'}`} />
                  
                  <div>
                    <h3 className="font-medium text-gray-900">{scenario.title}</h3>
                    <p className="text-xs text-muted-foreground">{scenario.subtitle}</p>
                  </div>
                  
                  <div className="w-full space-y-2">
                    <p className="text-xs text-gray-600">{scenario.budget}</p>
                    
                    {scenario.monthlySpend && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span>Monthly Spend:</span>
                          <span className="font-mono font-medium">
                            {formatCurrency(scenario.monthlySpend)}
                          </span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span>Total Impressions:</span>
                          <span className="font-mono font-medium">
                            {formatNumber(scenario.impressions)}
                          </span>
                        </div>
                        <div className="flex justify-between text-xs border-t pt-1">
                          <span>Anticipated Revenue:</span>
                          <span className="font-mono font-bold text-success">
                            {formatCurrency(scenario.anticipatedRevenue)}
                          </span>
                        </div>
                      </div>
                    )}
                    
                    {scenario.key === 'custom' && scenario.anticipatedRevenue && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs border-t pt-1">
                          <span>Current Revenue:</span>
                          <span className="font-mono font-bold text-success">
                            {formatCurrency(scenario.anticipatedRevenue)}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <Button
                    size="sm"
                    variant={isActive ? "default" : "outline"}
                    className="w-full"
                    data-testid={`button-select-${scenario.key}`}
                  >
                    {isActive ? "Currently Active" : "Select"}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Practice Type Comparison</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <span className="font-medium text-blue-800">Solo Practitioner:</span>
              <ul className="text-blue-600 mt-1 space-y-1">
                <li>• Lower marketing budgets</li>
                <li>• Higher personal engagement rates</li>
                <li>• Focused local targeting</li>
                <li>• Conservative growth projections</li>
              </ul>
            </div>
            <div>
              <span className="font-medium text-purple-800">Small Group:</span>
              <ul className="text-purple-600 mt-1 space-y-1">
                <li>• Balanced marketing investment</li>
                <li>• Shared patient base</li>
                <li>• Regional market reach</li>
                <li>• Moderate optimization rates</li>
              </ul>
            </div>
            <div>
              <span className="font-medium text-green-800">Hospital System:</span>
              <ul className="text-green-600 mt-1 space-y-1">
                <li>• Large marketing budgets</li>
                <li>• Professional conversion rates</li>
                <li>• Multi-channel strategies</li>
                <li>• Aggressive optimization goals</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}