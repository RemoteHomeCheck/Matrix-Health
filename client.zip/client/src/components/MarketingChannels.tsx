import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Laptop, BadgeDollarSign } from "lucide-react";
import { CalculatorState, CalculatorResults } from "@shared/schema";
import { formatCurrency, formatNumber, formatPercentage, formatLargeNumber } from "@/lib/calculations";

interface MarketingChannelsProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export default function MarketingChannels({ state, results, onUpdate }: MarketingChannelsProps) {
  const handleInputChange = (field: keyof CalculatorState, value: string) => {
    const numValue = parseFloat(value) || 0;
    onUpdate({ [field]: numValue });
  };

  // Dynamic CPM calculations for Digital
  const handleDigitalImpressionsChange = (value: string) => {
    const impressions = parseFloat(value) || 0;
    const cpm = state.digitalCpm || 8.35;
    const spend = (impressions * cpm) / 1000;
    onUpdate({ 
      digitalImpressions: impressions,
      digitalSpendOnImpressions: Math.round(spend * 100) / 100
    });
  };

  const handleDigitalSpendChange = (value: string) => {
    const spend = parseFloat(value) || 0;
    const cpm = state.digitalCpm || 8.35;
    const impressions = (spend * 1000) / cpm;
    onUpdate({ 
      digitalSpendOnImpressions: spend,
      digitalImpressions: Math.round(impressions)
    });
  };

  const handleDigitalCpmChange = (value: string) => {
    const cpm = parseFloat(value) || 8.35;
    const spend = (state.digitalImpressions * cpm) / 1000;
    onUpdate({ 
      digitalCpm: cpm,
      digitalSpendOnImpressions: Math.round(spend * 100) / 100
    });
  };

  // Dynamic CPM calculations for OOH
  const handleOOHImpressionsChange = (value: string) => {
    const impressions = parseFloat(value) || 0;
    const cpm = state.oohCpm || 12.00;
    const spend = (impressions * cpm) / 1000;
    onUpdate({ 
      oohImpressions: impressions,
      oohSpendOnImpressions: Math.round(spend * 100) / 100
    });
  };

  const handleOOHSpendChange = (value: string) => {
    const spend = parseFloat(value) || 0;
    const cpm = state.oohCpm || 12.00;
    const impressions = (spend * 1000) / cpm;
    onUpdate({ 
      oohSpendOnImpressions: spend,
      oohImpressions: Math.round(impressions)
    });
  };

  const handleOOHCpmChange = (value: string) => {
    const cpm = parseFloat(value) || 12.00;
    const spend = (state.oohImpressions * cpm) / 1000;
    onUpdate({ 
      oohCpm: cpm,
      oohSpendOnImpressions: Math.round(spend * 100) / 100
    });
  };

  // Use CPM values from state with fallbacks
  const digitalCPM = state.digitalCpm || 8.35;
  const oohCPM = state.oohCpm || 12.00;

  return (
    <div className="space-y-8">
      {/* Marketing Mix Strategy Explanation */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-blue-600 text-sm font-bold">💡</span>
          </div>
          <div>
            <h3 className="font-semibold text-blue-900 mb-2">Marketing Channels: Manual Control vs. Mix Optimization</h3>
            <p className="text-sm text-blue-800 leading-relaxed mb-3">
              <strong>Use this section</strong> when you want granular control over each channel's parameters, conversion rates, and budget allocation. Perfect for testing specific scenarios or when you have exact data from existing campaigns.
            </p>
            <p className="text-sm text-blue-700 leading-relaxed">
              <strong>Use Mix Optimization</strong> (next tab) for automated budget allocation that maximizes ROI. The optimizer finds the ideal Digital/OOH split based on your total budget and performance goals.
            </p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Digital Marketing Channel */}
        <Card data-testid="digital-marketing-card">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Laptop className="text-primary text-lg" />
                </div>
                <span>Digital Marketing</span>
              </div>
              <Badge variant="secondary" className="bg-primary/10 text-primary">
                Optimized
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Digital Funnel Parameters */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="digital-impressions">
                  Monthly Impressions
                  <span className="text-gray-400 ml-1" title="Digital ad impressions">ⓘ</span>
                </Label>
                <Input
                  id="digital-impressions"
                  type="number"
                  value={state.digitalImpressions}
                  onChange={(e) => handleDigitalImpressionsChange(e.target.value)}
                  data-testid="input-digital-impressions"
                />
              </div>

              <div>
                <Label htmlFor="digital-spend">
                  Spend on Impressions
                  <span className="text-gray-400 ml-1" title="Industry average CPM: TikTok $3.21, Facebook $8.35, Instagram $6.70, X $7.00, LinkedIn $6.37">ⓘ</span>
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                  <Input
                    id="digital-spend"
                    type="number"
                    value={state.digitalSpendOnImpressions}
                    onChange={(e) => handleDigitalSpendChange(e.target.value)}
                    className="pl-8"
                    data-testid="input-digital-spend"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Current CPM: ${digitalCPM.toFixed(2)} (Default: $8.35)
                </p>
              </div>

              <div>
                <Label htmlFor="digital-cpm">
                  CPM (Cost Per 1,000 Impressions)
                  <span className="text-gray-400 ml-1" title="Adjust CPM to see how impression/spend relationship changes">ⓘ</span>
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                  <Input
                    id="digital-cpm"
                    type="number"
                    step="0.01"
                    value={state.digitalCpm}
                    onChange={(e) => handleDigitalCpmChange(e.target.value)}
                    className="pl-8"
                    data-testid="input-digital-cpm"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Changing this updates the impression/spend relationship
                </p>
              </div>

              <div>
                <Label htmlFor="digital-ctr">
                  Click-Through Rate (CTR)
                  <span className="text-gray-400 ml-1" title="Healthcare average: 3.27-5%">ⓘ</span>
                </Label>
                <div className="relative">
                  <Input
                    id="digital-ctr"
                    type="number"
                    step="0.1"
                    value={state.digitalCtr}
                    onChange={(e) => handleInputChange('digitalCtr', e.target.value)}
                    className="pr-8"
                    data-testid="input-digital-ctr"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">Market benchmark: 0.8-1.5% | Ken's original: 0.6%</p>
              </div>

              <div>
                <Label htmlFor="digital-lead-conv">
                  Click-to-Lead Conversion
                  <span className="text-gray-400 ml-1" title="Healthcare average: 5.1-12.33%">ⓘ</span>
                </Label>
                <div className="relative">
                  <Input
                    id="digital-lead-conv"
                    type="number"
                    step="0.1"
                    value={state.digitalLeadConv}
                    onChange={(e) => handleInputChange('digitalLeadConv', e.target.value)}
                    className="pr-8"
                    data-testid="input-digital-lead-conv"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">Market: 8-15% | Ken's actual: ~0.2% | Conservative: 0.4%</p>
              </div>

              <div>
                <Label htmlFor="digital-appt-conv">Lead-to-Appointment Rate</Label>
                <div className="relative">
                  <Input
                    id="digital-appt-conv"
                    type="number"
                    step="0.1"
                    value={state.digitalApptConv}
                    onChange={(e) => handleInputChange('digitalApptConv', e.target.value)}
                    className="pr-8"
                    data-testid="input-digital-appt-conv"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
              </div>

              <div>
                <Label htmlFor="digital-patient-conv">Appointment-to-Patient Rate</Label>
                <div className="relative">
                  <Input
                    id="digital-patient-conv"
                    type="number"
                    step="0.1"
                    value={state.digitalPatientConv}
                    onChange={(e) => handleInputChange('digitalPatientConv', e.target.value)}
                    className="pr-8"
                    data-testid="input-digital-patient-conv"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
              </div>
            </div>

            {/* Digital Results */}
            <div className="bg-blue-50 p-4 rounded-lg" data-testid="digital-results">
              <h4 className="font-medium text-primary mb-3">Digital Channel Results</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Monthly Clicks:</span>
                  <span className="font-mono font-medium" data-testid="text-digital-clicks">
                    {formatNumber(results.digitalClicks)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Monthly Leads:</span>
                  <span className="font-mono font-medium" data-testid="text-digital-leads">
                    {formatNumber(results.digitalLeads)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Monthly Appointments:</span>
                  <span className="font-mono font-medium" data-testid="text-digital-appointments">
                    {formatNumber(results.digitalAppointments)}
                  </span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-sm font-medium">Monthly Patients:</span>
                  <span className="font-mono font-bold text-primary" data-testid="text-digital-patients">
                    {formatNumber(results.digitalPatients)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Monthly Revenue:</span>
                  <span className="font-mono font-bold text-primary" data-testid="text-digital-revenue">
                    {formatCurrency(results.digitalChannelRevenue)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* OOH Marketing Channel */}
        <Card data-testid="ooh-marketing-card">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <BadgeDollarSign className="text-purple-600 text-lg" />
                </div>
                <span>Out-of-Home (OOH)</span>
              </div>
              <Badge variant="secondary" className="bg-purple-100 text-purple-600">
                Traditional
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* OOH Funnel Parameters */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="ooh-impressions">
                  Monthly Impressions
                  <span className="text-gray-400 ml-1" title="BadgeDollarSign/transit ad views">ⓘ</span>
                </Label>
                <Input
                  id="ooh-impressions"
                  type="number"
                  value={state.oohImpressions}
                  onChange={(e) => handleOOHImpressionsChange(e.target.value)}
                  data-testid="input-ooh-impressions"
                />
              </div>

              <div>
                <Label htmlFor="ooh-spend">
                  Spend on Impressions
                  <span className="text-gray-400 ml-1" title="Industry average OOH CPM ranges from $12-$25">ⓘ</span>
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                  <Input
                    id="ooh-spend"
                    type="number"
                    value={state.oohSpendOnImpressions}
                    onChange={(e) => handleOOHSpendChange(e.target.value)}
                    className="pl-8"
                    data-testid="input-ooh-spend"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Current CPM: ${oohCPM.toFixed(2)} (Default: $12.00)
                </p>
              </div>

              <div>
                <Label htmlFor="ooh-cpm">
                  CPM (Cost Per 1,000 Impressions)
                  <span className="text-gray-400 ml-1" title="Adjust CPM to see how impression/spend relationship changes">ⓘ</span>
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                  <Input
                    id="ooh-cpm"
                    type="number"
                    step="0.01"
                    value={state.oohCpm || 12.00}
                    onChange={(e) => handleOOHCpmChange(e.target.value)}
                    className="pl-8"
                    data-testid="input-ooh-cpm"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Changing this updates the impression/spend relationship
                </p>
              </div>

              <div>
                <Label htmlFor="ooh-response">
                  Response Rate
                  <span className="text-gray-400 ml-1" title="OOH typically lower than digital">ⓘ</span>
                </Label>
                <div className="relative">
                  <Input
                    id="ooh-response"
                    type="number"
                    step="0.1"
                    value={state.oohResponse}
                    onChange={(e) => handleInputChange('oohResponse', e.target.value)}
                    className="pr-8"
                    data-testid="input-ooh-response"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">Benchmark: 0.5-1.2% for healthcare OOH</p>
              </div>

              <div>
                <Label htmlFor="ooh-lead-conv">
                  Inquiry-to-Lead Conversion
                  <span className="text-gray-400 ml-1" title="Phone calls to qualified leads">ⓘ</span>
                </Label>
                <div className="relative">
                  <Input
                    id="ooh-lead-conv"
                    type="number"
                    step="0.1"
                    value={state.oohLeadConv}
                    onChange={(e) => handleInputChange('oohLeadConv', e.target.value)}
                    className="pr-8"
                    data-testid="input-ooh-lead-conv"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
              </div>

              <div>
                <Label htmlFor="ooh-appt-conv">Lead-to-Appointment Rate</Label>
                <div className="relative">
                  <Input
                    id="ooh-appt-conv"
                    type="number"
                    step="0.1"
                    value={state.oohApptConv}
                    onChange={(e) => handleInputChange('oohApptConv', e.target.value)}
                    className="pr-8"
                    data-testid="input-ooh-appt-conv"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
              </div>

              <div>
                <Label htmlFor="ooh-patient-conv">Appointment-to-Patient Rate</Label>
                <div className="relative">
                  <Input
                    id="ooh-patient-conv"
                    type="number"
                    step="0.1"
                    value={state.oohPatientConv}
                    onChange={(e) => handleInputChange('oohPatientConv', e.target.value)}
                    className="pr-8"
                    data-testid="input-ooh-patient-conv"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
              </div>
            </div>

            {/* OOH Results */}
            <div className="bg-purple-50 p-4 rounded-lg" data-testid="ooh-results">
              <h4 className="font-medium text-purple-700 mb-3">OOH Channel Results</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Monthly Responses:</span>
                  <span className="font-mono font-medium" data-testid="text-ooh-responses">
                    {formatNumber(results.oohResponses)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Monthly Leads:</span>
                  <span className="font-mono font-medium" data-testid="text-ooh-leads">
                    {formatNumber(results.oohLeads)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Monthly Appointments:</span>
                  <span className="font-mono font-medium" data-testid="text-ooh-appointments">
                    {formatNumber(results.oohAppointments)}
                  </span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-sm font-medium">Monthly Patients:</span>
                  <span className="font-mono font-bold text-purple-700" data-testid="text-ooh-patients">
                    {formatNumber(results.oohPatients)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Monthly Revenue:</span>
                  <span className="font-mono font-bold text-purple-700" data-testid="text-ooh-revenue">
                    {formatCurrency(results.oohChannelRevenue)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Channel Comparison */}
      <Card data-testid="channel-comparison">
        <CardHeader>
          <CardTitle>Channel Performance Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-4">Cost Efficiency</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Digital Spend:</span>
                  <span className="font-mono font-medium">{formatCurrency(state.digitalSpendOnImpressions)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">OOH Spend:</span>
                  <span className="font-mono font-medium">{formatCurrency(state.oohSpendOnImpressions)}</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-sm font-medium">Cost per Patient:</span>
                  <span className="font-mono font-bold text-primary" data-testid="text-digital-cost-per-patient">
                    Digital: {formatCurrency(results.digitalCostPerPatient)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium"></span>
                  <span className="font-mono font-bold text-purple-600" data-testid="text-ooh-cost-per-patient">
                    OOH: {formatCurrency(results.oohCostPerPatient)}
                  </span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-sm font-medium">ROI:</span>
                  <span className="font-mono font-bold text-success" data-testid="text-digital-roi">
                    Digital: {formatPercentage(results.digitalROI)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium"></span>
                  <span className="font-mono font-bold text-success" data-testid="text-ooh-roi">
                    OOH: {formatPercentage(results.oohROI)}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-4">Volume Metrics</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Digital Patients/Mo:</span>
                  <span className="font-mono font-medium" data-testid="text-volume-digital">
                    {formatNumber(results.digitalPatients)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">OOH Patients/Mo:</span>
                  <span className="font-mono font-medium" data-testid="text-volume-ooh">
                    {formatNumber(results.oohPatients)}
                  </span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-sm font-medium">Total Patients/Mo:</span>
                  <span className="font-mono font-bold" data-testid="text-total-patients">
                    {formatNumber(results.totalPatients)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Combined Revenue/Mo:</span>
                  <span className="font-mono font-bold" data-testid="text-total-revenue">
                    {formatCurrency(results.totalMonthlyRevenue)}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-yellow-50 to-green-50 p-6 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-4">ROI Analysis</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Digital ROI:</span>
                  <span className="font-mono font-medium text-success" data-testid="text-digital-roi">
                    {formatPercentage(results.digitalROI)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">OOH ROI:</span>
                  <span className="font-mono font-medium text-success" data-testid="text-ooh-roi">
                    {formatPercentage(results.oohROI)}
                  </span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-sm font-medium">Blended ROI:</span>
                  <span className="font-mono font-bold text-success" data-testid="text-blended-roi">
                    {formatPercentage(results.blendedROI)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Payback Period:</span>
                  <span className="font-mono font-bold">0.8 days</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
