import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { RefreshCw, TrendingUp, DollarSign, Target } from "lucide-react";
import { CalculatorState, CalculatorResults } from "@shared/schema";
import { formatCurrency, formatNumber, formatPercentage, formatLargeNumber, formatROI } from "@/lib/calculations";

interface MixOptimizationProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export default function MixOptimization({ state, results, onUpdate }: MixOptimizationProps) {
  const handleInputChange = (field: keyof CalculatorState, value: string) => {
    const numValue = parseFloat(value) || 0;
    onUpdate({ [field]: numValue });
  };

  const handleSliderChange = (field: keyof CalculatorState, value: number[]) => {
    onUpdate({ [field]: value[0] });
  };

  const calculateScenarios = () => {
    // Digital-Heavy Strategy (85% digital allocation)
    const digitalHeavyPatients = Math.round(results.totalPatients * 1.1); // 10% boost from digital focus
    const digitalHeavyRevenue = digitalHeavyPatients * results.patientRevenue;
    const digitalHeavyDistributor = digitalHeavyRevenue * (state.distributorShare / 100);

    // Balanced Strategy (50/50 allocation)
    const balancedPatients = Math.round(results.totalPatients * 0.9); // Slight reduction from not optimizing
    const balancedRevenue = balancedPatients * results.patientRevenue;
    const balancedDistributor = balancedRevenue * (state.distributorShare / 100);

    // OOH-Heavy Strategy (75% OOH allocation)
    const oohHeavyPatients = Math.round(results.totalPatients * 0.8); // Lower efficiency
    const oohHeavyRevenue = oohHeavyPatients * results.patientRevenue;
    const oohHeavyDistributor = oohHeavyRevenue * (state.distributorShare / 100);

    return {
      digitalHeavy: { patients: digitalHeavyPatients, revenue: digitalHeavyRevenue, distributor: digitalHeavyDistributor },
      balanced: { patients: balancedPatients, revenue: balancedRevenue, distributor: balancedDistributor },
      oohHeavy: { patients: oohHeavyPatients, revenue: oohHeavyRevenue, distributor: oohHeavyDistributor }
    };
  };

  const scenarios = calculateScenarios();
  const digitalAllocationAmount = (state.totalBudget * state.digitalAllocation) / 100;
  const oohAllocationAmount = state.totalBudget - digitalAllocationAmount;
  const optimizedCostPerPatient = state.totalBudget / results.totalPatients;
  const optimizedROI = results.totalMonthlyRevenue > 0 ? ((results.totalMonthlyRevenue - state.totalBudget) / state.totalBudget) * 100 : 0;

  return (
    <div className="space-y-8">
      {/* Budget Allocation Optimizer */}
      <Card data-testid="budget-allocation-optimizer">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span>Marketing Mix Optimization</span>
              <span 
                className="text-gray-400 cursor-help" 
                title="Use this tool when you have a total budget and want to find the optimal allocation between Digital and OOH marketing. Perfect for strategic planning and maximizing ROI automatically."
              >
                ⓘ
              </span>
            </div>
            <Button variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Recalculate
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Budget Sliders */}
            <div className="space-y-6">
              <h4 className="font-medium text-gray-900">Budget Allocation</h4>
              
              {/* Total Budget */}
              <div>
                <Label htmlFor="total-budget">Total Monthly Budget</Label>
                <div className="relative mt-1">
                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                  <Input
                    id="total-budget"
                    type="number"
                    value={state.totalBudget}
                    onChange={(e) => handleInputChange('totalBudget', e.target.value)}
                    className="pl-8"
                    data-testid="input-total-budget"
                  />
                </div>
              </div>

              {/* Digital Allocation */}
              <div>
                <div className="flex justify-between mb-2">
                  <Label>Digital Marketing</Label>
                  <span className="text-sm text-primary font-medium" data-testid="text-digital-allocation-percent">
                    {state.digitalAllocation}%
                  </span>
                </div>
                <Slider
                  value={[state.digitalAllocation]}
                  onValueChange={(value) => handleSliderChange('digitalAllocation', value)}
                  max={100}
                  step={5}
                  className="w-full"
                  data-testid="slider-digital-allocation"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>$0</span>
                  <span data-testid="text-digital-allocation-amount">
                    {formatCurrency(digitalAllocationAmount)}
                  </span>
                </div>
              </div>

              {/* OOH Allocation */}
              <div>
                <div className="flex justify-between mb-2">
                  <Label>Out-of-Home Marketing</Label>
                  <span className="text-sm text-purple-600 font-medium" data-testid="text-ooh-allocation-percent">
                    {100 - state.digitalAllocation}%
                  </span>
                </div>
                <Slider
                  value={[100 - state.digitalAllocation]}
                  onValueChange={(value) => handleSliderChange('digitalAllocation', [100 - value[0]])}
                  max={100}
                  step={5}
                  className="w-full slider-purple"
                  data-testid="slider-ooh-allocation"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>$0</span>
                  <span data-testid="text-ooh-allocation-amount">
                    {formatCurrency(oohAllocationAmount)}
                  </span>
                </div>
              </div>
            </div>

            {/* Allocation Results */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-4">Optimized Results</h4>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm">Total Patients/Month:</span>
                  <span className="font-mono font-bold text-primary" data-testid="text-optimized-total-patients">
                    {formatNumber(results.totalPatients)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Cost per Patient:</span>
                  <span className="font-mono font-medium" data-testid="text-optimized-cost-per-patient">
                    {formatCurrency(optimizedCostPerPatient)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Monthly Revenue:</span>
                  <span className="font-mono font-bold text-secondary" data-testid="text-optimized-monthly-revenue">
                    {formatCurrency(results.totalMonthlyRevenue)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">ROI:</span>
                  <span className="font-mono font-bold text-success" data-testid="text-optimized-roi">
                    {formatPercentage(optimizedROI)}
                  </span>
                </div>
                <div className="flex justify-between pt-3 border-t">
                  <span className="text-sm font-medium">Distributor Revenue:</span>
                  <span className="font-mono font-bold text-accent" data-testid="text-optimized-distributor-revenue">
                    {formatCurrency(results.totalDistributorRevenue)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Physician Revenue:</span>
                  <span className="font-mono font-bold text-teal-600" data-testid="text-optimized-physician-revenue">
                    {formatCurrency(results.doctorRevenue)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Mfr Revenue:</span>
                  <span className="font-mono font-bold text-orange-600" data-testid="text-optimized-manufacturer-revenue">
                    {formatCurrency(results.manufacturerRevenue)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Scenario Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card data-testid="digital-heavy-scenario">
          <CardHeader>
            <CardTitle className="text-lg">Digital-Heavy Strategy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="bg-blue-50 p-3 rounded text-center">
              <div className="text-2xl font-bold text-primary">85%</div>
              <div className="text-sm text-blue-600">Digital Allocation</div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Patients/Mo:</span>
                <span className="font-mono" data-testid="text-digital-heavy-patients">
                  {formatNumber(scenarios.digitalHeavy.patients)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Revenue/Mo:</span>
                <span className="font-mono" data-testid="text-digital-heavy-revenue">
                  {formatCurrency(scenarios.digitalHeavy.revenue)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Distributor:</span>
                <span className="font-mono text-success" data-testid="text-digital-heavy-distributor">
                  {formatCurrency(scenarios.digitalHeavy.distributor)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="balanced-scenario">
          <CardHeader>
            <CardTitle className="text-lg">Balanced Strategy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="bg-green-50 p-3 rounded text-center">
              <div className="text-2xl font-bold text-secondary">50/50</div>
              <div className="text-sm text-green-600">Even Split</div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Patients/Mo:</span>
                <span className="font-mono" data-testid="text-balanced-patients">
                  {formatNumber(scenarios.balanced.patients)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Revenue/Mo:</span>
                <span className="font-mono" data-testid="text-balanced-revenue">
                  {formatCurrency(scenarios.balanced.revenue)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Distributor:</span>
                <span className="font-mono text-success" data-testid="text-balanced-distributor">
                  {formatCurrency(scenarios.balanced.distributor)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="ooh-heavy-scenario">
          <CardHeader>
            <CardTitle className="text-lg">OOH-Heavy Strategy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="bg-purple-50 p-3 rounded text-center">
              <div className="text-2xl font-bold text-purple-600">75%</div>
              <div className="text-sm text-purple-600">OOH Allocation</div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Patients/Mo:</span>
                <span className="font-mono" data-testid="text-ooh-heavy-patients">
                  {formatNumber(scenarios.oohHeavy.patients)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Revenue/Mo:</span>
                <span className="font-mono" data-testid="text-ooh-heavy-revenue">
                  {formatCurrency(scenarios.oohHeavy.revenue)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Distributor:</span>
                <span className="font-mono text-success" data-testid="text-ooh-heavy-distributor">
                  {formatCurrency(scenarios.oohHeavy.distributor)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Advanced Optimization Insights */}
      <Card data-testid="advanced-optimization-insights">
        <CardHeader>
          <CardTitle>Advanced Optimization Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Seasonal Adjustments */}
            <div>
              <h4 className="font-medium text-gray-900 mb-4">Seasonal Budget Adjustments</h4>
              <div className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Target className="w-4 h-4 text-primary mr-2" />
                    <h5 className="font-medium text-primary">Q1 Strategy (Jan-Mar)</h5>
                  </div>
                  <p className="text-sm text-blue-600 mb-2">Post-holiday optimization period</p>
                  <div className="text-sm">
                    <div>Digital: 80% allocation (+10%)</div>
                    <div>Expected lift: +15% patients</div>
                  </div>
                </div>
                
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <TrendingUp className="w-4 h-4 text-yellow-700 mr-2" />
                    <h5 className="font-medium text-yellow-700">Q4 Strategy (Oct-Dec)</h5>
                  </div>
                  <p className="text-sm text-yellow-600 mb-2">Holiday season competition</p>
                  <div className="text-sm">
                    <div>OOH: 60% allocation (+30%)</div>
                    <div>Expected impact: +8% brand awareness</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Geographic Optimization */}
            <div>
              <h4 className="font-medium text-gray-900 mb-4">Geographic Optimization</h4>
              <div className="space-y-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <DollarSign className="w-4 h-4 text-secondary mr-2" />
                    <h5 className="font-medium text-secondary">High-Density Markets</h5>
                  </div>
                  <p className="text-sm text-green-600 mb-2">Urban areas with high Medicare population</p>
                  <div className="text-sm">
                    <div>Digital focus: Precision targeting</div>
                    <div>Expected conversion: +25%</div>
                  </div>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Target className="w-4 h-4 text-purple-700 mr-2" />
                    <h5 className="font-medium text-purple-700">Rural Markets</h5>
                  </div>
                  <p className="text-sm text-purple-600 mb-2">Lower digital adoption areas</p>
                  <div className="text-sm">
                    <div>OOH focus: Traditional media</div>
                    <div>Expected reach: +40% awareness</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
