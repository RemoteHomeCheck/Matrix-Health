import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertTriangle, TrendingUp, Target, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { CalculatorState, CalculatorResults } from "@shared/schema";
import { formatCurrency, formatNumber, formatPercentage, formatLargeNumber } from "@/lib/calculations";
import { formatROI, formatPayback } from "@/lib/formatters";

interface MultiYearProjectionsProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export default function MultiYearProjections({ state, results, onUpdate }: MultiYearProjectionsProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<1 | 3 | 5>(1);

  const handleInputChange = (field: keyof CalculatorState, value: string) => {
    const numValue = parseFloat(value) || 0;
    onUpdate({ [field]: numValue });
  };

  const generateMonthlyBreakdown = () => {
    const months = [];
    const basePatients = results.totalPatients || 0;
    const patientRevenue = results.patientRevenue || 0; // Use correct field name
    
    // Handle NaN/zero cases gracefully
    if (!basePatients || !patientRevenue) {
      return Array.from({ length: 12 }, (_, i) => ({
        name: new Date(2024, i).toLocaleDateString('en-US', { month: 'short' }),
        patients: 0,
        revenue: 0,
        distributor: 0,
        manufacturer: 0,
        provider: 0,
        reimbursement: 0
      }));
    }
    
    for (let month = 1; month <= 12; month++) {
      const growthFactor = Math.pow(1 + (state.growthYear1 / 100), month);
      const patients = Math.round(basePatients * growthFactor);
      const revenue = patients * patientRevenue;
      const distributorShare = revenue * (state.distributorShare / 100);
      const manufacturerShare = revenue * (state.manufacturerShare / 100);
      const providerShare = revenue * (state.providerShare / 100);
      const patientReimbursement = patients * patientRevenue;
      
      months.push({
        name: new Date(2024, month - 1).toLocaleDateString('en-US', { month: 'short' }),
        patients,
        revenue,
        distributor: distributorShare,
        manufacturer: manufacturerShare,
        provider: providerShare,
        reimbursement: patientReimbursement
      });
    }
    return months;
  };

  const monthlyData = generateMonthlyBreakdown();

  return (
    <div className="space-y-8">
      {/* Time Period Selector and Growth Assumptions */}
      <Card data-testid="projections-header">
        <CardHeader>
          <CardTitle>Multi-Year Revenue Projections</CardTitle>
        </CardHeader>
        <CardContent>
          <TooltipProvider>
            {/* Growth Assumptions */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <h4 className="font-medium text-primary">Year 1 Growth</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-blue-600 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">Monthly patient acquisition growth rate during the first year as your marketing campaigns gain momentum and optimize.</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Growth Rate:</span>
                  <div className="flex items-center space-x-1">
                    <Input
                      type="number"
                      step="0.1"
                      value={state.growthYear1}
                      onChange={(e) => handleInputChange('growthYear1', e.target.value)}
                      className="w-16 text-sm px-2 py-1"
                      data-testid="input-growth-year1"
                    />
                    <span className="text-sm">%/mo</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Market Phase:</span>
                  <span className="text-sm font-medium">Initial</span>
                </div>
              </div>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <h4 className="font-medium text-purple-700">Conversion Optimization</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-purple-600 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">Annual improvement in conversion rates as campaigns optimize, A/B tests improve, and targeting becomes more precise.</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Annual Improvement:</span>
                  <div className="flex items-center space-x-1">
                    <Input
                      type="number"
                      step="1"
                      value={state.conversionOptimization}
                      onChange={(e) => handleInputChange('conversionOptimization', e.target.value)}
                      className="w-16 text-sm px-2 py-1"
                      data-testid="input-conversion-optimization"
                    />
                    <span className="text-sm">%/yr</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Campaign Maturity:</span>
                  <span className="text-sm font-medium">Learning</span>
                </div>
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <h4 className="font-medium text-secondary">CAC Improvement</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-green-600 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">Annual reduction in Customer Acquisition Cost (CAC) through improved targeting, campaign optimization, and economies of scale.</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Annual Reduction:</span>
                  <div className="flex items-center space-x-1">
                    <Input
                      type="number"
                      step="1"
                      value={state.cacImprovementRate}
                      onChange={(e) => handleInputChange('cacImprovementRate', e.target.value)}
                      className="w-16 text-sm px-2 py-1"
                      data-testid="input-cac-improvement"
                    />
                    <span className="text-sm">%/yr</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Cost Efficiency:</span>
                  <span className="text-sm font-medium">Improving</span>
                </div>
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <h4 className="font-medium text-secondary">Year 2-3 Assumptions</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-green-600 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">Steady-state growth rate for years 2-3 when market presence is established and campaigns are fully optimized.</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Growth Rate:</span>
                  <div className="flex items-center space-x-1">
                    <Input
                      type="number"
                      step="0.1"
                      value={state.growthYear23}
                      onChange={(e) => handleInputChange('growthYear23', e.target.value)}
                      className="w-16 text-sm px-2 py-1"
                      data-testid="input-growth-year23"
                    />
                    <span className="text-sm">%/mo</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Market Phase:</span>
                  <span className="text-sm font-medium">Steady</span>
                </div>
              </div>
            </div>
            
            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <h4 className="font-medium text-accent">Year 4-5 Assumptions</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-orange-600 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">Mature market growth rate for years 4-5 when market penetration slows and focus shifts to retention and efficiency.</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Growth Rate:</span>
                  <div className="flex items-center space-x-1">
                    <Input
                      type="number"
                      step="0.1"
                      value={state.growthYear45}
                      onChange={(e) => handleInputChange('growthYear45', e.target.value)}
                      className="w-16 text-sm px-2 py-1"
                      data-testid="input-growth-year45"
                    />
                    <span className="text-sm">%/mo</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Market Phase:</span>
                  <span className="text-sm font-medium">Mature</span>
                </div>
              </div>
            </div>
          </div>
          </TooltipProvider>
        </CardContent>
      </Card>

      {/* Projection Results */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Dynamic Content Based on Selected Period */}
        <Card data-testid="projection-breakdown" className="overflow-hidden">
          <CardHeader>
            <CardTitle className="flex items-center justify-between text-lg">
              <span>
                {selectedPeriod === 1 && "Year 1 Monthly Breakdown"}
                {selectedPeriod === 3 && "3-Year Quarterly Breakdown"}  
                {selectedPeriod === 5 && "5-Year Annual Breakdown"}
              </span>
              <div className="flex space-x-2">
                {[1, 3, 5].map((period) => (
                  <Button
                    key={period}
                    variant={selectedPeriod === period ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedPeriod(period as 1 | 3 | 5)}
                    data-testid={`button-breakdown-period-${period}`}
                  >
                    {period} Year{period > 1 ? 's' : ''}
                  </Button>
                ))}
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {selectedPeriod === 1 && (
              <>
                <div className="overflow-x-auto border rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200 text-xs">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-1 py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{minWidth: '50px'}}>
                          Month
                        </th>
                        <th className="px-1 py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{minWidth: '60px'}}>
                          Patients
                        </th>
                        <th className="px-1 py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{minWidth: '80px'}}>
                          Revenue
                        </th>
                        <th className="px-1 py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{minWidth: '70px'}}>
                          Distributor
                        </th>
                        <th className="px-1 py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{minWidth: '80px'}}>
                          Manufacturer
                        </th>
                        <th className="px-1 py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{minWidth: '70px'}}>
                          Provider
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {monthlyData.map((month, index) => (
                        <tr key={month.name} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-25'}>
                          <td className="px-1 py-2 whitespace-nowrap text-xs font-medium text-gray-900">
                            {month.name}
                          </td>
                          <td className="px-1 py-2 whitespace-nowrap text-xs text-gray-900 text-right">
                            {formatNumber(month.patients)}
                          </td>
                          <td className="px-1 py-2 whitespace-nowrap text-xs text-gray-900 text-right font-mono">
                            {formatCurrency(month.revenue)}
                          </td>
                          <td className="px-1 py-2 whitespace-nowrap text-xs text-success text-right font-mono">
                            {formatCurrency(month.distributor)}
                          </td>
                          <td className="px-1 py-2 whitespace-nowrap text-xs text-orange-600 text-right font-mono">
                            {formatCurrency(month.manufacturer)}
                          </td>
                          <td className="px-1 py-2 whitespace-nowrap text-xs text-teal-600 text-right font-mono">
                            {formatCurrency(month.provider)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {/* Revenue Summary Cards Below Table */}
                <div className="p-4 bg-gray-50 border-t">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                    <div className="bg-white p-3 rounded shadow-sm">
                      <div className="font-semibold text-gray-900">
                        {formatCurrency(results.year1Revenue)}
                      </div>
                      <div className="text-xs text-gray-600">Total Revenue</div>
                    </div>
                    <div className="bg-green-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-green-600">
                        {formatCurrency(results.year1Revenue * (state.distributorShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Distributor Share</div>
                    </div>
                    <div className="bg-orange-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-orange-600">
                        {formatCurrency(results.year1Revenue * (state.manufacturerShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Manufacturer Share</div>
                    </div>
                    <div className="bg-teal-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-teal-600">
                        {formatCurrency(results.year1Revenue * (state.providerShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Provider Share</div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-primary">Year 1 Totals:</span>
                      <div className="text-right">
                        <div className="font-bold text-primary" data-testid="text-year1-total-revenue">
                          {formatCurrency(results.year1Revenue)} Total Revenue
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 md:grid-cols-6 gap-4 text-sm">
                      <div className="text-center">
                        <div className="font-semibold text-green-600" data-testid="text-year1-distributor-total">
                          {formatCurrency(results.year1Revenue * (state.distributorShare / 100))}
                        </div>
                        <div className="text-xs text-gray-600">Distributor</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-orange-600">
                          {formatCurrency(results.year1Revenue * (state.manufacturerShare / 100))}
                        </div>
                        <div className="text-xs text-gray-600">Manufacturer</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-teal-600">
                          {formatCurrency(results.year1Revenue * (state.providerShare / 100))}
                        </div>
                        <div className="text-xs text-gray-600">Provider</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-blue-600">
                          {formatCurrency(results.year1Patients * results.patientTreatmentReimbursement)}
                        </div>
                        <div className="text-xs text-gray-600">Patient Treatment Reimbursement</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-blue-600">
                          {results.blendedROI !== null ? formatROI(results.blendedROI) : "N/A"}
                        </div>
                        <div className="text-xs text-gray-600">Blended ROI</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-purple-600">
                          {results.blendedPaybackMonths !== null ? formatPayback(results.blendedPaybackMonths) : "N/A"}
                        </div>
                        <div className="text-xs text-gray-600">Payback Period</div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
            
            {selectedPeriod === 3 && (
              <>
                <div className="overflow-x-auto border rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200 text-xs">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase">Year</th>
                        <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quarter</th>
                        <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase">Patients</th>
                        <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase">Revenue</th>
                        <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase">Distributor</th>
                        <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase">Mfr</th>
                        <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase">Provider</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {[1, 2, 3].map(year => [1, 2, 3, 4].map(quarter => {
                        const basePatients = results.year1Patients * Math.pow(1 + (state.growthYear23 / 100), (year - 1) * 12 + (quarter - 1) * 3);
                        const quarterPatients = Math.round(basePatients / 4);
                        const quarterRevenue = quarterPatients * results.patientTreatmentReimbursement;
                        const isEvenRow = ((year - 1) * 4 + quarter - 1) % 2 === 0;
                        
                        return (
                          <tr key={`${year}-${quarter}`} className={isEvenRow ? 'bg-white' : 'bg-gray-25'}>
                            <td className="px-2 py-2 whitespace-nowrap text-xs font-medium text-gray-900">
                              Year {year}
                            </td>
                            <td className="px-2 py-2 whitespace-nowrap text-xs text-gray-600">
                              Q{quarter}
                            </td>
                            <td className="px-2 py-2 whitespace-nowrap text-xs text-gray-900 text-right">
                              {formatNumber(quarterPatients)}
                            </td>
                            <td className="px-2 py-2 whitespace-nowrap text-xs text-gray-900 text-right font-mono">
                              {formatCurrency(quarterRevenue)}
                            </td>
                            <td className="px-2 py-2 whitespace-nowrap text-xs text-success text-right font-mono">
                              {formatCurrency(quarterRevenue * (state.distributorShare / 100))}
                            </td>
                            <td className="px-2 py-2 whitespace-nowrap text-xs text-orange-600 text-right font-mono">
                              {formatCurrency(quarterRevenue * (state.manufacturerShare / 100))}
                            </td>
                            <td className="px-2 py-2 whitespace-nowrap text-xs text-teal-600 text-right font-mono">
                              {formatCurrency(quarterRevenue * (state.providerShare / 100))}
                            </td>
                          </tr>
                        );
                      })).flat()}
                    </tbody>
                  </table>
                </div>
                
                <div className="p-4 bg-gray-50 border-t">
                  <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 text-sm">
                    <div className="bg-white p-3 rounded shadow-sm">
                      <div className="font-semibold text-gray-900">
                        {formatCurrency(results.year3Revenue)}
                      </div>
                      <div className="text-xs text-gray-600">3-Year Total Revenue</div>
                    </div>
                    <div className="bg-green-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-green-600">
                        {formatCurrency(results.year3Revenue * (state.distributorShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Distributor Share</div>
                    </div>
                    <div className="bg-orange-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-orange-600">
                        {formatCurrency(results.year3Revenue * (state.manufacturerShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Mfr Share</div>
                    </div>
                    <div className="bg-teal-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-teal-600">
                        {formatCurrency(results.year3Revenue * (state.providerShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Provider Share</div>
                    </div>
                    <div className="bg-blue-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-blue-600">
                        {formatNumber(results.year3Patients)}
                      </div>
                      <div className="text-xs text-gray-600">Total Patients</div>
                    </div>
                  </div>
                </div>
              </>
            )}
            
            {selectedPeriod === 5 && (
              <>
                <div className="overflow-x-auto border rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200 text-xs">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase">Year</th>
                        <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase">Patients</th>
                        <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase">Revenue</th>
                        <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase">Distributor</th>
                        <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase">Mfr</th>
                        <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase">Provider</th>
                        <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase">Growth Rate</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {[1, 2, 3, 4, 5].map((year, index) => {
                        let yearPatients;
                        let growthRate;
                        
                        if (year === 1) {
                          yearPatients = results.year1Patients;
                          growthRate = state.growthYear1;
                        } else if (year <= 3) {
                          yearPatients = results.year1Patients * Math.pow(1 + (state.growthYear23 / 100), (year - 1) * 12);
                          growthRate = state.growthYear23;
                        } else {
                          yearPatients = results.year1Patients * Math.pow(1 + (state.growthYear23 / 100), 24) * Math.pow(1 + (state.growthYear45 / 100), (year - 3) * 12);
                          growthRate = state.growthYear45;
                        }
                        
                        const yearRevenue = yearPatients * results.patientTreatmentReimbursement;
                        const isEvenRow = index % 2 === 0;
                        
                        return (
                          <tr key={year} className={isEvenRow ? 'bg-white' : 'bg-gray-25'}>
                            <td className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                              Year {year}
                            </td>
                            <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-900 text-right">
                              {formatNumber(Math.round(yearPatients))}
                            </td>
                            <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                              {formatCurrency(yearRevenue)}
                            </td>
                            <td className="px-3 py-3 whitespace-nowrap text-sm text-success text-right font-mono">
                              {formatCurrency(yearRevenue * (state.distributorShare / 100))}
                            </td>
                            <td className="px-3 py-3 whitespace-nowrap text-sm text-orange-600 text-right font-mono">
                              {formatCurrency(yearRevenue * (state.manufacturerShare / 100))}
                            </td>
                            <td className="px-3 py-3 whitespace-nowrap text-sm text-teal-600 text-right font-mono">
                              {formatCurrency(yearRevenue * (state.providerShare / 100))}
                            </td>
                            <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-600 text-right">
                              {growthRate}%/mo
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                
                <div className="p-4 bg-gray-50 border-t">
                  <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 text-sm">
                    <div className="bg-white p-3 rounded shadow-sm">
                      <div className="font-semibold text-gray-900">
                        {formatCurrency(results.year5Revenue)}
                      </div>
                      <div className="text-xs text-gray-600">5-Year Total Revenue</div>
                    </div>
                    <div className="bg-green-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-green-600">
                        {formatCurrency(results.year5Revenue * (state.distributorShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Distributor Share</div>
                    </div>
                    <div className="bg-orange-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-orange-600">
                        {formatCurrency(results.year5Revenue * (state.manufacturerShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Mfr Share</div>
                    </div>
                    <div className="bg-teal-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-teal-600">
                        {formatCurrency(results.year5Revenue * (state.providerShare / 100))}
                      </div>
                      <div className="text-xs text-gray-600">Provider Share</div>
                    </div>
                    <div className="bg-blue-50 p-3 rounded shadow-sm">
                      <div className="font-semibold text-blue-600">
                        {formatNumber(results.year5Patients)}
                      </div>
                      <div className="text-xs text-gray-600">Total Patients</div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Multi-Year Summary */}
        <Card data-testid="multiyear-summary">
          <CardHeader>
            <CardTitle>Long-Term Projections</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* 3-Year Projection */}
            <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-4">3-Year Forecast</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Total Patients</p>
                  <p className="text-xl font-bold text-primary" data-testid="text-year3-patients">
                    {formatNumber(results.year3Patients)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Gross Revenue</p>
                  <p className="text-xl font-bold text-primary" data-testid="text-year3-revenue">
                    {formatCurrency(results.year3Revenue)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Distributor Share</p>
                  <p className="text-xl font-bold text-green-600" data-testid="text-year3-distributor">
                    {formatCurrency(results.year3Revenue * (state.distributorShare / 100))}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Provider Share</p>
                  <p className="text-xl font-bold text-teal-600" data-testid="text-year3-provider">
                    {formatCurrency(results.year3Revenue * (state.providerShare / 100))}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Manufacturer Share</p>
                  <p className="text-xl font-bold text-orange-600" data-testid="text-year3-manufacturer">
                    {formatCurrency(results.year3Revenue * (state.manufacturerShare / 100))}
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-sm text-gray-600">Monthly Run Rate</p>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="h-4 w-4 text-blue-600 cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs">Average monthly revenue calculated by dividing the total 3-year revenue by 36 months. This shows your sustainable monthly income stream from wound care treatments.</p>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <p className="text-xl font-bold text-accent" data-testid="text-year3-monthly">
                    {formatCurrency(results.year3Revenue / 36)}
                  </p>
                </div>
              </div>
            </div>

            {/* 5-Year Projection */}
            <div className="bg-gradient-to-r from-green-50 to-yellow-50 p-6 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-4">5-Year Forecast</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Total Patients</p>
                  <p className="text-xl font-bold text-primary" data-testid="text-year5-patients">
                    {formatNumber(results.year5Patients)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Gross Revenue</p>
                  <p className="text-xl font-bold text-primary" data-testid="text-year5-revenue">
                    {formatCurrency(results.year5Revenue)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Distributor Share</p>
                  <p className="text-xl font-bold text-green-600" data-testid="text-year5-distributor">
                    {formatCurrency(results.year5Revenue * (state.distributorShare / 100))}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Provider Share</p>
                  <p className="text-xl font-bold text-teal-600" data-testid="text-year5-provider">
                    {formatCurrency(results.year5Revenue * (state.providerShare / 100))}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Manufacturer Share</p>
                  <p className="text-xl font-bold text-orange-600" data-testid="text-year5-manufacturer">
                    {formatCurrency(results.year5Revenue * (state.manufacturerShare / 100))}
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-sm text-gray-600">Market Penetration</p>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="h-4 w-4 text-blue-600 cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs">Percentage of addressable chronic wound patients captured in your target market. Based on clinical research: chronic wounds affect 2.5% of US population, with 30% being treatment-appropriate cases requiring advanced wound care like dermal patch grafts.</p>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <p className="text-xl font-bold text-accent" data-testid="text-year5-penetration">
                    12.3%
                  </p>
                </div>
              </div>
            </div>

            {/* Optimization Impact Analysis */}
            <div className="bg-yellow-50 p-6 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <h4 className="font-medium text-warning">Campaign Optimization Impact</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-yellow-700 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="max-w-sm space-y-2">
                      <p className="font-semibold">Customer Acquisition Cost (CAC)</p>
                      <p>Total marketing spend divided by new patients acquired. Shows how much it costs to get each new patient.</p>
                      <div className="border-t pt-2">
                        <p className="font-medium text-green-600">Good CAC (Healthcare):</p>
                        <p className="text-sm">Under $500-800 per patient for wound care treatments with high lifetime value</p>
                      </div>
                      <div>
                        <p className="font-medium text-red-600">Poor CAC:</p>
                        <p className="text-sm">Over $1,500 per patient - unsustainable economics that reduce profitability</p>
                      </div>
                      <p className="text-xs text-gray-600 border-t pt-2">CAC improves over time through campaign optimization, better targeting, and increased conversion rates.</p>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Year 1 CAC:</span>
                  <span className="font-mono font-medium">
                    {results.digitalCostPerPatient !== null ? formatCurrency(results.digitalCostPerPatient) : "N/A"} per patient
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Year 3 CAC (optimized):</span>
                  <span className="font-mono font-medium text-success">
                    {results.digitalCostPerPatient !== null ? formatCurrency(results.digitalCostPerPatient * Math.pow(1 - (state.cacImprovementRate / 100), 3)) : "N/A"} per patient
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Year 5 CAC (optimized):</span>
                  <span className="font-mono font-medium text-success">
                    {results.digitalCostPerPatient !== null ? formatCurrency(results.digitalCostPerPatient * Math.pow(1 - (state.cacImprovementRate / 100), 5)) : "N/A"} per patient
                  </span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-sm font-medium">Total CAC Savings (5-year):</span>
                  <span className="font-mono font-bold text-secondary">
                    {results.digitalCostPerPatient !== null ? formatCurrency((results.digitalCostPerPatient - results.digitalCostPerPatient * Math.pow(1 - (state.cacImprovementRate / 100), 5)) * results.year5Patients) : "N/A"}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Market Capacity Analysis */}
      <Card data-testid="market-capacity-analysis">
        <CardHeader>
          <CardTitle>Market Capacity & Scaling Considerations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-red-50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <AlertTriangle className="w-5 h-5 text-red-700 mr-2" />
                <h4 className="font-medium text-red-700">Capacity Constraints</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-red-600 cursor-help ml-2" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="max-w-xs space-y-1">
                      <p className="font-semibold">Market Limitations</p>
                      <p className="text-sm">Physical and regulatory barriers that limit how fast you can scale your wound care practice:</p>
                      <ul className="text-xs space-y-1 list-disc list-inside">
                        <li>Provider network: Limited certified wound specialists</li>
                        <li>Patient saturation: Finite pool of chronic wound patients per region</li>
                        <li>Geographic limits: Travel distance affects patient access</li>
                        <li>Regulatory capacity: Compliance requirements slow expansion</li>
                      </ul>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </div>
              <ul className="text-sm text-red-600 space-y-2">
                <li>• Provider network scale</li>
                <li>• Patient acquisition saturation</li>
                <li>• Geographic market limits</li>
                <li>• Regulatory capacity</li>
              </ul>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <Target className="w-5 h-5 text-yellow-700 mr-2" />
                <h4 className="font-medium text-yellow-700">Scaling Requirements</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-yellow-600 cursor-help ml-2" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="max-w-xs space-y-1">
                      <p className="font-semibold">Infrastructure Needs</p>
                      <p className="text-sm">Essential systems required to support rapid growth and maintain quality care:</p>
                      <ul className="text-xs space-y-1 list-disc list-inside">
                        <li>AI platform: Automated patient matching and treatment protocols</li>
                        <li>Provider onboarding: Training systems for new practitioners</li>
                        <li>Compliance infrastructure: HIPAA, Medicare, state licensing systems</li>
                        <li>Quality assurance: Patient outcome tracking and safety protocols</li>
                      </ul>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </div>
              <ul className="text-sm text-yellow-600 space-y-2">
                <li>• AI platform development</li>
                <li>• Provider onboarding systems</li>
                <li>• Compliance infrastructure</li>
                <li>• Quality assurance processes</li>
              </ul>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <TrendingUp className="w-5 h-5 text-green-700 mr-2" />
                <h4 className="font-medium text-green-700">Optimization Timeline</h4>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-green-600 cursor-help ml-2" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="max-w-xs space-y-1">
                      <p className="font-semibold">Performance Improvement Schedule</p>
                      <p className="text-sm">Realistic timeline for marketing campaign optimization and efficiency gains:</p>
                      <ul className="text-xs space-y-1 list-disc list-inside">
                        <li>Month 3-6: Learning phase - data collection and initial optimization</li>
                        <li>Month 6-12: Conversion improvements from better targeting and messaging</li>
                        <li>Year 2-3: Sustained annual optimization as campaigns mature</li>
                        <li>Year 4-5: Mature efficiency with established patient acquisition systems</li>
                      </ul>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="space-y-2 text-sm text-green-600">
                <div className="flex justify-between">
                  <span>Month 3-6:</span>
                  <span>Campaign learning phase</span>
                </div>
                <div className="flex justify-between">
                  <span>Month 6-12:</span>
                  <span>+{Math.round(state.conversionOptimization * 0.5)}% conversion improvement</span>
                </div>
                <div className="flex justify-between">
                  <span>Year 2-3:</span>
                  <span>+{state.conversionOptimization}% annual optimization</span>
                </div>
                <div className="flex justify-between">
                  <span>Year 4-5:</span>
                  <span>Mature campaign efficiency</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
