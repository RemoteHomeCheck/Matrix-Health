import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Target, Users, Zap, ArrowRight } from "lucide-react";
import { CalculatorState, CalculatorResults } from "@shared/schema";
import { formatNumber, formatCurrency } from "@/lib/calculations";

interface OptimizationSuggestionsProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export function OptimizationSuggestions({ state, results, onUpdate }: OptimizationSuggestionsProps) {
  const currentPatients = results.totalPatients;
  const currentSpend = state.digitalSpendOnImpressions + state.oohSpendOnImpressions;

  const optimizations = [
    {
      icon: Target,
      title: "Improve Lead Conversion",
      description: "Increase Digital Lead Conversion from 1% to 2.5%",
      currentValue: `${state.digitalLeadConv}%`,
      targetValue: "2.5%",
      impact: "6x more patients",
      action: () => onUpdate({ digitalLeadConv: 2.5 }),
      reasoning: "Better landing pages, lead magnets, and follow-up sequences"
    },
    {
      icon: Users,
      title: "Boost Appointment Rate",
      description: "Increase appointment conversion from 7.5% to 15%",
      currentValue: `${state.digitalApptConv}%`,
      targetValue: "15%",
      impact: "2x more patients",
      action: () => onUpdate({ digitalApptConv: 15, oohApptConv: 15 }),
      reasoning: "Phone follow-up, appointment incentives, telehealth options"
    },
    {
      icon: Zap,
      title: "Optimize Click Rate",
      description: "Improve CTR from 1.2% to 2.0%",
      currentValue: `${state.digitalCtr}%`,
      targetValue: "2.0%",
      impact: "67% more patients",
      action: () => onUpdate({ digitalCtr: 2.0 }),
      reasoning: "Better ad copy, targeting, and creative testing"
    },
    {
      icon: TrendingUp,
      title: "Increase Patient Conversion",
      description: "Boost patient conversion from 60% to 80%",
      currentValue: `${state.digitalPatientConv}%`,
      targetValue: "80%",
      impact: "33% more patients",
      action: () => onUpdate({ digitalPatientConv: 80, oohPatientConv: 75 }),
      reasoning: "Better qualification, education, and treatment plans"
    }
  ];

  // Calculate combined optimization impact
  const optimizedState = {
    ...state,
    digitalLeadConv: 2.5,
    digitalApptConv: 15,
    oohApptConv: 15,
    digitalCtr: 2.0,
    digitalPatientConv: 80,
    oohPatientConv: 75
  };

  // Simple calculation for demonstration
  const optimizedClicks = state.digitalImpressions * (2.0 / 100);
  const optimizedLeads = optimizedClicks * (2.5 / 100);
  const optimizedAppointments = optimizedLeads * (15 / 100);
  const optimizedPatients = optimizedAppointments * (80 / 100);
  
  const oohOptimizedResponses = state.oohImpressions * (state.oohResponse / 100);
  const oohOptimizedLeads = oohOptimizedResponses * (state.oohLeadConv / 100);
  const oohOptimizedAppointments = oohOptimizedLeads * (15 / 100);
  const oohOptimizedPatients = oohOptimizedAppointments * (75 / 100);
  
  const totalOptimizedPatients = optimizedPatients + oohOptimizedPatients;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            Growth Optimization Strategies
          </CardTitle>
          <p className="text-sm text-gray-600">
            Current: {formatNumber(currentPatients)} patients/month for {formatCurrency(currentSpend)}/month
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            {optimizations.map((opt, index) => {
              const Icon = opt.icon;
              return (
                <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Icon className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm mb-1">{opt.title}</h4>
                      <p className="text-xs text-gray-600 mb-2">{opt.description}</p>
                      
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          {opt.currentValue}
                        </Badge>
                        <ArrowRight className="w-3 h-3 text-gray-400" />
                        <Badge variant="default" className="text-xs">
                          {opt.targetValue}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium text-green-600">{opt.impact}</span>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={opt.action}
                          className="text-xs px-2 py-1 h-6"
                        >
                          Apply
                        </Button>
                      </div>
                      
                      <p className="text-xs text-gray-500 mt-2">{opt.reasoning}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Combined Impact */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-green-800">Combined Optimization Impact</h4>
              <Button 
                onClick={() => onUpdate(optimizedState)}
                className="bg-green-600 hover:bg-green-700"
                size="sm"
              >
                Apply All Optimizations
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-700">
                  {formatNumber(totalOptimizedPatients)}
                </div>
                <div className="text-xs text-green-600">Optimized Patients/Month</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-700">
                  {Math.round((totalOptimizedPatients / currentPatients) * 100)}%
                </div>
                <div className="text-xs text-green-600">Improvement</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-700">
                  {formatCurrency(totalOptimizedPatients * results.distributorRevenue)}
                </div>
                <div className="text-xs text-green-600">Monthly Distributor Revenue</div>
              </div>
            </div>
          </div>

          {/* Implementation Timeline */}
          <div className="mt-6">
            <h4 className="font-semibold mb-3">Implementation Timeline</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <Badge className="w-16 text-xs">Week 1-2</Badge>
                <span className="text-sm">Improve ad copy and landing pages (CTR boost)</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="w-16 text-xs">Week 3-4</Badge>
                <span className="text-sm">Implement lead magnets and follow-up sequences (Lead conv.)</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="w-16 text-xs">Week 5-8</Badge>
                <span className="text-sm">Add phone follow-up and appointment incentives (Appt rate)</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="w-16 text-xs">Week 9-12</Badge>
                <span className="text-sm">Optimize consultation process and patient education</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}