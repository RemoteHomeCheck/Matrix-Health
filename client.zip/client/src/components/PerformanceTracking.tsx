import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, TrendingUp, TrendingDown, AlertCircle, Calculator, Target, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { CalculatorState, MonthlyPerformanceData, CalculatorResults } from "@shared/schema";
import { formatCurrency, formatNumber, formatPercentage } from "@/lib/calculations";

interface PerformanceTrackingProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export default function PerformanceTracking({ state, results, onUpdate }: PerformanceTrackingProps) {
  const [selectedMonth, setSelectedMonth] = useState<MonthlyPerformanceData | null>(null);
  const [isAddingMonth, setIsAddingMonth] = useState(false);

  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  // Initialize performance data if needed
  const performanceData = state.actualPerformanceData || [];

  const handleToggleTracking = (enabled: boolean) => {
    onUpdate({ 
      enablePerformanceTracking: enabled,
      actualPerformanceData: enabled ? performanceData : []
    });
  };

  const handleAddMonth = () => {
    const newMonth: MonthlyPerformanceData = {
      id: `${currentYear}-${currentMonth}-${Date.now()}`,
      month: currentMonth,
      year: currentYear,
      actualDigitalSpend: 0,
      actualOohSpend: 0,
      actualDigitalClicks: 0,
      actualDigitalLeads: 0,
      actualDigitalAppointments: 0,
      actualDigitalPatients: 0,
      actualOohResponses: 0,
      actualOohLeads: 0,
      actualOohAppointments: 0,
      actualOohPatients: 0,
      actualTotalPatients: 0,
      actualRevenue: 0,
      actualDigitalCAC: null,
      actualOohCAC: null,
      actualBlendedCAC: null,
      notes: "",
    };
    setSelectedMonth(newMonth);
    setIsAddingMonth(true);
  };

  const handleSaveMonth = (monthData: MonthlyPerformanceData) => {
    // Calculate derived metrics
    const totalSpend = monthData.actualDigitalSpend + monthData.actualOohSpend;
    const totalPatients = monthData.actualDigitalPatients + monthData.actualOohPatients;
    
    const updatedMonth = {
      ...monthData,
      actualTotalPatients: totalPatients,
      actualRevenue: totalPatients * results.patientRevenue,
      actualDigitalCAC: monthData.actualDigitalPatients > 0 ? monthData.actualDigitalSpend / monthData.actualDigitalPatients : null,
      actualOohCAC: monthData.actualOohPatients > 0 ? monthData.actualOohSpend / monthData.actualOohPatients : null,
      actualBlendedCAC: totalPatients > 0 ? totalSpend / totalPatients : null,
      // Add variance calculations vs projections
      projectedPatients: results.totalPatients,
      projectedRevenue: results.totalMonthlyRevenue,
      patientsVariance: results.totalPatients > 0 ? ((totalPatients - results.totalPatients) / results.totalPatients) * 100 : 0,
      revenueVariance: results.totalMonthlyRevenue > 0 ? ((totalPatients * results.patientRevenue - results.totalMonthlyRevenue) / results.totalMonthlyRevenue) * 100 : 0,
    };

    const updatedData = isAddingMonth 
      ? [...performanceData, updatedMonth]
      : performanceData.map(item => item.id === monthData.id ? updatedMonth : item);

    onUpdate({ actualPerformanceData: updatedData });
    setSelectedMonth(null);
    setIsAddingMonth(false);
  };

  const calculateAverageVariance = () => {
    if (performanceData.length === 0) return { patients: 0, revenue: 0 };
    
    const avgPatientsVariance = performanceData.reduce((sum, month) => sum + (month.patientsVariance || 0), 0) / performanceData.length;
    const avgRevenueVariance = performanceData.reduce((sum, month) => sum + (month.revenueVariance || 0), 0) / performanceData.length;
    
    return { patients: avgPatientsVariance, revenue: avgRevenueVariance };
  };

  const averageVariance = calculateAverageVariance();

  if (!state.enablePerformanceTracking) {
    return (
      <Card data-testid="performance-tracking-toggle">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Real-Time Performance Tracking</CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-4 w-4 text-blue-600 cursor-help" />
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs">Track actual monthly performance data to compare against projections and get updated forecasts based on real results. Essential for ongoing business optimization.</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-3">
            <Switch
              checked={state.enablePerformanceTracking}
              onCheckedChange={handleToggleTracking}
              data-testid="switch-enable-tracking"
            />
            <div>
              <Label htmlFor="enable-tracking" className="text-sm font-medium">
                Enable Performance Tracking
              </Label>
              <p className="text-xs text-gray-600">
                Input actual monthly results to refine projections and track variance from initial forecasts
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <TooltipProvider>
      <div className="space-y-6">
        {/* Header with Toggle */}
        <Card data-testid="performance-tracking-header">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CardTitle>Real-Time Performance Tracking</CardTitle>
                <Badge variant={performanceData.length > 0 ? "default" : "secondary"}>
                  {performanceData.length} months tracked
                </Badge>
              </div>
              <Switch
                checked={state.enablePerformanceTracking}
                onCheckedChange={handleToggleTracking}
                data-testid="switch-disable-tracking"
              />
            </div>
          </CardHeader>
        </Card>

        {/* Performance Summary */}
        {performanceData.length > 0 && (
          <Card data-testid="performance-summary">
            <CardHeader>
              <CardTitle>Performance Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="h-5 w-5 text-blue-600" />
                    <h4 className="font-medium text-blue-900">Average Patient Variance</h4>
                  </div>
                  <p className={`text-2xl font-bold ${averageVariance.patients >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {averageVariance.patients >= 0 ? '+' : ''}{averageVariance.patients.toFixed(1)}%
                  </p>
                  <p className="text-sm text-blue-700">vs. initial projections</p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="h-5 w-5 text-green-600" />
                    <h4 className="font-medium text-green-900">Average Revenue Variance</h4>
                  </div>
                  <p className={`text-2xl font-bold ${averageVariance.revenue >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {averageVariance.revenue >= 0 ? '+' : ''}{averageVariance.revenue.toFixed(1)}%
                  </p>
                  <p className="text-sm text-green-700">vs. initial projections</p>
                </div>
                
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Calculator className="h-5 w-5 text-yellow-600" />
                    <h4 className="font-medium text-yellow-900">Tracking Period</h4>
                  </div>
                  <p className="text-2xl font-bold text-yellow-800">
                    {performanceData.length} {performanceData.length === 1 ? 'month' : 'months'}
                  </p>
                  <p className="text-sm text-yellow-700">of actual data</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Monthly Data Management */}
        <Card data-testid="monthly-data-management">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Monthly Performance Data</CardTitle>
              <Button onClick={handleAddMonth} size="sm" data-testid="button-add-month">
                <Plus className="h-4 w-4 mr-2" />
                Add Current Month
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {performanceData.length === 0 ? (
              <div className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Performance Data Yet</h3>
                <p className="text-gray-600 mb-4">
                  Start tracking by adding your first month of actual performance data
                </p>
                <Button onClick={handleAddMonth} data-testid="button-add-first-month">
                  <Plus className="h-4 w-4 mr-2" />
                  Add First Month
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {performanceData.map((month) => (
                  <div key={month.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">
                        {new Date(month.year, month.month - 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                      </h4>
                      <div className="flex gap-2">
                        <Badge variant={month.patientsVariance && month.patientsVariance >= 0 ? "default" : "destructive"}>
                          {month.patientsVariance ? `${month.patientsVariance >= 0 ? '+' : ''}${month.patientsVariance.toFixed(1)}%` : 'N/A'}
                        </Badge>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => setSelectedMonth(month)}
                          data-testid={`button-edit-month-${month.id}`}
                        >
                          Edit
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Patients:</span>
                        <p className="font-medium">{formatNumber(month.actualTotalPatients)}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Revenue:</span>
                        <p className="font-medium">{formatCurrency(month.actualRevenue)}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Blended CAC:</span>
                        <p className="font-medium">{month.actualBlendedCAC ? formatCurrency(month.actualBlendedCAC) : 'N/A'}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Total Spend:</span>
                        <p className="font-medium">{formatCurrency(month.actualDigitalSpend + month.actualOohSpend)}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Month Editor Modal/Form */}
        {selectedMonth && (
          <MonthEditor 
            month={selectedMonth}
            onSave={handleSaveMonth}
            onCancel={() => {
              setSelectedMonth(null);
              setIsAddingMonth(false);
            }}
            isNew={isAddingMonth}
          />
        )}
      </div>
    </TooltipProvider>
  );
}

interface MonthEditorProps {
  month: MonthlyPerformanceData;
  onSave: (month: MonthlyPerformanceData) => void;
  onCancel: () => void;
  isNew: boolean;
}

function MonthEditor({ month, onSave, onCancel, isNew }: MonthEditorProps) {
  const [formData, setFormData] = useState<MonthlyPerformanceData>(month);

  const handleInputChange = (field: keyof MonthlyPerformanceData, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: typeof value === 'string' ? (isNaN(Number(value)) ? value : Number(value)) : value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Card data-testid="month-editor">
      <CardHeader>
        <CardTitle>
          {isNew ? 'Add' : 'Edit'} Performance Data - {new Date(formData.year, formData.month - 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <Tabs defaultValue="spending" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="spending">Spending</TabsTrigger>
              <TabsTrigger value="digital">Digital Results</TabsTrigger>
              <TabsTrigger value="ooh">OOH Results</TabsTrigger>
            </TabsList>
            
            <TabsContent value="spending" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="actualDigitalSpend">Digital Spend</Label>
                  <Input
                    id="actualDigitalSpend"
                    type="number"
                    value={formData.actualDigitalSpend}
                    onChange={(e) => handleInputChange('actualDigitalSpend', e.target.value)}
                    data-testid="input-digital-spend"
                  />
                </div>
                <div>
                  <Label htmlFor="actualOohSpend">OOH Spend</Label>
                  <Input
                    id="actualOohSpend"
                    type="number"
                    value={formData.actualOohSpend}
                    onChange={(e) => handleInputChange('actualOohSpend', e.target.value)}
                    data-testid="input-ooh-spend"
                  />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="digital" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="actualDigitalClicks">Digital Clicks</Label>
                  <Input
                    id="actualDigitalClicks"
                    type="number"
                    value={formData.actualDigitalClicks}
                    onChange={(e) => handleInputChange('actualDigitalClicks', e.target.value)}
                    data-testid="input-digital-clicks"
                  />
                </div>
                <div>
                  <Label htmlFor="actualDigitalLeads">Digital Leads</Label>
                  <Input
                    id="actualDigitalLeads"
                    type="number"
                    value={formData.actualDigitalLeads}
                    onChange={(e) => handleInputChange('actualDigitalLeads', e.target.value)}
                    data-testid="input-digital-leads"
                  />
                </div>
                <div>
                  <Label htmlFor="actualDigitalAppointments">Digital Appointments</Label>
                  <Input
                    id="actualDigitalAppointments"
                    type="number"
                    value={formData.actualDigitalAppointments}
                    onChange={(e) => handleInputChange('actualDigitalAppointments', e.target.value)}
                    data-testid="input-digital-appointments"
                  />
                </div>
                <div>
                  <Label htmlFor="actualDigitalPatients">Digital Patients</Label>
                  <Input
                    id="actualDigitalPatients"
                    type="number"
                    value={formData.actualDigitalPatients}
                    onChange={(e) => handleInputChange('actualDigitalPatients', e.target.value)}
                    data-testid="input-digital-patients"
                  />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="ooh" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="actualOohResponses">OOH Responses</Label>
                  <Input
                    id="actualOohResponses"
                    type="number"
                    value={formData.actualOohResponses}
                    onChange={(e) => handleInputChange('actualOohResponses', e.target.value)}
                    data-testid="input-ooh-responses"
                  />
                </div>
                <div>
                  <Label htmlFor="actualOohLeads">OOH Leads</Label>
                  <Input
                    id="actualOohLeads"
                    type="number"
                    value={formData.actualOohLeads}
                    onChange={(e) => handleInputChange('actualOohLeads', e.target.value)}
                    data-testid="input-ooh-leads"
                  />
                </div>
                <div>
                  <Label htmlFor="actualOohAppointments">OOH Appointments</Label>
                  <Input
                    id="actualOohAppointments"
                    type="number"
                    value={formData.actualOohAppointments}
                    onChange={(e) => handleInputChange('actualOohAppointments', e.target.value)}
                    data-testid="input-ooh-appointments"
                  />
                </div>
                <div>
                  <Label htmlFor="actualOohPatients">OOH Patients</Label>
                  <Input
                    id="actualOohPatients"
                    type="number"
                    value={formData.actualOohPatients}
                    onChange={(e) => handleInputChange('actualOohPatients', e.target.value)}
                    data-testid="input-ooh-patients"
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <div>
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={formData.notes || ''}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder="Any additional notes about this month's performance..."
              data-testid="textarea-notes"
            />
          </div>

          <div className="flex gap-3">
            <Button type="submit" data-testid="button-save-month">
              {isNew ? 'Add Month' : 'Save Changes'}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} data-testid="button-cancel-month">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}