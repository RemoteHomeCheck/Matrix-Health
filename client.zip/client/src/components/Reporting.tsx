import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { 
  FileText, 
  Download, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Target,
  Calendar,
  BarChart3,
  PieChart,
  LineChart,
  Eye,
  Mail,
  Printer,
  Calculator,
  RefreshCw,
  Plus,
  Trash2
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { CalculatorState, CalculatorResults, MonthlyPerformanceData } from "@shared/schema";
import { formatCurrency, formatNumber, formatPercentage } from "@/lib/calculations";

interface ReportingProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export default function Reporting({ state, results, onUpdate }: ReportingProps) {
  const [selectedReportType, setSelectedReportType] = useState<string>("executive-summary");
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>("current-month");
  const [exportFormat, setExportFormat] = useState<string>("pdf");
  const [autoReportsEnabled, setAutoReportsEnabled] = useState<boolean>(false);
  const [scheduledReports, setScheduledReports] = useState([
    { id: '1', name: 'Monthly Executive Summary', frequency: 'monthly', format: 'pdf', email: true, sms: false, enabled: true, nextRun: '2024-09-01' },
    { id: '2', name: 'Weekly Performance Tracking', frequency: 'weekly', format: 'excel', email: true, sms: true, enabled: false, nextRun: '2024-08-13' },
    { id: '3', name: 'Quarterly Financial Analysis', frequency: 'quarterly', format: 'quickbooks', email: true, sms: false, enabled: true, nextRun: '2024-10-01' }
  ]);

  const performanceData = state.actualPerformanceData || [];
  const hasPerformanceData = performanceData.length > 0;

  // Calculate performance metrics
  const calculatePerformanceMetrics = () => {
    if (!hasPerformanceData) return null;

    const totalActualPatients = performanceData.reduce((sum, month) => sum + month.actualTotalPatients, 0);
    const totalActualRevenue = performanceData.reduce((sum, month) => sum + month.actualRevenue, 0);
    const totalActualSpend = performanceData.reduce((sum, month) => sum + month.actualDigitalSpend + month.actualOohSpend, 0);
    
    const avgMonthlyPatients = totalActualPatients / performanceData.length;
    const avgMonthlyRevenue = totalActualRevenue / performanceData.length;
    const avgBlendedCAC = totalActualPatients > 0 ? totalActualSpend / totalActualPatients : 0;
    
    const projectedMonthlyPatients = results.totalPatients;
    const projectedMonthlyRevenue = results.totalMonthlyRevenue;
    
    const patientsVariance = projectedMonthlyPatients > 0 ? 
      ((avgMonthlyPatients - projectedMonthlyPatients) / projectedMonthlyPatients) * 100 : 0;
    const revenueVariance = projectedMonthlyRevenue > 0 ? 
      ((avgMonthlyRevenue - projectedMonthlyRevenue) / projectedMonthlyRevenue) * 100 : 0;

    return {
      totalActualPatients,
      totalActualRevenue,
      totalActualSpend,
      avgMonthlyPatients,
      avgMonthlyRevenue,
      avgBlendedCAC,
      patientsVariance,
      revenueVariance,
      trackingPeriod: performanceData.length
    };
  };

  const performanceMetrics = calculatePerformanceMetrics();

  const handleAutoSync = async (format: string) => {
    // Auto-sync functionality for direct integration with practice management systems
    try {
      const reportData = {
        reportType: selectedReportType,
        timeframe: selectedTimeframe,
        generatedAt: new Date().toISOString(),
        projections: results,
        performance: performanceMetrics,
        state: {
          revenueModel: state.revenueModel,
          totalBudget: state.totalBudget,
          digitalAllocation: state.digitalAllocation,
          distributorShare: state.distributorShare,
          providerShare: state.providerShare,
          manufacturerShare: state.manufacturerShare
        }
      };

      // Show sync in progress
      const syncButton = document.querySelector('[data-testid="button-auto-sync"]') as HTMLButtonElement;
      if (syncButton) {
        syncButton.disabled = true;
        syncButton.textContent = 'Syncing...';
      }

      // Simulate API call to practice management system
      await simulateAPISync(format, reportData);
      
      // Success feedback
      alert(`Successfully synced data to ${exportFormats.find(f => f.id === format)?.name}! Financial data has been automatically imported.`);
      
    } catch (error) {
      alert(`Sync failed: ${error.message}. Please check your API credentials or try manual export.`);
    } finally {
      // Reset button state
      const syncButton = document.querySelector('[data-testid="button-auto-sync"]') as HTMLButtonElement;
      if (syncButton) {
        syncButton.disabled = false;
        syncButton.textContent = `Auto-Sync to ${exportFormats.find(f => f.id === format)?.name.split(' ')[0] || 'System'}`;
      }
    }
  };

  const simulateAPISync = async (format: string, reportData: any) => {
    // Simulate API integration with different practice management systems
    const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
    
    await delay(2000); // Simulate API call time
    
    // In a real implementation, this would make actual API calls to:
    switch (format) {
      case 'epic':
        // Epic MyChart API integration
        console.log('Syncing to Epic MyChart via FHIR R4 API...');
        break;
      case 'cerner':
        // Oracle Cerner PowerChart API
        console.log('Syncing to Cerner PowerChart via SMART on FHIR...');
        break;
      case 'athenahealth':
        // athenaCollector API
        console.log('Syncing to athenahealth via athenaCollector API...');
        break;
      case 'quickbooks':
        // QuickBooks Online API
        console.log('Syncing to QuickBooks via Intuit API...');
        break;
      case 'nextgen':
        // NextGen Healthcare API
        console.log('Syncing to NextGen via Practice Management API...');
        break;
      default:
        console.log(`Syncing to ${format} via REST API...`);
    }
    
    // Random chance of failure to simulate real-world scenarios
    if (Math.random() < 0.1) {
      throw new Error('API authentication failed. Please check credentials.');
    }
  };

  const generateFinancialSoftwareData = (format: string, reportData: any) => {
    const baseData = {
      date: new Date().toISOString().split('T')[0],
      description: `Matrix Health Calculator - ${reportData.reportType}`,
      revenue: results.totalMonthlyRevenue,
      marketingExpense: state.digitalSpendOnImpressions + state.oohSpendOnImpressions,
      patients: results.totalPatients,
      distributorShare: results.totalDistributorRevenue,
      providerShare: results.totalMonthlyRevenue * (state.providerShare / 100),
      manufacturerShare: results.totalMonthlyRevenue * (state.manufacturerShare / 100)
    };

    switch (format) {
      case 'quickbooks':
        return generateQuickBooksFormat(baseData);
      case 'epic':
        return generateEpicFormat(baseData);
      case 'cerner':
        return generateCernerFormat(baseData);
      case 'athenahealth':
        return generateAthenaHealthFormat(baseData);
      case 'nextgen':
        return generateNextGenFormat(baseData);
      case 'eclinicalworks':
        return generateEClinicalWorksFormat(baseData);
      case 'allscripts':
        return generateAllscriptsFormat(baseData);
      case 'meditech':
        return generateMeditechFormat(baseData);
      case 'xero':
        return generateXeroFormat(baseData);
      case 'sage':
        return generateSageIntacctFormat(baseData);
      case 'csv':
        return generateUniversalCSV(baseData);
      case 'excel':
        return generateExcelFormat(baseData, reportData);
      default:
        return JSON.stringify(reportData, null, 2);
    }
  };

  const generateQuickBooksFormat = (data: any) => {
    // QuickBooks IIF format for easy import
    const qbData = [
      '!TRNS\tTRNSTYPE\tDATE\tACCNT\tNAME\tCLASS\tAMOUNT\tDOCNUM\tMEMO',
      `TRNS\tDEPOSIT\t${data.date}\tUndeposited Funds\tMatrix Health Revenue\t\t${data.revenue}\tMH-${data.date}\tWound Care Treatment Revenue`,
      'SPL\tDEPOSIT\t' + data.date + '\tRevenue:Medical Services\t\t\t-' + data.revenue + '\t\tPatient Treatment Reimbursement',
      'ENDTRNS',
      '',
      '!TRNS\tTRNSTYPE\tDATE\tACCNT\tNAME\tCLASS\tAMOUNT\tDOCNUM\tMEMO',
      `TRNS\tCHECK\t${data.date}\tChecking\tMarketing Expense\t\t-${data.marketingExpense}\tMKT-${data.date}\tDigital and OOH Marketing`,
      'SPL\tCHECK\t' + data.date + '\tExpenses:Marketing\t\t\t' + data.marketingExpense + '\t\tMarketing Campaign Costs',
      'ENDTRNS'
    ].join('\n');
    return qbData;
  };

  const generateXeroFormat = (data: any) => {
    // Xero CSV format for bank statement import
    const xeroData = [
      'Date,Amount,Payee,Description,Reference',
      `${data.date},${data.revenue},"Patient Revenue","Wound Care Treatment Revenue - ${data.patients} patients","MH-REV-${data.date}"`,
      `${data.date},-${data.marketingExpense},"Marketing Expense","Digital and OOH Marketing Costs","MH-MKT-${data.date}"`
    ].join('\n');
    return xeroData;
  };

  const generateEpicFormat = (data: any) => {
    // Epic MyChart revenue reporting format - CSV compatible with Epic Systems
    const epicData = [
      'Date,Department,Service_Line,Revenue_Type,Amount,Patient_Count,Description,Reference_ID',
      `${data.date},"Wound Care","Dermal Patch Treatment","Patient Revenue",${data.revenue},${data.patients},"Matrix Health Calculator - Wound Care Revenue","MH-EPIC-${data.date}"`,
      `${data.date},"Marketing","Digital Marketing","Marketing Expense",-${data.marketingExpense},0,"Digital and OOH Marketing Investment","MH-MKT-${data.date}"`
    ].join('\n');
    return epicData;
  };

  const generateCernerFormat = (data: any) => {
    // Oracle Cerner PowerChart financial data format
    const cernerData = [
      'Transaction_Date,Revenue_Center,Charge_Code,Description,Amount,Quantity,Unit_Revenue,Patient_Type',
      `${data.date},"WOUND_CARE","DERMAL_PATCH","Dermal Patch Graft Treatment",${data.revenue},${data.patients},${(data.revenue / data.patients).toFixed(2)},"Medicare"`,
      `${data.date},"MARKETING","MKT_EXPENSE","Marketing Campaign Costs",-${data.marketingExpense},1,${data.marketingExpense},"Operational"`
    ].join('\n');
    return cernerData;
  };

  const generateAthenaHealthFormat = (data: any) => {
    // athenaCollector billing integration format
    const athenaData = [
      'Date,Practice_ID,Department,Charge_Description,Amount,Patient_Count,Revenue_Category,Notes',
      `${data.date},"MATRIX_HEALTH","Wound Care","Dermal Patch Treatment Revenue",${data.revenue},${data.patients},"Patient_Care","Matrix Health Calculator - ${data.patients} patients treated"`,
      `${data.date},"MATRIX_HEALTH","Administration","Marketing Investment",-${data.marketingExpense},0,"Marketing","Digital and OOH marketing campaigns"`
    ].join('\n');
    return athenaData;
  };

  const generateNextGenFormat = (data: any) => {
    // NextGen Healthcare practice management format
    const nextGenData = [
      'Transaction_Date,Provider_ID,Service_Code,Description,Charge_Amount,Units,Patient_Count,Revenue_Stream',
      `${data.date},"PROVIDER_001","WOUND_CARE","Dermal Patch Graft Treatment",${data.revenue},${data.patients},${data.patients},"Clinical_Revenue"`,
      `${data.date},"ADMIN_001","MARKETING","Practice Marketing Expenses",${data.marketingExpense},1,0,"Operational_Expense"`
    ].join('\n');
    return nextGenData;
  };

  const generateEClinicalWorksFormat = (data: any) => {
    // eClinicalWorks revenue cycle management format
    const ecwData = [
      'Date,Department_Code,Service_Type,Revenue_Amount,Expense_Amount,Patient_Volume,Description,Tracking_ID',
      `${data.date},"WOUND_CARE","CLINICAL_SERVICE",${data.revenue},0,${data.patients},"Dermal Patch Treatment Revenue","ECW-REV-${data.date}"`,
      `${data.date},"ADMIN","MARKETING_EXPENSE",0,${data.marketingExpense},0,"Digital and OOH Marketing Costs","ECW-MKT-${data.date}"`
    ].join('\n');
    return ecwData;
  };

  const generateAllscriptsFormat = (data: any) => {
    // Allscripts financial reporting format
    const allscriptsData = [
      'Transaction_Date,Location_ID,Revenue_Center,Charge_Code,Amount,Volume,Description,Batch_ID',
      `${data.date},"LOC_001","WOUND_CARE","99283",${data.revenue},${data.patients},"Matrix Health Dermal Patch Revenue","BATCH_${data.date}_001"`,
      `${data.date},"LOC_001","ADMIN","MKT_EXP",-${data.marketingExpense},1,"Marketing Campaign Investment","BATCH_${data.date}_002"`
    ].join('\n');
    return allscriptsData;
  };

  const generateMeditechFormat = (data: any) => {
    // MEDITECH Expanse financial module format
    const meditechData = [
      'Date,Account_Code,Department,Description,Debit_Amount,Credit_Amount,Patient_Count,Reference',
      `${data.date},"4000.001","WOUND_CARE","Dermal Patch Treatment Revenue",${data.revenue},0,${data.patients},"MEDITECH-REV-${data.date}"`,
      `${data.date},"6100.001","MARKETING","Digital and OOH Marketing Expense",0,${data.marketingExpense},0,"MEDITECH-MKT-${data.date}"`
    ].join('\n');
    return meditechData;
  };

  const generateSageIntacctFormat = (data: any) => {
    // Sage Intacct healthcare-specific accounting format
    const sageData = [
      'Journal_ID,Date,Account_Number,Debit,Credit,Description,Entity,Department,Location',
      `MH_${data.date}_001,${data.date},4100,${data.revenue},0,"Wound Care Revenue - Matrix Health","MATRIX_HEALTH","CLINICAL","MAIN"`,
      `MH_${data.date}_002,${data.date},6200,0,${data.marketingExpense},"Marketing Investment - Digital/OOH","MATRIX_HEALTH","MARKETING","MAIN"`
    ].join('\n');
    return sageData;
  };

  const generateUniversalCSV = (data: any) => {
    // Universal CSV format compatible with most accounting software
    const csvData = [
      'Date,Description,Category,Revenue,Expenses,Net_Amount,Patients,Distributor_Share,Provider_Share,Manufacturer_Share',
      `${data.date},"Matrix Health Calculator Report","Medical Revenue",${data.revenue},${data.marketingExpense},${data.revenue - data.marketingExpense},${data.patients},${data.distributorShare},${data.providerShare},${data.manufacturerShare}`
    ].join('\n');
    return csvData;
  };

  const generateExcelFormat = (data: any, reportData: any) => {
    // Create Excel-compatible CSV with multiple sheets worth of data
    const excelData = [
      // Summary Sheet
      'Matrix Health Calculator - Financial Summary',
      '',
      'Metric,Value',
      `Report Date,${data.date}`,
      `Monthly Revenue,$${data.revenue.toLocaleString()}`,
      `Marketing Expense,$${data.marketingExpense.toLocaleString()}`,
      `Net Profit,$${(data.revenue - data.marketingExpense).toLocaleString()}`,
      `Patients Treated,${data.patients}`,
      `Revenue per Patient,$${(data.revenue / data.patients).toLocaleString()}`,
      '',
      'Revenue Distribution',
      `Distributor Share (${state.distributorShare}%),$${data.distributorShare.toLocaleString()}`,
      `Provider Share (${state.providerShare}%),$${data.providerShare.toLocaleString()}`,
      `Manufacturer Share (${state.manufacturerShare}%),$${data.manufacturerShare.toLocaleString()}`,
      '',
      'Marketing Performance',
      `Digital Spend,$${state.digitalSpendOnImpressions.toLocaleString()}`,
      `OOH Spend,$${state.oohSpendOnImpressions.toLocaleString()}`,
      `Digital Patients,${results.digitalPatients}`,
      `OOH Patients,${results.oohPatients}`,
      `Digital CAC,$${results.digitalCAC?.toLocaleString() || 'N/A'}`,
      `OOH CAC,$${results.oohCAC?.toLocaleString() || 'N/A'}`
    ].join('\n');
    return excelData;
  };

  const handleExportReport = (format: string, reportType: string) => {
    const reportData = {
      reportType,
      timeframe: selectedTimeframe,
      generatedAt: new Date().toISOString(),
      projections: results,
      performance: performanceMetrics,
      state: {
        revenueModel: state.revenueModel,
        totalBudget: state.totalBudget,
        digitalAllocation: state.digitalAllocation,
        distributorShare: state.distributorShare,
        providerShare: state.providerShare,
        manufacturerShare: state.manufacturerShare
      }
    };

    // Generate format-specific content
    const content = generateFinancialSoftwareData(format, reportData);
    
    // Determine file extension and MIME type
    const fileExtensions: { [key: string]: string } = {
      'quickbooks': 'iif',
      'epic': 'csv',
      'cerner': 'csv',
      'athenahealth': 'csv',
      'nextgen': 'csv',
      'eclinicalworks': 'csv',
      'allscripts': 'csv',
      'meditech': 'csv',
      'xero': 'csv',
      'sage': 'csv',
      'csv': 'csv',
      'excel': 'csv',
      'json': 'json',
      'pdf': 'json' // PDF would require additional library
    };

    const mimeTypes: { [key: string]: string } = {
      'csv': 'text/csv',
      'iif': 'text/plain',
      'json': 'application/json'
    };

    const extension = fileExtensions[format] || 'txt';
    const mimeType = mimeTypes[extension] || 'text/plain';
    
    // Create and download file
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `matrix-health-${reportType}-${new Date().toISOString().split('T')[0]}.${extension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleScheduleReport = (reportConfig: any) => {
    const newReport = {
      id: (scheduledReports.length + 1).toString(),
      name: reportConfig.name,
      frequency: reportConfig.frequency,
      format: reportConfig.format,
      email: reportConfig.email,
      sms: reportConfig.sms,
      enabled: true,
      nextRun: calculateNextRunDate(reportConfig.frequency)
    };
    setScheduledReports(prev => [...prev, newReport]);
  };

  const calculateNextRunDate = (frequency: string) => {
    const now = new Date();
    switch (frequency) {
      case 'daily':
        now.setDate(now.getDate() + 1);
        break;
      case 'weekly':
        now.setDate(now.getDate() + 7);
        break;
      case 'monthly':
        now.setMonth(now.getMonth() + 1);
        break;
      case 'quarterly':
        now.setMonth(now.getMonth() + 3);
        break;
      case 'annually':
        now.setFullYear(now.getFullYear() + 1);
        break;
    }
    return now.toISOString().split('T')[0];
  };

  const handleToggleScheduledReport = (reportId: string) => {
    setScheduledReports(prev => prev.map(report => 
      report.id === reportId 
        ? { ...report, enabled: !report.enabled }
        : report
    ));
  };

  const handleDeleteScheduledReport = (reportId: string) => {
    setScheduledReports(prev => prev.filter(report => report.id !== reportId));
  };

  const handleTestSMS = async (phoneNumber: string) => {
    try {
      const response = await fetch('/api/sms/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ phoneNumber })
      });

      if (response.ok) {
        console.log('Test SMS sent successfully');
        return true;
      } else {
        console.error('Failed to send test SMS');
        return false;
      }
    } catch (error) {
      console.error('SMS test error:', error);
      return false;
    }
  };

  const handleReportGeneration = async (reportConfig: any) => {
    try {
      // Generate the report (using existing export functionality)
      handleExportReport(reportConfig.format, reportConfig.reportType);
      
      // Send notifications if enabled
      if (reportConfig.sms || reportConfig.email) {
        const response = await fetch('/api/reports/notify', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            phoneNumber: reportConfig.sms ? '+1234567890' : undefined, // This would come from user settings
            email: reportConfig.email ? 'doctor@practice.com' : undefined, // This would come from user settings
            reportName: reportConfig.name,
            reportType: reportConfig.reportType
          })
        });

        if (response.ok) {
          console.log('Notifications sent successfully');
        } else {
          console.error('Failed to send notifications');
        }
      }
    } catch (error) {
      console.error('Report generation error:', error);
      
      // Send error notification if SMS is enabled
      if (reportConfig.sms) {
        await fetch('/api/reports/error', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            phoneNumber: '+1234567890', // This would come from user settings
            reportName: reportConfig.name,
            error: error.message || 'Unknown error'
          })
        });
      }
    }
  };

  const frequencyOptions = [
    { id: "daily", name: "Daily", description: "Every day at 6:00 AM" },
    { id: "weekly", name: "Weekly", description: "Every Monday at 6:00 AM" },
    { id: "monthly", name: "Monthly", description: "1st of each month at 6:00 AM" },
    { id: "quarterly", name: "Quarterly", description: "First day of quarter at 6:00 AM" },
    { id: "annually", name: "Annually", description: "January 1st at 6:00 AM" }
  ];

  const reportTypes = [
    { id: "executive-summary", name: "Executive Summary", description: "High-level overview for leadership" },
    { id: "financial-analysis", name: "Financial Analysis", description: "Detailed revenue and cost breakdown" },
    { id: "marketing-performance", name: "Marketing Performance", description: "Channel effectiveness and ROI" },
    { id: "variance-analysis", name: "Variance Analysis", description: "Actual vs projected performance" },
    { id: "distributor-report", name: "Distributor Report", description: "Partner-focused revenue sharing" },
    { id: "clinical-metrics", name: "Clinical Metrics", description: "Patient outcomes and treatment data" }
  ];

  const timeframes = [
    { id: "current-month", name: "Current Month" },
    { id: "quarter", name: "Quarterly" },
    { id: "ytd", name: "Year to Date" },
    { id: "annual", name: "Annual Projection" },
    { id: "multi-year", name: "Multi-Year Forecast" }
  ];

  const exportFormats = [
    { id: "pdf", name: "PDF Report", description: "Professional formatted report for presentations" },
    { id: "excel", name: "Excel (.xlsx)", description: "Microsoft Excel, Google Sheets compatible" },
    { id: "quickbooks", name: "QuickBooks (.iif)", description: "QuickBooks Desktop/Online - 45% of practices" },
    { id: "epic", name: "Epic MyChart", description: "Epic Systems revenue reporting format" },
    { id: "cerner", name: "Cerner PowerChart", description: "Oracle Cerner financial data format" },
    { id: "athenahealth", name: "athenahealth", description: "athenaCollector billing integration" },
    { id: "nextgen", name: "NextGen", description: "NextGen Healthcare practice management" },
    { id: "eclinicalworks", name: "eClinicalWorks", description: "eCW revenue cycle management" },
    { id: "allscripts", name: "Allscripts", description: "Allscripts financial reporting format" },
    { id: "meditech", name: "MEDITECH", description: "MEDITECH Expanse financial module" },
    { id: "xero", name: "Xero", description: "Cloud-based accounting for smaller practices" },
    { id: "sage", name: "Sage Intacct", description: "Healthcare-specific accounting platform" },
    { id: "csv", name: "Universal CSV", description: "Compatible with most practice management systems" }
  ];

  const renderExecutiveSummary = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Users className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-gray-600">Monthly Patients</span>
            </div>
            <p className="text-2xl font-bold text-blue-900">{formatNumber(results.totalPatients)}</p>
            {hasPerformanceData && performanceMetrics && (
              <Badge variant={performanceMetrics.patientsVariance >= 0 ? "default" : "destructive"} className="mt-2">
                {performanceMetrics.patientsVariance >= 0 ? '+' : ''}{performanceMetrics.patientsVariance.toFixed(1)}% vs target
              </Badge>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-gray-600">Monthly Revenue</span>
            </div>
            <p className="text-2xl font-bold text-green-900">{formatCurrency(results.totalMonthlyRevenue)}</p>
            {hasPerformanceData && performanceMetrics && (
              <Badge variant={performanceMetrics.revenueVariance >= 0 ? "default" : "destructive"} className="mt-2">
                {performanceMetrics.revenueVariance >= 0 ? '+' : ''}{performanceMetrics.revenueVariance.toFixed(1)}% vs target
              </Badge>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-medium text-gray-600">Blended CAC</span>
            </div>
            <p className="text-2xl font-bold text-purple-900">{formatCurrency(results.blendedCAC)}</p>
            {hasPerformanceData && performanceMetrics && (
              <p className="text-sm text-gray-600 mt-2">
                Actual: {formatCurrency(performanceMetrics.avgBlendedCAC)}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-4 w-4 text-orange-600" />
              <span className="text-sm font-medium text-gray-600">Distributor Share</span>
            </div>
            <p className="text-2xl font-bold text-orange-900">{formatCurrency(results.totalDistributorRevenue)}</p>
            <p className="text-sm text-gray-600 mt-2">{state.distributorShare}% of revenue</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Revenue Model Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Current Model</h4>
              <p className="text-sm text-gray-600 mb-1">
                {state.revenueModel === 'physician_funded' ? 'Physician-Funded Model' :
                 state.revenueModel === 'group_collective' ? 'Group Collective Model' :
                 state.revenueModel === 'distributor_funded' ? 'Distributor-Funded Model' : 'Custom Model'}
              </p>
              <p className="text-lg font-semibold">{formatCurrency(state.totalBudget)}/month budget</p>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Channel Allocation</h4>
              <p className="text-sm text-gray-600 mb-1">Digital: {state.digitalAllocation}%</p>
              <p className="text-sm text-gray-600 mb-1">OOH: {100 - state.digitalAllocation}%</p>
              <p className="text-lg font-semibold">Optimized Mix</p>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Revenue Split</h4>
              <p className="text-sm text-gray-600 mb-1">Distributor: {state.distributorShare}%</p>
              <p className="text-sm text-gray-600 mb-1">Provider: {state.providerShare}%</p>
              <p className="text-sm text-gray-600 mb-1">Manufacturer: {state.manufacturerShare}%</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {hasPerformanceData && performanceMetrics && (
        <Card>
          <CardHeader>
            <CardTitle>Performance Tracking Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Tracking Period</h4>
                <p className="text-2xl font-bold text-blue-900">{performanceMetrics.trackingPeriod}</p>
                <p className="text-sm text-gray-600">months of data</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Total Actual Revenue</h4>
                <p className="text-2xl font-bold text-green-900">{formatCurrency(performanceMetrics.totalActualRevenue)}</p>
                <p className="text-sm text-gray-600">{performanceMetrics.totalActualPatients} patients treated</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Performance Score</h4>
                <p className="text-2xl font-bold text-purple-900">
                  {((performanceMetrics.patientsVariance + performanceMetrics.revenueVariance) / 2).toFixed(1)}%
                </p>
                <p className="text-sm text-gray-600">vs. initial projections</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const renderFinancialAnalysis = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Revenue Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b">
              <span className="font-medium">Patient Treatment Reimbursement</span>
              <span className="text-lg font-bold">{formatCurrency(results.patientRevenue)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span>Total Monthly Revenue</span>
              <span className="text-lg font-semibold">{formatCurrency(results.totalMonthlyRevenue)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span>Annual Revenue Projection</span>
              <span className="text-lg font-semibold">{formatCurrency(results.totalMonthlyRevenue * 12)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Cost Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b">
              <span>Digital Marketing Spend</span>
              <span>{formatCurrency(state.digitalSpendOnImpressions)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span>OOH Marketing Spend</span>
              <span>{formatCurrency(state.oohSpendOnImpressions)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span className="font-medium">Total Marketing Investment</span>
              <span className="text-lg font-bold">{formatCurrency(state.digitalSpendOnImpressions + state.oohSpendOnImpressions)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b">
              <span className="font-medium">Marketing ROI</span>
              <span className="text-lg font-bold">{formatNumber(results.totalMonthlyRevenue / (state.digitalSpendOnImpressions + state.oohSpendOnImpressions))}x</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderMarketingPerformance = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Digital Channel Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Impressions</span>
                <span className="font-medium">{formatNumber(state.digitalImpressions)}</span>
              </div>
              <div className="flex justify-between">
                <span>Clicks</span>
                <span className="font-medium">{formatNumber(results.digitalClicks)}</span>
              </div>
              <div className="flex justify-between">
                <span>Leads</span>
                <span className="font-medium">{formatNumber(results.digitalLeads)}</span>
              </div>
              <div className="flex justify-between">
                <span>Appointments</span>
                <span className="font-medium">{formatNumber(results.digitalAppointments)}</span>
              </div>
              <div className="flex justify-between border-t pt-2">
                <span className="font-semibold">Patients</span>
                <span className="font-bold text-blue-600">{formatNumber(results.digitalPatients)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold">CAC</span>
                <span className="font-bold">{formatCurrency(results.digitalCAC)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>OOH Channel Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Impressions</span>
                <span className="font-medium">{formatNumber(state.oohImpressions)}</span>
              </div>
              <div className="flex justify-between">
                <span>Responses</span>
                <span className="font-medium">{formatNumber(results.oohResponses)}</span>
              </div>
              <div className="flex justify-between">
                <span>Leads</span>
                <span className="font-medium">{formatNumber(results.oohLeads)}</span>
              </div>
              <div className="flex justify-between">
                <span>Appointments</span>
                <span className="font-medium">{formatNumber(results.oohAppointments)}</span>
              </div>
              <div className="flex justify-between border-t pt-2">
                <span className="font-semibold">Patients</span>
                <span className="font-bold text-green-600">{formatNumber(results.oohPatients)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold">CAC</span>
                <span className="font-bold">{formatCurrency(results.oohCAC)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Report Configuration */}
      <Card data-testid="report-configuration">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Report Configuration
          </CardTitle>
        </CardHeader>
        <CardContent>

          {/* Auto-Generated Reports Section */}
          <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg border mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  <Calendar className="w-5 h-5 inline mr-2" />
                  Automated Report Scheduling
                </h3>
                <p className="text-sm text-gray-600">
                  Schedule reports to be automatically generated and delivered to reduce administrative burden
                </p>
              </div>
              <Switch 
                checked={autoReportsEnabled}
                onCheckedChange={setAutoReportsEnabled}
                data-testid="switch-auto-reports"
              />
            </div>

            {autoReportsEnabled && (
              <div className="mt-4 space-y-4">
                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-medium mb-3">Create New Scheduled Report</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div>
                      <Label htmlFor="schedule-report-type">Report Type</Label>
                      <Select defaultValue="executive-summary">
                        <SelectTrigger data-testid="select-schedule-report-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {reportTypes.map((type) => (
                            <SelectItem key={type.id} value={type.id}>
                              <div>
                                <div className="font-medium">{type.name}</div>
                                <div className="text-xs text-gray-500">{type.description}</div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="schedule-frequency">Frequency</Label>
                      <Select defaultValue="monthly">
                        <SelectTrigger data-testid="select-schedule-frequency">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {frequencyOptions.map((freq) => (
                            <SelectItem key={freq.id} value={freq.id}>
                              <div>
                                <div className="font-medium">{freq.name}</div>
                                <div className="text-xs text-gray-500">{freq.description}</div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="schedule-format">Format</Label>
                      <Select defaultValue="pdf">
                        <SelectTrigger data-testid="select-schedule-format">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {exportFormats.slice(0, 6).map((format) => (
                            <SelectItem key={format.id} value={format.id}>
                              <div>
                                <div className="font-medium">{format.name}</div>
                                <div className="text-xs text-gray-500">{format.description}</div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex flex-col justify-end">
                      <Button 
                        onClick={() => handleScheduleReport({
                          name: `Auto-Generated Report ${scheduledReports.length + 1}`,
                          frequency: 'monthly',
                          format: 'pdf',
                          email: true,
                          sms: false
                        })}
                        data-testid="button-add-scheduled-report"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Schedule Report
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="flex items-center space-x-2">
                      <Switch defaultChecked data-testid="switch-email-delivery" />
                      <Label>Email Delivery</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch data-testid="switch-sms-alerts" />
                      <Label>SMS Completion Alerts</Label>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-medium mb-3">Active Scheduled Reports</h4>
                  <div className="space-y-3">
                    {scheduledReports.map((report) => (
                      <div key={report.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center gap-3">
                            <Switch 
                              checked={report.enabled}
                              onCheckedChange={() => handleToggleScheduledReport(report.id)}
                              data-testid={`switch-report-${report.id}`}
                            />
                            <div>
                              <h5 className="font-medium">{report.name}</h5>
                              <div className="text-sm text-gray-600 flex items-center gap-4">
                                <span>{frequencyOptions.find(f => f.id === report.frequency)?.name} • {report.format.toUpperCase()}</span>
                                <span>Next: {report.nextRun}</span>
                                <div className="flex items-center gap-2">
                                  {report.email && <Badge variant="outline" className="text-xs">Email</Badge>}
                                  {report.sms && <Badge variant="outline" className="text-xs">SMS</Badge>}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleReportGeneration({
                              format: report.format,
                              reportType: 'scheduled',
                              name: report.name,
                              sms: report.sms,
                              email: report.email
                            })}
                            data-testid={`button-run-now-${report.id}`}
                          >
                            <RefreshCw className="w-4 h-4 mr-1" />
                            Run Now
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDeleteScheduledReport(report.id)}
                            data-testid={`button-delete-${report.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          <Separator className="my-6" />

          {/* Manual Report Generation */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Report Type</label>
              <Select value={selectedReportType} onValueChange={setSelectedReportType}>
                <SelectTrigger data-testid="select-report-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {reportTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Timeframe</label>
              <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                <SelectTrigger data-testid="select-timeframe">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {timeframes.map((timeframe) => (
                    <SelectItem key={timeframe.id} value={timeframe.id}>
                      {timeframe.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Export Format</label>
              <Select value={exportFormat} onValueChange={setExportFormat}>
                <SelectTrigger data-testid="select-export-format">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {exportFormats.map((format) => (
                    <SelectItem key={format.id} value={format.id}>
                      <div className="flex flex-col">
                        <span className="font-medium">{format.name}</span>
                        <span className="text-xs text-gray-500">{format.description}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg mt-4 mb-4">
            <h4 className="font-medium text-blue-900 mb-2">Medical Practice Software Integration</h4>
            <p className="text-sm text-blue-700 mb-2">
              Export formats are optimized for direct import into the most popular medical practice management systems:
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-blue-600">
              <span>• Epic Systems (30%+ market share)</span>
              <span>• athenahealth (28% market share)</span>
              <span>• Cerner/Oracle Health</span>
              <span>• NextGen Healthcare</span>
              <span>• eClinicalWorks</span>
              <span>• Allscripts</span>
              <span>• MEDITECH Expanse</span>
              <span>• QuickBooks (45% of practices)</span>
            </div>
            <p className="text-xs text-blue-600 mt-2">
              All formats are HIPAA-compliant and designed for seamless financial data integration.
            </p>
          </div>

          <div className="bg-green-50 p-4 rounded-lg mt-4 mb-4">
            <h4 className="font-medium text-green-900 mb-2">
              <RefreshCw className="w-4 h-4 inline mr-2" />
              Auto-Sync Technology
            </h4>
            <p className="text-sm text-green-700 mb-2">
              Click "Auto-Sync" to automatically push performance data to your practice management system via secure API integration:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-green-600">
              <span>• One-click financial data synchronization</span>
              <span>• Real-time API integration with major EMR systems</span>
              <span>• SMART on FHIR compliant for Epic & Cerner</span>
              <span>• Direct athenaCollector & QuickBooks API support</span>
            </div>
            <p className="text-xs text-green-600 mt-2 font-medium">
              Note: API credentials required for auto-sync functionality. Contact your IT administrator for setup.
            </p>
          </div>

          <div className="flex gap-3 mt-4">
            <Button 
              onClick={() => handleExportReport(exportFormat, selectedReportType)}
              data-testid="button-export-report"
            >
              <Download className="h-4 w-4 mr-2" />
              Export for {exportFormats.find(f => f.id === exportFormat)?.name.split(' ')[0] || 'Download'}
            </Button>
            <Button 
              variant="default" 
              className="bg-green-600 hover:bg-green-700"
              onClick={() => handleAutoSync(exportFormat)}
              data-testid="button-auto-sync"
            >
              <Calculator className="h-4 w-4 mr-2" />
              Auto-Sync to {exportFormats.find(f => f.id === exportFormat)?.name.split(' ')[0] || 'System'}
            </Button>
            <Button variant="outline" data-testid="button-preview-report">
              <Eye className="h-4 w-4 mr-2" />
              Preview
            </Button>
            <Button variant="outline" data-testid="button-email-report">
              <Mail className="h-4 w-4 mr-2" />
              Email Report
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Report Content */}
      <Card data-testid="report-content">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>
              {reportTypes.find(type => type.id === selectedReportType)?.name} Report
            </CardTitle>
            <Badge variant="outline">
              {timeframes.find(tf => tf.id === selectedTimeframe)?.name}
            </Badge>
          </div>
          <p className="text-sm text-gray-600">
            {reportTypes.find(type => type.id === selectedReportType)?.description}
          </p>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedReportType} onValueChange={setSelectedReportType}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="executive-summary">Executive</TabsTrigger>
              <TabsTrigger value="financial-analysis">Financial</TabsTrigger>
              <TabsTrigger value="marketing-performance">Marketing</TabsTrigger>
            </TabsList>
            
            <TabsContent value="executive-summary" className="mt-6">
              {renderExecutiveSummary()}
            </TabsContent>
            
            <TabsContent value="financial-analysis" className="mt-6">
              {renderFinancialAnalysis()}
            </TabsContent>
            
            <TabsContent value="marketing-performance" className="mt-6">
              {renderMarketingPerformance()}
            </TabsContent>
            
            <TabsContent value="variance-analysis" className="mt-6">
              {hasPerformanceData ? (
                <div className="text-center py-8">
                  <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Variance Analysis</h3>
                  <p className="text-gray-600">
                    Based on {performanceMetrics?.trackingPeriod} months of actual performance data
                  </p>
                </div>
              ) : (
                <div className="text-center py-8">
                  <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No Performance Data</h3>
                  <p className="text-gray-600 mb-4">
                    Enable Performance Tracking to see variance analysis
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="distributor-report" className="mt-6">
              <div className="text-center py-8">
                <PieChart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Distributor Report</h3>
                <p className="text-gray-600">
                  Partner-focused revenue sharing analysis
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="clinical-metrics" className="mt-6">
              <div className="text-center py-8">
                <LineChart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Clinical Metrics</h3>
                <p className="text-gray-600">
                  Patient outcomes and treatment effectiveness data
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}