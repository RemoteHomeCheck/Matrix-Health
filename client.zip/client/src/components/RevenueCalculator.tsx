import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calculator, DollarSign, Users, TrendingUp, BarChart3, Clock, Target, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { CalculatorState, CalculatorResults } from "@shared/schema";
import { formatCurrency, formatNumber, formatLargeNumber } from "@/lib/calculations";

interface RevenueCalculatorProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export default function RevenueCalculator({ state, results, onUpdate }: RevenueCalculatorProps) {
  const handleInputChange = (field: keyof CalculatorState, value: string) => {
    const numValue = parseFloat(value) || 0;
    onUpdate({ [field]: numValue });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Input Parameters Card */}
      <div className="lg:col-span-1">
        <Card data-testid="input-parameters-card">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Input Parameters</span>
              <Calculator className="w-5 h-5 text-gray-400" />
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Medicare Treatment Parameters */}
            <div className="bg-blue-50 p-4 rounded-lg space-y-4">
              <h4 className="font-medium text-primary mb-3">Medicare Treatment</h4>
              
              <div>
                <Label htmlFor="reimbursement-per-cm">
                  Reimbursement per sq cm
                  <span className="text-gray-400 ml-1" title="Medicare standard rate">ⓘ</span>
                </Label>
                <div className="relative mt-1">
                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                  <Input
                    id="reimbursement-per-cm"
                    type="number"
                    value={state.reimbursementPerCm}
                    onChange={(e) => handleInputChange('reimbursementPerCm', e.target.value)}
                    className="pl-8"
                    data-testid="input-reimbursement"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="treatment-length">Length (cm)</Label>
                  <Input
                    id="treatment-length"
                    type="number"
                    value={state.treatmentLength}
                    onChange={(e) => handleInputChange('treatmentLength', e.target.value)}
                    data-testid="input-length"
                  />
                </div>
                <div>
                  <Label htmlFor="treatment-width">Width (cm)</Label>
                  <Input
                    id="treatment-width"
                    type="number"
                    value={state.treatmentWidth}
                    onChange={(e) => handleInputChange('treatmentWidth', e.target.value)}
                    data-testid="input-width"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="include-followup">
                  <input
                    id="include-followup"
                    type="checkbox"
                    checked={state.includeFollowUp}
                    onChange={(e) => handleInputChange('includeFollowUp', e.target.checked ? '1' : '0')}
                    className="mr-2"
                    data-testid="checkbox-include-followup"
                  />
                  Include Follow-up Dressing Fees
                  <span className="text-gray-400 ml-1" title="$500/week for redressing">ⓘ</span>
                </Label>
              </div>

              <div>
                <Label htmlFor="digital-lead-conv">
                  Digital Lead Conversion Rate
                  <span className="text-gray-400 ml-1" title="Ken's actual: 0.2%, Market benchmark: 0.4%">ⓘ</span>
                </Label>
                <div className="relative mt-1">
                  <Input
                    id="digital-lead-conv"
                    type="number"
                    step="0.1"
                    value={state.digitalLeadConv}
                    onChange={(e) => handleInputChange('digitalLeadConv', e.target.value)}
                    className="pr-8"
                    data-testid="input-digital-lead-conv"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Ken's actual: 0.2% | Market benchmark: 0.4%
                </p>
              </div>

              <div>
                <Label htmlFor="treatment-duration">Treatment Duration (weeks)</Label>
                <Input
                  id="treatment-duration"
                  type="number"
                  value={state.treatmentDuration}
                  onChange={(e) => handleInputChange('treatmentDuration', e.target.value)}
                  data-testid="input-duration"
                />
              </div>
            </div>

            {/* Revenue Share Parameters */}
            <div className="bg-green-50 p-4 rounded-lg space-y-4">
              <h4 className="font-medium text-secondary mb-3">Revenue Share</h4>
              
              <div>
                <Label htmlFor="distributor-share">Distributor Share</Label>
                <div className="relative mt-1">
                  <Input
                    id="distributor-share"
                    type="number"
                    value={state.distributorShare}
                    onChange={(e) => handleInputChange('distributorShare', e.target.value)}
                    className="pr-8"
                    data-testid="input-distributor-share"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
              </div>

              <div>
                <Label htmlFor="provider-share">Provider Share</Label>
                <div className="relative mt-1">
                  <Input
                    id="provider-share"
                    type="number"
                    value={state.providerShare}
                    onChange={(e) => handleInputChange('providerShare', e.target.value)}
                    className="pr-8"
                    data-testid="input-provider-share"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
              </div>

              <div>
                <Label htmlFor="manufacturer-share">Manufacturer Share</Label>
                <div className="relative mt-1">
                  <Input
                    id="manufacturer-share"
                    type="number"
                    value={state.manufacturerShare}
                    onChange={(e) => handleInputChange('manufacturerShare', e.target.value)}
                    className="pr-8"
                    data-testid="input-manufacturer-share"
                  />
                  <span className="absolute right-3 top-3 text-gray-500">%</span>
                </div>
              </div>

              {/* Group Size Input - Show when Group Collective model is selected */}
              {state.revenueModel === 'group_collective' && (
                <div className="bg-blue-50 p-3 rounded border">
                  <Label htmlFor="group-size">
                    Number of Doctors in Collective
                    <span className="text-gray-400 ml-1" title="Total number of doctors pooling resources together">ⓘ</span>
                  </Label>
                  <Input
                    id="group-size"
                    type="number"
                    min="2"
                    max="20"
                    value={state.groupSize}
                    onChange={(e) => handleInputChange('groupSize', e.target.value)}
                    className="mt-1"
                    data-testid="input-group-size"
                  />
                  <p className="text-xs text-gray-600 mt-1">
                    Costs and revenue will be calculated per doctor in the collective
                  </p>
                </div>
              )}
            </div>


          </CardContent>
        </Card>
      </div>

      {/* Results Display */}
      <div className="lg:col-span-2 space-y-6">
        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-l-4 border-l-primary" data-testid="treatment-value-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Treatment Value</p>
                  <p className="text-2xl font-bold text-primary" data-testid="text-treatment-value">
                    {formatCurrency(results.treatmentValue)}
                  </p>
                  <p className="text-xs text-gray-500">
                    {state.treatmentLength * state.treatmentWidth} sq cm @ ${formatLargeNumber(state.reimbursementPerCm)}/cm
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <DollarSign className="text-primary text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-secondary" data-testid="patient-revenue-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Patient Treatment Reimbursement</p>
                  <p className="text-2xl font-bold text-secondary" data-testid="text-patient-treatment-reimbursement">
                    {formatCurrency(results.patientTreatmentReimbursement)}
                  </p>
                  <p className="text-xs text-gray-500">
                    Graft: {formatCurrency(results.treatmentValue)} + Dressings: {formatCurrency(results.patientTreatmentReimbursement - results.treatmentValue)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center">
                  <Users className="text-secondary text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-orange-500" data-testid="manufacturer-revenue-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Manufacturer Revenue</p>
                  <p className="text-2xl font-bold text-orange-600" data-testid="text-manufacturer-revenue">
                    {formatCurrency(results.manufacturerRevenue)}
                  </p>
                  <p className="text-xs text-gray-500">
                    {state.manufacturerShare}% of {formatCurrency(results.patientTreatmentReimbursement)} total
                  </p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="text-orange-600 text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-teal-500" data-testid="provider-revenue-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Provider Revenue</p>
                  <p className="text-2xl font-bold text-teal-600" data-testid="text-provider-revenue">
                    {formatCurrency(results.doctorRevenue)}
                  </p>
                  <p className="text-xs text-gray-500">
                    {state.providerShare}% of {formatCurrency(results.patientTreatmentReimbursement)} total
                  </p>
                </div>
                <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="text-teal-600 text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-accent" data-testid="distributor-revenue-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Distributor Revenue</p>
                  <p className="text-2xl font-bold text-accent" data-testid="text-distributor-revenue">
                    {formatCurrency(results.distributorRevenue)}
                  </p>
                  <p className="text-xs text-gray-500">
                    {state.distributorShare}% of {formatCurrency(results.patientTreatmentReimbursement)} total
                  </p>
                </div>
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center">
                  <TrendingUp className="text-accent text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Revenue Breakdown Table */}
        <Card data-testid="revenue-breakdown-table">
          <CardHeader className="bg-gray-50">
            <CardTitle>Revenue Breakdown Analysis</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Metric
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Value
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      % of Total
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Patient Treatment Reimbursement (Total)
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                      {formatCurrency(results.patientTreatmentReimbursement)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">
                      100%
                    </td>
                  </tr>
                  <tr className="bg-blue-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-primary">
                      Provider Revenue ({state.providerShare}%)
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-primary text-right font-mono">
                      {formatCurrency(results.doctorRevenue)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-primary text-right">
                      {state.providerShare}%
                    </td>
                  </tr>
                  <tr className="bg-green-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-secondary">
                      Distributor Revenue ({state.distributorShare}%)
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary text-right font-mono">
                      {formatCurrency(results.distributorRevenue)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary text-right">
                      {state.distributorShare}%
                    </td>
                  </tr>
                  <tr className="bg-orange-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-accent">
                      Manufacturer Revenue ({state.manufacturerShare}%)
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-accent text-right font-mono">
                      {formatCurrency(results.manufacturerRevenue)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-accent text-right">
                      {state.manufacturerShare}%
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Analytics Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Clinical Economics Insights */}
          <Card data-testid="clinical-economics">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-600" />
                Clinical Economics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <TooltipProvider>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="text-sm font-medium text-blue-700">Treatment Duration</p>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="w-3 h-3 text-blue-600 cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="max-w-xs">Average treatment period for chronic wound management including follow-up care</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-lg font-bold text-blue-900">{state.treatmentDuration} weeks</p>
                    <p className="text-xs text-blue-600">vs 52-week average</p>
                  </div>
                  
                  <div className="bg-green-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="text-sm font-medium text-green-700">Cost per Week</p>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="w-3 h-3 text-green-600 cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="max-w-xs">Weekly treatment cost including dressing changes and monitoring</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-lg font-bold text-green-900">
                      {formatCurrency(results.patientTreatmentReimbursement / Math.max(state.treatmentDuration, 1))}
                    </p>
                    <p className="text-xs text-green-600">accelerated healing</p>
                  </div>
                  
                  <div className="bg-purple-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="text-sm font-medium text-purple-700">Graft Efficiency</p>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="w-3 h-3 text-purple-600 cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="max-w-xs">Reimbursement per square cm of graft applied</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-lg font-bold text-purple-900">
                      {formatCurrency(state.reimbursementPerCm)}/cm²
                    </p>
                    <p className="text-xs text-purple-600">Medicare rate</p>
                  </div>
                  
                  <div className="bg-orange-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="text-sm font-medium text-orange-700">Total Area</p>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="w-3 h-3 text-orange-600 cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="max-w-xs">Total wound surface area requiring graft coverage</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-lg font-bold text-orange-900">
                      {formatNumber(state.treatmentLength * state.treatmentWidth)} cm²
                    </p>
                    <p className="text-xs text-orange-600">{state.treatmentLength}×{state.treatmentWidth}</p>
                  </div>
                </div>
              </TooltipProvider>
            </CardContent>
          </Card>

          {/* Industry Benchmarks */}
          <Card data-testid="industry-benchmarks">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-green-600" />
                Industry Benchmarks
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">Chronic Wound Prevalence</p>
                    <p className="text-sm text-gray-600">US population affected</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-blue-600">2.5%</p>
                    <p className="text-xs text-gray-500">~8.3M patients</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">Medicare Population</p>
                    <p className="text-sm text-gray-600">Beneficiaries with chronic wounds</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-green-600">16.4%</p>
                    <p className="text-xs text-gray-500">10.7M patients</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">Treatment Duration</p>
                    <p className="text-sm text-gray-600">Average management period</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-orange-600">12-13 mo</p>
                    <p className="text-xs text-gray-500">vs {state.treatmentDuration}wk graft</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">Recurrence Rate</p>
                    <p className="text-sm text-gray-600">Wounds that return</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-purple-600">60-70%</p>
                    <p className="text-xs text-gray-500">repeat revenue</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Revenue Impact Analysis */}
        <Card data-testid="revenue-impact-analysis">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-600" />
              Economic Impact vs Traditional Care
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-red-50 to-red-100 p-4 rounded-lg border border-red-200">
                <h4 className="font-semibold text-red-800 mb-3">Traditional Wound Care</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-red-700">Duration:</span>
                    <span className="font-medium text-red-900">12-13 months</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-red-700">Weekly Cost:</span>
                    <span className="font-medium text-red-900">~$300-500</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-red-700">Total Cost:</span>
                    <span className="font-medium text-red-900">$15K-26K</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-red-700">Healing Rate:</span>
                    <span className="font-medium text-red-900">65-75%</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg border border-green-200">
                <h4 className="font-semibold text-green-800 mb-3">Dermal Graft Treatment</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-green-700">Duration:</span>
                    <span className="font-medium text-green-900">{state.treatmentDuration} weeks</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-green-700">Weekly Cost:</span>
                    <span className="font-medium text-green-900">
                      {formatCurrency(results.patientTreatmentReimbursement / Math.max(state.treatmentDuration, 1))}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-green-700">Total Cost:</span>
                    <span className="font-medium text-green-900">{formatCurrency(results.patientTreatmentReimbursement)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-green-700">Healing Rate:</span>
                    <span className="font-medium text-green-900">85-95%</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg border border-blue-200">
                <h4 className="font-semibold text-blue-800 mb-3">Cost Comparison</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-blue-700">Time Saved:</span>
                    <span className="font-medium text-blue-900">
                      {Math.max(0, 52 - state.treatmentDuration)} weeks
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-blue-700">Cost Efficiency:</span>
                    <span className="font-medium text-blue-900">
                      {((results.patientTreatmentReimbursement / 20000 - 1) * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-blue-700">Better Outcomes:</span>
                    <span className="font-medium text-blue-900">+15-20%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-blue-700">Patient Quality:</span>
                    <span className="font-medium text-blue-900">Significantly ↑</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
