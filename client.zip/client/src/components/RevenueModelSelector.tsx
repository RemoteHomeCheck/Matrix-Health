import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DollarSign, Users, Handshake } from "lucide-react";
import { CalculatorResults } from "@shared/schema";
import { formatCurrency, formatNumber } from "@/lib/calculations";

interface RevenueModel {
  name: string;
  description: string;
  totalBudget: number;
  distributorShare: number;
  providerShare: number;
  manufacturerShare: number;
  [key: string]: any;
}

interface RevenueModelSelectorProps {
  currentModel: string;
  onModelSelect: (model: 'physician_funded' | 'group_collective' | 'distributor_funded') => void;
  revenueModels: Record<string, RevenueModel>;
  results: CalculatorResults;
  onGroupSizeChange?: (size: number) => void;
  groupSize?: number;
}

export function RevenueModelSelector({ currentModel, onModelSelect, revenueModels, results, onGroupSizeChange, groupSize = 3 }: RevenueModelSelectorProps) {
  const models = [
    {
      id: 'physician_funded' as const,
      icon: DollarSign,
      title: 'Physician-Funded',
      budget: '$7,500/mo',
      highlight: 'Doctor pays marketing',
      description: 'Solo practitioner covers all marketing costs'
    },
    {
      id: 'group_collective' as const,
      icon: Users,
      title: 'Group Collective',
      budget: '$10,000/mo',
      highlight: 'Shared marketing pool',
      description: 'Multiple practitioners pool marketing budget'
    },
    {
      id: 'distributor_funded' as const,
      icon: Handshake,
      title: 'Distributor-Funded',
      budget: '$7,500/mo',
      highlight: 'Zero cost to doctor',
      description: 'Distributor covers marketing, higher revenue share'
    }
  ];

  return (
    <div className="mb-8">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-primary" />
            Revenue Models for Solo Practitioners
          </CardTitle>
          <p className="text-sm text-gray-600">
            Choose between three different funding structures for solo practitioners
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            {models.map((model) => {
              const Icon = model.icon;
              const isActive = currentModel === model.id;
              const modelData = revenueModels[model.id];
              
              return (
                <div
                  key={model.id}
                  className={`relative border-2 rounded-lg p-4 cursor-pointer transition-all ${
                    isActive 
                      ? 'border-primary bg-primary/5 shadow-md' 
                      : 'border-gray-200 hover:border-primary/50'
                  }`}
                  onClick={() => onModelSelect(model.id)}
                  data-testid={`model-${model.id}`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${isActive ? 'bg-primary text-white' : 'bg-gray-100'}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-sm">{model.title}</h3>
                      <p className="text-xs text-gray-600 mb-2">{model.description}</p>
                      
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span>Suggested Monthly Budget:</span>
                          <span className="font-medium">{model.budget}</span>
                        </div>
                      </div>
                      
                      <Badge 
                        variant={isActive ? "default" : "secondary"} 
                        className="text-xs mt-2"
                      >
                        {model.highlight}
                      </Badge>
                    </div>
                  </div>
                  
                  {isActive && (
                    <div className="absolute top-2 right-2">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Group Size Input - Show when Group Collective model is selected */}
          {currentModel === 'group_collective' && (
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-blue-600" />
                <Label htmlFor="group-size-selector" className="font-medium text-blue-900">
                  Number of Doctors in Collective
                </Label>
              </div>
              <Input
                id="group-size-selector"
                type="number"
                min="2"
                max="20"
                value={groupSize}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  const newSize = parseInt(e.target.value) || 3;
                  if (onGroupSizeChange) {
                    onGroupSizeChange(newSize);
                  }
                }}
                className="w-32"
                data-testid="input-group-size-selector"
              />
              <p className="text-xs text-blue-700 mt-2">
                💡 Marketing costs and revenue projections will be calculated per doctor
              </p>
            </div>
          )}

          {/* Quick Comparison */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-sm mb-3">Current Model Performance</h4>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
              <div>
                <div className="text-lg font-bold text-primary">
                  {formatNumber(results.totalPatients)}
                </div>
                <div className="text-xs text-gray-600">Patients/Month</div>
              </div>
              <div>
                <div className="text-lg font-bold text-green-600">
                  {formatCurrency(results.totalDistributorRevenue)}
                </div>
                <div className="text-xs text-gray-600">Distributor Revenue</div>
              </div>
              <div>
                <div className="text-lg font-bold text-orange-600">
                  {formatCurrency(results.manufacturerRevenue)}
                </div>
                <div className="text-xs text-gray-600">Mfr Revenue</div>
              </div>
              <div>
                <div className="text-lg font-bold text-teal-600">
                  {formatCurrency(results.doctorRevenue)}
                </div>
                <div className="text-xs text-gray-600">Provider Revenue</div>
              </div>
              <div>
                <div className="text-lg font-bold text-secondary">
                  {formatCurrency(results.patientTreatmentReimbursement)}
                </div>
                <div className="text-xs text-gray-600">Patient Treatment Reimbursement</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}