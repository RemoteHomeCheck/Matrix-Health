import { useState, useCallback } from "react";
import { CalculatorState, CalculatorResults } from "@shared/schema";
import { calculateResults } from "@/lib/calculations";

// Revenue models for solo practitioners with different funding structures
const REVENUE_MODELS = {
  physician_funded: {
    name: "Physician-Funded Model",
    description: "Solo practitioner pays $7,500/mo, distributor gets 15%",
    digitalImpressions: 450000, // $7,500 split across channels
    digitalSpendOnImpressions: 3758, // 450k × $8.35 CPM
    oohImpressions: 450000,
    oohSpendOnImpressions: 5400, // 450k × $12.00 CPM
    totalBudget: 7500,
    digitalAllocation: 41,
    distributorShare: 15,
    providerShare: 50,
    manufacturerShare: 35,
    digitalCtr: 1.2,
    oohResponse: 0.07,
    digitalLeadConv: 1.0,
    oohLeadConv: 8.5,
    digitalApptConv: 7.5,
    oohApptConv: 7.5,
    digitalPatientConv: 60,
    oohPatientConv: 55
  },
  group_collective: {
    name: "Group Collective Model", 
    description: "Solo practitioners pool together for $10,000/mo collective spend",
    digitalImpressions: 598000, // $10,000 split across channels
    digitalSpendOnImpressions: 4993, // 598k × $8.35 CPM
    oohImpressions: 598000,
    oohSpendOnImpressions: 7176, // 598k × $12.00 CPM
    totalBudget: 10000,
    digitalAllocation: 41,
    distributorShare: 15,
    providerShare: 50,
    manufacturerShare: 35,
    digitalCtr: 1.2,
    oohResponse: 0.07,
    digitalLeadConv: 1.0,
    oohLeadConv: 8.5,
    digitalApptConv: 7.5,
    oohApptConv: 7.5,
    digitalPatientConv: 60,
    oohPatientConv: 55
  },
  distributor_funded: {
    name: "Distributor-Funded Model",
    description: "Distributor pays all marketing, physician pays $0, distributor gets 25%",
    digitalImpressions: 450000, // Same volume as physician-funded
    digitalSpendOnImpressions: 3758,
    oohImpressions: 450000,
    oohSpendOnImpressions: 5400,
    totalBudget: 7500,
    digitalAllocation: 41,
    distributorShare: 25, // Higher share for taking marketing risk
    providerShare: 40, // Reduced since they pay nothing
    manufacturerShare: 35,
    digitalCtr: 1.2,
    oohResponse: 0.07,
    digitalLeadConv: 1.0,
    oohLeadConv: 8.5,
    digitalApptConv: 7.5,
    oohApptConv: 7.5,
    digitalPatientConv: 60,
    oohPatientConv: 55
  }
};

const defaultState: CalculatorState = {
  // Medicare Treatment Parameters
  reimbursementPerCm: 2500,
  treatmentLength: 4,
  treatmentWidth: 4,
  treatmentDuration: 6,
  includeFollowUp: true, // Include follow-up dressing fees by default
  
  // Revenue Share Parameters
  distributorShare: 15,
  providerShare: 50,
  manufacturerShare: 35,
  

  
  // Digital Marketing Parameters (Ken's real-world data: 1 customer from 16,000 impressions)
  digitalImpressions: 300000, // $2,500 ÷ $8.35 CPM = ~300k impressions
  digitalCtr: 1.2, // Market benchmark: 0.8-1.5% for healthcare digital
  digitalLeadConv: 1.0, // Default: 1% (between Ken's 0.2% and market 0.4%)
  digitalApptConv: 7.5, // Market benchmark: 5-10% with concierge support
  digitalPatientConv: 60, // Pre-qualified Plan B rate: 50-70%
  digitalCpm: 8.35, // Digital marketing CPM (adjustable)
  
  // OOH Marketing Parameters (market-rate benchmarks Q4-2024/Q1-2025)
  oohImpressions: 208000, // $2,500 ÷ $12.00 CPM = ~208k impressions
  oohResponse: 0.07, // Market benchmark: 0.04-0.1% for health-targeted OOH
  oohLeadConv: 8.5, // Market benchmark: 5-12% for OOH responses
  oohApptConv: 7.5, // Consistent with digital concierge rate
  oohPatientConv: 55, // Slightly lower than digital due to less targeting
  oohCpm: 12.00, // OOH marketing CPM (adjustable)
  
  // Multi-Year Growth Assumptions
  growthYear1: 5,
  growthYear23: 3,
  growthYear45: 1.5,
  
  // Optimization Over Time (industry-typical improvement rates)
  conversionOptimization: 15, // 15% annual improvement in conversion rates
  cacImprovementRate: 12, // 12% annual CAC improvement
  maxConversionCeiling: 300, // 3x max improvement cap (prevents sci-fi projections)
  
  // Revenue Model
  revenueModel: 'custom' as const,
  
  // Group Collective Parameters
  groupSize: 3, // Default to 3 doctors in a group collective
  
  // Data Source (Ken's actual vs market benchmarks)
  useKenData: false, // Default to market benchmarks
  
  // Budget Optimization
  totalBudget: 50000,
  digitalAllocation: 70,
  
  // Impression Spend Tracking (realistic CPM calculations)
  digitalSpendOnImpressions: 2505, // 300k impressions × $8.35 CPM
  oohSpendOnImpressions: 2496, // 208k impressions × $12.00 CPM
  
  // Real-Time Performance Tracking
  enablePerformanceTracking: false,
  actualPerformanceData: [],
};

export const useCalculator = () => {
  const [state, setState] = useState<CalculatorState>(defaultState);
  const [results, setResults] = useState<CalculatorResults>(() => calculateResults(defaultState));

  const updateState = useCallback((updates: Partial<CalculatorState>) => {
    setState(prevState => {
      const newState = { ...prevState, ...updates };
      const newResults = calculateResults(newState);
      setResults(newResults);
      return newState;
    });
  }, []);

  const resetToDefaults = useCallback(() => {
    setState(defaultState);
    setResults(calculateResults(defaultState));
  }, []);

  const applyRevenueModel = useCallback((model: keyof typeof REVENUE_MODELS) => {
    const preset = REVENUE_MODELS[model];
    const newState = { ...state, ...preset, revenueModel: model };
    setState(newState);
    setResults(calculateResults(newState));
  }, [state]);

  return {
    state,
    results,
    updateState,
    resetToDefaults,
    applyRevenueModel,
    revenueModels: REVENUE_MODELS
  };
};
