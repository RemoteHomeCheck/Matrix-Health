import { CalculatorState, CalculatorResults } from "@shared/schema";
import { CALCULATION_CONSTANTS } from "./constants";
import { FriendlyError, sumGeometric, calcPayback } from "./helpers";

export const calculateResults = (state: CalculatorState): CalculatorResults => {
  // 1. Revenue Split Validation with improved friendly error messages
  const pctSum = state.distributorShare + state.providerShare + state.manufacturerShare;
  if (Math.abs(pctSum - 100) > CALCULATION_CONSTANTS.REVENUE_SPLIT_TOLERANCE) {
    const friendlyMessage = `Please adjust the Distributor, Provider, and Manufacturer percentages so they total 100%. Currently they total ${pctSum.toFixed(1)}%.`;
    throw new FriendlyError(friendlyMessage, `Revenue shares must add to 100% (currently ${pctSum.toFixed(1)}%)`);
  }

  // Treatment Value Calculations (Fixed: CMS pays per graft, not per week)
  const treatmentArea = state.treatmentLength * state.treatmentWidth;
  const treatmentValue = treatmentArea * state.reimbursementPerCm; // One-time graft payment
  const followUpDressingFee = CALCULATION_CONSTANTS.FOLLOW_UP_DRESSING_FEE;
  
  // Guard against edge case: minimum 1 follow-up week, maximum reasonable duration
  const followUpWeeks = Math.max(0, Math.min(state.treatmentDuration - 1, CALCULATION_CONSTANTS.MAX_FOLLOW_UP_WEEKS));
  const followUpRevenue = state.includeFollowUp ? followUpDressingFee * followUpWeeks : 0;
  const patientTreatmentReimbursement = treatmentValue + followUpRevenue; // Total per patient
  const grossRevenue = patientTreatmentReimbursement;
  
  // Revenue Shares (Patient Treatment Reimbursement split)
  const distributorRevenue = patientTreatmentReimbursement * (state.distributorShare / 100);
  const doctorRevenue = patientTreatmentReimbursement * (state.providerShare / 100);
  const manufacturerRevenue = patientTreatmentReimbursement * (state.manufacturerShare / 100);
  
  // FIXED: Verification that total split equals Patient Treatment Reimbursement
  const totalSplit = distributorRevenue + doctorRevenue + manufacturerRevenue;
  if (Math.abs(totalSplit - patientTreatmentReimbursement) > CALCULATION_CONSTANTS.CALCULATION_EPSILON) {
    throw new Error(`Revenue split calculation error: ${totalSplit.toFixed(2)} ≠ ${patientTreatmentReimbursement.toFixed(2)}`);
  }
  
  // Digital Channel Calculations
  const digitalClicks = state.digitalImpressions * (state.digitalCtr / 100);
  const digitalLeads = digitalClicks * (state.digitalLeadConv / 100);
  const digitalAppointments = digitalLeads * (state.digitalApptConv / 100);
  const digitalPatients = digitalAppointments * (state.digitalPatientConv / 100);
  const digitalChannelRevenue = digitalPatients * patientTreatmentReimbursement;
  
  // OOH Channel Calculations
  const oohResponses = state.oohImpressions * (state.oohResponse / 100);
  const oohLeads = oohResponses * (state.oohLeadConv / 100);
  const oohAppointments = oohLeads * (state.oohApptConv / 100);
  const oohPatients = oohAppointments * (state.oohPatientConv / 100);
  const oohChannelRevenue = oohPatients * patientTreatmentReimbursement;
  
  // Combined Results
  const totalPatients = digitalPatients + oohPatients;
  const totalMonthlyRevenue = digitalChannelRevenue + oohChannelRevenue;
  const totalDistributorRevenue = totalMonthlyRevenue * (state.distributorShare / 100);
  
  // Cost Analysis (using actual spend on impressions)
  const digitalCost = state.digitalSpendOnImpressions;
  const oohCost = state.oohSpendOnImpressions;
  
  // FIXED: Calculate effective CPM rates from spend with division-by-zero protection
  const digitalEffectiveCPM = state.digitalImpressions > 0 ? 
    (digitalCost / (state.digitalImpressions / 1000)) : null;
  const oohEffectiveCPM = state.oohImpressions > 0 ? 
    (oohCost / (state.oohImpressions / 1000)) : null;
  
  const digitalCostPerPatient = digitalPatients > 0 ? digitalCost / digitalPatients : 
    (digitalCost > 0 ? null : 0); // null for impossible scenarios (cost but no patients)
  const oohCostPerPatient = oohPatients > 0 ? oohCost / oohPatients : 
    (oohCost > 0 ? null : 0);
  
  // Enhanced ROI calculations with improved null handling for UI compatibility
  const digitalROI = digitalCost > 0 ? ((digitalChannelRevenue - digitalCost) / digitalCost) * 100 : 
    (digitalChannelRevenue > 0 ? null : 0); // null for infinite ROI (revenue with no cost)
  const oohROI = oohCost > 0 ? ((oohChannelRevenue - oohCost) / oohCost) * 100 : 
    (oohChannelRevenue > 0 ? null : 0);
  const blendedROI = (digitalCost + oohCost) > 0 ? ((totalMonthlyRevenue - digitalCost - oohCost) / (digitalCost + oohCost)) * 100 : 
    (totalMonthlyRevenue > 0 ? null : 0);
  
  // Enhanced Payback Period Calculations using improved helper function
  const digitalMonthlyDistributorRevenue = digitalChannelRevenue * (state.distributorShare / 100);
  const oohMonthlyDistributorRevenue = oohChannelRevenue * (state.distributorShare / 100);
  
  const digitalPaybackMonths = calcPayback(digitalCost, digitalMonthlyDistributorRevenue);
  const oohPaybackMonths = calcPayback(oohCost, oohMonthlyDistributorRevenue);
  const blendedPaybackMonths = calcPayback(digitalCost + oohCost, totalDistributorRevenue);
  
  // Multi-Year Projections with Optimization
  const baseMonthlyPatients = totalPatients;
  let cumulativeYear1Patients = 0;
  let cumulativeYear1Revenue = 0;
  
  // Convert annual growth to monthly rate for proper compound calculation
  const monthlyGrowthRate = Math.pow(1 + (state.growthYear1 / 100), 1/12) - 1;
  
  // Year 1 calculation with monthly growth and optimization
  for (let month = 1; month <= 12; month++) {
    const monthlyGrowthFactor = Math.pow(1 + monthlyGrowthRate, month - 1); // Start from month 0
    // Conversion optimization: gradual improvement over the year
    const conversionImprovement = 1 + ((state.conversionOptimization / 100) * (month / 12));
    const monthlyPatients = baseMonthlyPatients * monthlyGrowthFactor * conversionImprovement;
    
    // Add market saturation cap to prevent sci-fi projections
    const maxMonthlyPatients = baseMonthlyPatients * CALCULATION_CONSTANTS.MAX_PATIENT_MULTIPLIER_DIGITAL;
    const cappedMonthlyPatients = Math.min(monthlyPatients, maxMonthlyPatients);
    
    const monthlyRevenue = cappedMonthlyPatients * patientTreatmentReimbursement;
    cumulativeYear1Patients += cappedMonthlyPatients;
    cumulativeYear1Revenue += monthlyRevenue;
  }
  
  // CRITICAL FIX: Year 3 projections using geometric series sum instead of end-rate multiplication
  const monthlyGrowthRate23 = Math.pow(1 + (state.growthYear23 / 100), 1/12) - 1;
  const year3ConversionBoost = Math.min(
    Math.pow(1 + (state.conversionOptimization / 100), 3),
    state.maxConversionCeiling / 100
  );
  
  // Calculate cumulative patients for months 13-36 using geometric series helper
  const year3MonthsCount = 24; // Months 13-36  
  const year3SumFactor = sumGeometric(monthlyGrowthRate23, year3MonthsCount);
  const year3BaseMonthly = baseMonthlyPatients * Math.pow(1 + monthlyGrowthRate, 12); // End of Year 1 rate
  const cumulativeYear23Patients = year3BaseMonthly * year3ConversionBoost * year3SumFactor;
  const year3Patients = cumulativeYear1Patients + cumulativeYear23Patients;
  const year3Revenue = year3Patients * patientTreatmentReimbursement;
  
  // CRITICAL FIX: Year 5 projections using geometric series sum
  const monthlyGrowthRate45 = Math.pow(1 + (state.growthYear45 / 100), 1/12) - 1;
  const year5ConversionBoost = Math.min(
    Math.pow(1 + (state.conversionOptimization / 100), 5),
    state.maxConversionCeiling / 100
  );
  
  // Calculate cumulative patients for months 37-60 using geometric series helper
  const year5MonthsCount = 24; // Months 37-60
  const year5SumFactor = sumGeometric(monthlyGrowthRate45, year5MonthsCount);
  const year5BaseMonthly = year3BaseMonthly * Math.pow(1 + monthlyGrowthRate23, 24); // End of Year 3 rate
  const cumulativeYear45Patients = year5BaseMonthly * year5ConversionBoost * year5SumFactor;
  const year5Patients = year3Patients + cumulativeYear45Patients;
  const year5Revenue = year5Patients * patientTreatmentReimbursement;
  
  return {
    treatmentValue,
    patientRevenue: patientTreatmentReimbursement, // For UI compatibility
    patientTreatmentReimbursement,
    distributorRevenue,
    grossRevenue,
    doctorRevenue,
    manufacturerRevenue,
    
    digitalClicks,
    digitalLeads,
    digitalAppointments,
    digitalPatients,
    digitalChannelRevenue,
    
    oohResponses,
    oohLeads,
    oohAppointments,
    oohPatients,
    oohChannelRevenue,
    
    totalPatients,
    totalMonthlyRevenue,
    totalDistributorRevenue,
    
    year1Revenue: cumulativeYear1Revenue,
    year3Revenue,
    year5Revenue,
    year1Patients: cumulativeYear1Patients,
    year3Patients,
    year5Patients,
    
    digitalCostPerPatient,
    oohCostPerPatient,
    digitalROI,
    oohROI,
    blendedROI,
    
    // FIXED: Added effective CPM rates to return object
    digitalEffectiveCPM,
    oohEffectiveCPM,
    
    // CAC Analysis - FIXED: Add missing CAC properties
    digitalCAC: digitalPatients > 0 ? digitalCost / digitalPatients : null,
    oohCAC: oohPatients > 0 ? oohCost / oohPatients : null,
    blendedCAC: totalPatients > 0 ? (digitalCost + oohCost) / totalPatients : null,
    
    // Payback Period Analysis
    digitalPaybackMonths,
    oohPaybackMonths,
    blendedPaybackMonths,
    
    // Multi-year projection breakdown for UI with monthly cost clarification  
    projections: {
      year1: {
        patients: cumulativeYear1Patients,
        grossBillings: cumulativeYear1Revenue,
        distributorRevenue: cumulativeYear1Revenue * (state.distributorShare / 100),
        netProfit: cumulativeYear1Revenue - (digitalCost + oohCost) * 12, // 12 months of monthly costs
        roi: (digitalCost + oohCost) > 0 ? 
          ((cumulativeYear1Revenue - (digitalCost + oohCost) * 12) / ((digitalCost + oohCost) * 12)) * 100 : null
      },
      year3: {
        patients: year3Patients,
        grossBillings: year3Revenue,
        distributorRevenue: year3Revenue * (state.distributorShare / 100),
        netProfit: year3Revenue - (digitalCost + oohCost) * 36, // 36 months of monthly costs
        roi: (digitalCost + oohCost) > 0 ? 
          ((year3Revenue - (digitalCost + oohCost) * 36) / ((digitalCost + oohCost) * 36)) * 100 : null
      },
      year5: {
        patients: year5Patients,
        grossBillings: year5Revenue,
        distributorRevenue: year5Revenue * (state.distributorShare / 100),
        netProfit: year5Revenue - (digitalCost + oohCost) * 60, // 60 months of monthly costs
        roi: (digitalCost + oohCost) > 0 ? 
          ((year5Revenue - (digitalCost + oohCost) * 60) / ((digitalCost + oohCost) * 60)) * 100 : null
      }
    }
  };
};

export const formatCurrency = (value: number): string => {
  if (value >= 1000000) {
    return `$${(value / 1000000).toFixed(2)}M`;
  } else if (value >= 1000) {
    return `$${(value / 1000).toFixed(0)}K`;
  } else {
    return `$${value.toLocaleString()}`;
  }
};

export const formatNumber = (value: number): string => {
  return Math.round(value).toLocaleString();
};

export const formatPercentage = (value: number): string => {
  return `${value.toFixed(1)}%`;
};

export const formatLargeNumber = (value: number): string => {
  return Math.round(value).toLocaleString();
};

export const formatROI = (roiPercentage: number | null): string => {
  if (roiPercentage === null) {
    return "∞"; // Infinite ROI symbol for UI compatibility
  }
  const multiple = (roiPercentage / 100) + 1;
  if (roiPercentage > 10000) {
    return `${(roiPercentage / 100).toFixed(0)}x return (${roiPercentage.toFixed(0)}%)`;
  } else if (roiPercentage > 1000) {
    return `${multiple.toFixed(1)}x return (${roiPercentage.toFixed(0)}%)`;
  } else {
    return `${multiple.toFixed(1)}x return (${roiPercentage.toFixed(1)}%)`;
  }
};

export const formatPaybackPeriod = (months: number | null): string => {
  if (months === null) {
    return "Never"; // Loss-making or break-even scenarios
  }
  if (months === 0) {
    return "Immediate"; // No cost scenarios
  }
  return `${months.toFixed(1)} months`;
};

export const formatCostPerPatient = (cost: number | null): string => {
  if (cost === null) {
    return "N/A"; // Impossible scenarios (cost with no patients)
  }
  return formatCurrency(cost);
};
