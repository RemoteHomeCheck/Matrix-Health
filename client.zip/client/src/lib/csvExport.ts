import { CalculatorState, CalculatorResults } from "@shared/schema";
import { formatCurrency, formatNumber, formatPercentage } from "./calculations";

export const exportToCSV = (state: CalculatorState, results: CalculatorResults) => {
  const csvData = [
    ['Matrix Health Calculator - Revenue Analysis'],
    ['Generated on:', new Date().toLocaleDateString()],
    [''],
    ['TREATMENT PARAMETERS'],
    ['Graft Area (cm²)', `${state.treatmentLength} × ${state.treatmentWidth} = ${state.treatmentLength * state.treatmentWidth}`],
    ['CMS Rate per cm²', formatCurrency(state.reimbursementPerCm)],
    ['Treatment Duration (weeks)', state.treatmentDuration.toString()],
    ['Include Follow-up Fees', state.includeFollowUp ? 'Yes' : 'No'],
    ['Total Patient Revenue', formatCurrency(results.patientRevenue)],
    [''],
    ['REVENUE DISTRIBUTION'],
    ['Distributor Share (%)', formatPercentage(state.distributorShare)],
    ['Distributor Revenue', formatCurrency(results.distributorRevenue)],
    ['Provider Share (%)', formatPercentage(state.providerShare)],
    ['Provider Revenue', formatCurrency(results.doctorRevenue)],
    ['Manufacturer Share (%)', formatPercentage(state.manufacturerShare)],
    ['Manufacturer Revenue', formatCurrency(results.manufacturerRevenue)],
    [''],
    ['DIGITAL MARKETING CHANNEL'],
    ['Monthly Impressions', formatNumber(state.digitalImpressions)],
    ['CPM Rate', formatCurrency(state.digitalCpm)],
    ['Monthly Spend', formatCurrency(state.digitalSpendOnImpressions)],
    ['Click-Through Rate (%)', formatPercentage(state.digitalCtr)],
    ['Clicks per Month', formatNumber(results.digitalClicks)],
    ['Lead Conversion (%)', formatPercentage(state.digitalLeadConv)],
    ['Leads per Month', formatNumber(results.digitalLeads)],
    ['Appointment Rate (%)', formatPercentage(state.digitalApptConv)],
    ['Appointments per Month', formatNumber(results.digitalAppointments)],
    ['Patient Conversion (%)', formatPercentage(state.digitalPatientConv)],
    ['Patients per Month', formatNumber(results.digitalPatients)],
    ['Channel Revenue', formatCurrency(results.digitalChannelRevenue)],
    ['Cost per Patient', formatCurrency(results.digitalCostPerPatient)],
    ['Channel ROI (%)', formatPercentage(results.digitalROI)],
    ['Payback Period (months)', results.digitalPaybackMonths === Infinity ? 'N/A' : results.digitalPaybackMonths.toFixed(1)],
    [''],
    ['OUT-OF-HOME MARKETING CHANNEL'],
    ['Monthly Impressions', formatNumber(state.oohImpressions)],
    ['CPM Rate', formatCurrency(state.oohCpm)],
    ['Monthly Spend', formatCurrency(state.oohSpendOnImpressions)],
    ['Response Rate (%)', formatPercentage(state.oohResponse)],
    ['Responses per Month', formatNumber(results.oohResponses)],
    ['Lead Conversion (%)', formatPercentage(state.oohLeadConv)],
    ['Leads per Month', formatNumber(results.oohLeads)],
    ['Appointment Rate (%)', formatPercentage(state.oohApptConv)],
    ['Appointments per Month', formatNumber(results.oohAppointments)],
    ['Patient Conversion (%)', formatPercentage(state.oohPatientConv)],
    ['Patients per Month', formatNumber(results.oohPatients)],
    ['Channel Revenue', formatCurrency(results.oohChannelRevenue)],
    ['Cost per Patient', formatCurrency(results.oohCostPerPatient)],
    ['Channel ROI (%)', formatPercentage(results.oohROI)],
    ['Payback Period (months)', results.oohPaybackMonths === Infinity ? 'N/A' : results.oohPaybackMonths.toFixed(1)],
    [''],
    ['COMBINED RESULTS'],
    ['Total Patients per Month', formatNumber(results.totalPatients)],
    ['Total Monthly Revenue', formatCurrency(results.totalMonthlyRevenue)],
    ['Total Distributor Revenue', formatCurrency(results.totalDistributorRevenue)],
    ['Blended ROI (%)', formatPercentage(results.blendedROI)],
    ['Blended Payback (months)', results.blendedPaybackMonths === Infinity ? 'N/A' : results.blendedPaybackMonths.toFixed(1)],
    [''],
    ['MULTI-YEAR PROJECTIONS'],
    ['Year 1 Patients', formatNumber(results.year1Patients)],
    ['Year 1 Revenue', formatCurrency(results.year1Revenue)],
    ['Year 3 Patients', formatNumber(results.year3Patients)],
    ['Year 3 Revenue', formatCurrency(results.year3Revenue)],
    ['Year 5 Patients', formatNumber(results.year5Patients)],
    ['Year 5 Revenue', formatCurrency(results.year5Revenue)],
  ];

  const csvContent = csvData.map(row => 
    row.map(cell => `"${cell}"`).join(',')
  ).join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `matrix-health-calculator-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};