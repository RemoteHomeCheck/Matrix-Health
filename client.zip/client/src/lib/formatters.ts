// Enhanced formatting utilities for handling edge cases

// Helper function to format ROI values with proper edge case handling
export const formatROI = (roi: number): string => {
  if (!isFinite(roi)) return "∞%";
  if (roi === 0) return "0%";
  return `${roi.toFixed(0)}%`;
};

// Helper function to format payback period with proper edge case handling
export const formatPayback = (months: number): string => {
  if (!isFinite(months)) return "N/A";
  if (months < 0) return "Never";
  if (months === 0) return "Immediate";
  return `${months.toFixed(1)}mo`;
};

// Helper function to format cost per patient with edge case handling
export const formatCostPerPatient = (cost: number): string => {
  if (!isFinite(cost)) return "N/A";
  if (cost === 0) return "$0";
  return `$${cost.toFixed(0)}`;
};

// Helper function to format currency with edge case handling
export const formatCurrencyEnhanced = (amount: number): string => {
  if (!isFinite(amount)) return "N/A";
  if (amount === 0) return "$0";
  
  if (amount >= 1000000) {
    return `$${(amount / 1000000).toFixed(1)}M`;
  } else if (amount >= 1000) {
    return `$${(amount / 1000).toFixed(0)}K`;
  } else {
    return `$${amount.toFixed(0)}`;
  }
};

// Format numbers with commas and handle edge cases
export const formatNumberEnhanced = (num: number): string => {
  if (!isFinite(num)) return "N/A";
  if (num === 0) return "0";
  return num.toLocaleString(undefined, { maximumFractionDigits: 1 });
};