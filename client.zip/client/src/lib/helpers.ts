// Optimization 4: Custom error class for friendly messages
export class FriendlyError extends Error {
  constructor(public friendlyMessage: string, technical: string) {
    super(technical);
    this.name = 'FriendlyError';
  }
}

// Optimization 5: Geometric series helper for reuse
export const sumGeometric = (r: number, n: number): number => {
  if (r === 0) return n;
  return (Math.pow(1 + r, n) - 1) / r;
};

// Optimization 1: Improved payback calculation with break-even vs loss distinction
export const calcPayback = (cost: number, revenue: number): number | null | undefined => {
  if (cost === 0) return 0; // Immediate payback if no cost
  if (revenue === cost) return null; // N/A for break-even
  if (revenue < cost) return null; // Changed from undefined to null for "Never" to maintain type consistency
  return cost / (revenue - cost); // Standard payback calculation
};

// Enhanced formatters for improved ROI/payback semantics with x-return multiple
export const formatROI = (roi: number | null): string => {
  if (roi === null) return "∞";
  if (roi > 100) {
    const multiple = (roi / 100) + 1;
    return `${multiple.toFixed(1)}x return (${roi.toFixed(1)}%)`;
  }
  return `${roi.toFixed(1)}%`;
};

export const formatPaybackPeriod = (months: number | null | undefined): string => {
  if (months === undefined) return "Never"; // Loss scenario
  if (months === null) return "Never"; // Simplified: both break-even and loss show "Never"
  if (months === 0) return "Immediate";
  if (months < 1) return `${Math.round(months * 30)} days`;
  return `${months.toFixed(1)} months`;
};

// Phone number validation helper
export const validatePhoneNumber = (phone: string): boolean => {
  const phoneRegex = /^\+?[1-9]\d{1,14}$/;
  return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
};

// Currency formatting helper
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

// Percentage formatting helper
export const formatPercentage = (value: number): string => {
  return `${value.toFixed(1)}%`;
};