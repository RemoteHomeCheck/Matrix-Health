import { useState } from "react";
import { Calculator, BarChart3, TrendingUp, Settings, Download, Activity, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { exportToCSV } from "@/lib/csvExport";
import { useCalculator } from "@/hooks/useCalculator";
import RevenueCalculator from "@/components/RevenueCalculator";
import MarketingChannels from "@/components/MarketingChannels";
import MultiYearProjections from "@/components/MultiYearProjections";
import MixOptimization from "@/components/MixOptimization";
import PerformanceTracking from "@/components/PerformanceTracking";
import Reporting from "@/components/Reporting";
import { RevenueModelSelector } from "@/components/RevenueModelSelector";
import { OptimizationSuggestions } from "@/components/OptimizationSuggestions";

type TabType = 'revenue-calculator' | 'marketing-channels' | 'projections' | 'optimization' | 'performance-tracking' | 'reporting';

export default function CalculatorPage() {
  const [activeTab, setActiveTab] = useState<TabType>('revenue-calculator');
  const { state, results, updateState, resetToDefaults, applyRevenueModel, revenueModels } = useCalculator();

  const tabs = [
    { id: 'revenue-calculator' as TabType, label: '1. Revenue Calculator', icon: Calculator },
    { id: 'marketing-channels' as TabType, label: '2. Marketing Channels', icon: BarChart3 },
    { id: 'optimization' as TabType, label: '3. Growth & Mix Optimization', icon: Settings },
    { id: 'projections' as TabType, label: '4. Multi-Year Projections', icon: TrendingUp },
    { id: 'performance-tracking' as TabType, label: '5. Performance Tracking', icon: Activity },
    { id: 'reporting' as TabType, label: '6. Reporting', icon: FileText },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'revenue-calculator':
        return <RevenueCalculator state={state} results={results} onUpdate={updateState} />;
      case 'marketing-channels':
        return <MarketingChannels state={state} results={results} onUpdate={updateState} />;
      case 'optimization':
        return (
          <div className="space-y-8">
            <OptimizationSuggestions state={state} results={results} onUpdate={updateState} />
            <MixOptimization state={state} results={results} onUpdate={updateState} />
          </div>
        );
      case 'projections':
        return <MultiYearProjections state={state} results={results} onUpdate={updateState} />;
      case 'performance-tracking':
        return <PerformanceTracking state={state} results={results} onUpdate={updateState} />;
      case 'reporting':
        return <Reporting state={state} results={results} onUpdate={updateState} />;
      default:
        return <RevenueCalculator state={state} results={results} onUpdate={updateState} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-md border-b-4 border-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <Calculator className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900" data-testid="app-title">
                  Matrix Health Calculator
                </h1>
                <p className="text-sm text-gray-600">Medicare Wound Care ROI Analytics Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-secondary/10 px-3 py-1 rounded-full">
                <span className="text-secondary font-medium text-sm">Medicare Certified</span>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.href = '/settings'}
                data-testid="button-settings"
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => exportToCSV(state, results)}
                data-testid="button-export-csv"
              >
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
              <Button 
                variant="default" 
                size="sm"
                onClick={resetToDefaults}
                data-testid="button-reset"
              >
                Reset Calculator
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Revenue Model Selection */}
        <RevenueModelSelector
          currentModel={state.revenueModel}
          onModelSelect={applyRevenueModel}
          revenueModels={revenueModels}
          results={results}
          groupSize={state.groupSize}
          onGroupSizeChange={(size) => updateState({ groupSize: size })}
        />

        {/* Tab Navigation - Two Rows */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px" aria-label="Tabs" data-testid="tab-navigation">
              {/* First Row - Primary tabs */}
              <div className="flex justify-center space-x-8">
                {tabs.slice(0, 3).map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`tab-button whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm focus:outline-none transition-colors ${
                        activeTab === tab.id ? 'active' : ''
                      }`}
                      data-testid={`tab-${tab.id}`}
                    >
                      <Icon className="w-4 h-4 mr-2 inline" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
              
              {/* Second Row - Additional tabs */}
              <div className="flex justify-center space-x-8 border-t border-gray-100">
                {tabs.slice(3).map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`tab-button whitespace-nowrap py-3 px-6 border-b-2 font-medium text-sm focus:outline-none transition-colors ${
                        activeTab === tab.id ? 'active' : ''
                      }`}
                      data-testid={`tab-${tab.id}`}
                    >
                      <Icon className="w-4 h-4 mr-2 inline" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div data-testid={`content-${activeTab}`}>
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
}
