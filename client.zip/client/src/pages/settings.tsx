import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  Settings, 
  Link2, 
  Shield, 
  Bell, 
  User,
  Database,
  Key,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Trash2,
  Plus,
  RefreshCw,
  Download,
  ArrowLeft
} from "lucide-react";

interface IntegrationStatus {
  id: string;
  name: string;
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: string;
  description: string;
  marketShare?: string;
}

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("integrations");
  const [integrations, setIntegrations] = useState<IntegrationStatus[]>([
    { id: 'epic', name: 'Epic Systems', status: 'disconnected', description: 'Epic MyChart & EHR integration', marketShare: '30%+ market share' },
    { id: 'athenahealth', name: 'athenahealth', status: 'connected', lastSync: '2024-08-06 03:45 AM', description: 'athenaCollector billing integration', marketShare: '28% market share' },
    { id: 'cerner', name: 'Cerner PowerChart', status: 'disconnected', description: 'Oracle Cerner financial data sync', marketShare: '26% market share' },
    { id: 'quickbooks', name: 'QuickBooks Online', status: 'connected', lastSync: '2024-08-06 04:20 AM', description: 'Accounting & financial management', marketShare: '45% of practices' },
    { id: 'nextgen', name: 'NextGen Healthcare', status: 'error', description: 'Practice management system', marketShare: '12% market share' },
    { id: 'eclinicalworks', name: 'eClinicalWorks', status: 'disconnected', description: 'EHR & revenue cycle management', marketShare: '8% market share' },
    { id: 'allscripts', name: 'Allscripts', status: 'disconnected', description: 'Healthcare information solutions', marketShare: '7% market share' },
    { id: 'meditech', name: 'MEDITECH Expanse', status: 'disconnected', description: 'Health information systems', marketShare: '5% market share' },
    { id: 'sage', name: 'Sage Intacct', status: 'disconnected', description: 'Healthcare-specific accounting', marketShare: 'Enterprise focused' },
    { id: 'xero', name: 'Xero', status: 'disconnected', description: 'Cloud accounting for smaller practices', marketShare: 'Small practice focused' }
  ]);

  const [notifications, setNotifications] = useState({
    emailReports: true,
    syncAlerts: true,
    monthlyDigest: false,
    errorNotifications: true
  });

  const [userSettings, setUserSettings] = useState({
    practiceType: 'solo',
    defaultReportFormat: 'pdf',
    autoSyncEnabled: false,
    syncFrequency: 'monthly'
  });

  const handleConnect = (integrationId: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, status: 'connected', lastSync: new Date().toLocaleString() }
        : integration
    ));
  };

  const handleDisconnect = (integrationId: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, status: 'disconnected', lastSync: undefined }
        : integration
    ));
  };

  const handleTestConnection = (integrationId: string) => {
    // Simulate API test
    setTimeout(() => {
      setIntegrations(prev => prev.map(integration => 
        integration.id === integrationId 
          ? { ...integration, lastSync: new Date().toLocaleString() }
          : integration
      ));
    }, 2000);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Connected</Badge>;
      case 'error':
        return <Badge variant="destructive"><AlertCircle className="w-3 h-3 mr-1" />Error</Badge>;
      default:
        return <Badge variant="secondary">Disconnected</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <div className="container mx-auto py-8 px-4">
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Button variant="outline" onClick={() => window.location.href = '/'} className="mr-4" data-testid="button-back">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Calculator
            </Button>
            <div>
              <h1 className="text-3xl font-bold mb-2">Settings & Integrations</h1>
              <p className="text-gray-600">Manage your Matrix Health Calculator preferences and financial software connections</p>
            </div>
          </div>
        </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="integrations" data-testid="tab-integrations">
            <Link2 className="w-4 h-4 mr-2" />
            Integrations
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            <Bell className="w-4 h-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="preferences" data-testid="tab-preferences">
            <Settings className="w-4 h-4 mr-2" />
            Preferences
          </TabsTrigger>
          <TabsTrigger value="security" data-testid="tab-security">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
        </TabsList>

        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="w-5 h-5 mr-2" />
                Financial Software Integrations
              </CardTitle>
              <p className="text-sm text-gray-600">
                Connect your practice management and accounting software for automatic data synchronization
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Market Leaders Section */}
              <div>
                <h3 className="font-semibold mb-3 text-lg">Major Practice Management Systems</h3>
                <div className="grid gap-4">
                  {integrations.filter(i => ['epic', 'athenahealth', 'cerner', 'quickbooks'].includes(i.id)).map((integration) => (
                    <div key={integration.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <h4 className="font-medium mr-3">{integration.name}</h4>
                          {getStatusBadge(integration.status)}
                          <Badge variant="outline" className="ml-2 text-xs">{integration.marketShare}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{integration.description}</p>
                        {integration.lastSync && (
                          <p className="text-xs text-gray-500">Last sync: {integration.lastSync}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        {integration.status === 'connected' ? (
                          <>
                            <Button variant="outline" size="sm" onClick={() => handleTestConnection(integration.id)} data-testid={`button-test-${integration.id}`}>
                              <RefreshCw className="w-4 h-4 mr-1" />
                              Test
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => handleDisconnect(integration.id)} data-testid={`button-disconnect-${integration.id}`}>
                              <Trash2 className="w-4 h-4 mr-1" />
                              Disconnect
                            </Button>
                          </>
                        ) : (
                          <Button onClick={() => handleConnect(integration.id)} data-testid={`button-connect-${integration.id}`}>
                            <Plus className="w-4 h-4 mr-1" />
                            Connect
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              {/* Other Systems Section */}
              <div>
                <h3 className="font-semibold mb-3 text-lg">Additional Healthcare Systems</h3>
                <div className="grid gap-4">
                  {integrations.filter(i => !['epic', 'athenahealth', 'cerner', 'quickbooks'].includes(i.id)).map((integration) => (
                    <div key={integration.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <h4 className="font-medium mr-3">{integration.name}</h4>
                          {getStatusBadge(integration.status)}
                          <Badge variant="outline" className="ml-2 text-xs">{integration.marketShare}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{integration.description}</p>
                        {integration.lastSync && (
                          <p className="text-xs text-gray-500">Last sync: {integration.lastSync}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        {integration.status === 'connected' ? (
                          <>
                            <Button variant="outline" size="sm" onClick={() => handleTestConnection(integration.id)} data-testid={`button-test-${integration.id}`}>
                              <RefreshCw className="w-4 h-4 mr-1" />
                              Test
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => handleDisconnect(integration.id)} data-testid={`button-disconnect-${integration.id}`}>
                              <Trash2 className="w-4 h-4 mr-1" />
                              Disconnect
                            </Button>
                          </>
                        ) : (
                          <Button onClick={() => handleConnect(integration.id)} data-testid={`button-connect-${integration.id}`}>
                            <Plus className="w-4 h-4 mr-1" />
                            Connect
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              {/* Integration Info */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Integration Information</h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• All integrations use secure, HIPAA-compliant API connections</li>
                  <li>• Data is encrypted in transit and at rest</li>
                  <li>• Automatic sync occurs monthly or can be triggered manually</li>
                  <li>• Integration credentials are stored securely and never exposed</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="w-5 h-5 mr-2" />
                Notification Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-reports">Email Reports</Label>
                    <p className="text-sm text-gray-500">Receive monthly performance reports via email</p>
                  </div>
                  <Switch 
                    id="email-reports" 
                    checked={notifications.emailReports}
                    onCheckedChange={(checked) => setNotifications(prev => ({...prev, emailReports: checked}))}
                    data-testid="switch-email-reports"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="sync-alerts">Sync Alerts</Label>
                    <p className="text-sm text-gray-500">Get notified when data synchronization completes</p>
                  </div>
                  <Switch 
                    id="sync-alerts" 
                    checked={notifications.syncAlerts}
                    onCheckedChange={(checked) => setNotifications(prev => ({...prev, syncAlerts: checked}))}
                    data-testid="switch-sync-alerts"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="monthly-digest">Monthly Digest</Label>
                    <p className="text-sm text-gray-500">Summary of calculator usage and insights</p>
                  </div>
                  <Switch 
                    id="monthly-digest" 
                    checked={notifications.monthlyDigest}
                    onCheckedChange={(checked) => setNotifications(prev => ({...prev, monthlyDigest: checked}))}
                    data-testid="switch-monthly-digest"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="error-notifications">Error Notifications</Label>
                    <p className="text-sm text-gray-500">Alert me when integration errors occur</p>
                  </div>
                  <Switch 
                    id="error-notifications" 
                    checked={notifications.errorNotifications}
                    onCheckedChange={(checked) => setNotifications(prev => ({...prev, errorNotifications: checked}))}
                    data-testid="switch-error-notifications"
                  />
                </div>
              </div>

              <Separator className="my-6" />

              {/* SMS Testing Section */}
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-medium text-green-900 mb-3">
                  <RefreshCw className="w-4 h-4 inline mr-2" />
                  SMS Configuration & Testing
                </h4>
                <p className="text-sm text-green-700 mb-4">
                  Test your SMS alert functionality to ensure you receive automated report notifications.
                </p>
                <div className="flex gap-3">
                  <Input
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    id="sms-test-number"
                    className="flex-1"
                    data-testid="input-sms-test-number"
                  />
                  <Button 
                    variant="outline"
                    onClick={() => {
                      const phoneInput = document.getElementById('sms-test-number') as HTMLInputElement;
                      if (phoneInput && phoneInput.value) {
                        fetch('/api/sms/test', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ phoneNumber: phoneInput.value })
                        }).then(res => {
                          if (res.ok) {
                            alert('✅ Test SMS sent successfully! Check your phone.');
                          } else {
                            alert('❌ Failed to send test SMS. Verify your phone number format (+1234567890).');
                          }
                        }).catch(err => {
                          alert('❌ SMS service error: ' + err.message);
                        });
                      } else {
                        alert('Please enter a phone number first');
                      }
                    }}
                    data-testid="button-test-sms-connection"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Test SMS Connection
                  </Button>
                </div>
                <p className="text-xs text-green-600 mt-2">
                  SMS alerts are powered by Twilio. Test messages help verify your configuration is working correctly.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="w-5 h-5 mr-2" />
                Calculator Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="practice-type">Practice Type</Label>
                  <Select value={userSettings.practiceType} onValueChange={(value) => setUserSettings(prev => ({...prev, practiceType: value}))}>
                    <SelectTrigger data-testid="select-practice-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="solo">Solo Practice</SelectItem>
                      <SelectItem value="small-group">Small Group (2-10 providers)</SelectItem>
                      <SelectItem value="large-group">Large Group (11+ providers)</SelectItem>
                      <SelectItem value="hospital">Hospital System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="default-format">Default Report Format</Label>
                  <Select value={userSettings.defaultReportFormat} onValueChange={(value) => setUserSettings(prev => ({...prev, defaultReportFormat: value}))}>
                    <SelectTrigger data-testid="select-default-format">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF Report</SelectItem>
                      <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                      <SelectItem value="quickbooks">QuickBooks Format</SelectItem>
                      <SelectItem value="epic">Epic Systems</SelectItem>
                      <SelectItem value="athenahealth">athenahealth</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sync-frequency">Auto-Sync Frequency</Label>
                  <Select value={userSettings.syncFrequency} onValueChange={(value) => setUserSettings(prev => ({...prev, syncFrequency: value}))}>
                    <SelectTrigger data-testid="select-sync-frequency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="manual">Manual Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch 
                    id="auto-sync" 
                    checked={userSettings.autoSyncEnabled}
                    onCheckedChange={(checked) => setUserSettings(prev => ({...prev, autoSyncEnabled: checked}))}
                    data-testid="switch-auto-sync"
                  />
                  <Label htmlFor="auto-sync">Enable Auto-Sync</Label>
                </div>
              </div>

              <Button className="w-full" data-testid="button-save-preferences">
                Save Preferences
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Security & API Keys
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-yellow-50 p-4 rounded-lg">
                <h4 className="font-medium text-yellow-900 mb-2">
                  <Key className="w-4 h-4 inline mr-2" />
                  API Credentials Management
                </h4>
                <p className="text-sm text-yellow-700 mb-3">
                  Securely store your practice management system credentials for automatic synchronization.
                </p>
                <p className="text-xs text-yellow-600">
                  All credentials are encrypted and stored in compliance with HIPAA security standards.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="epic-api-key">Epic Systems API Key</Label>
                  <div className="flex gap-2 mt-1">
                    <Input 
                      id="epic-api-key" 
                      type="password" 
                      placeholder="Enter Epic API credentials"
                      data-testid="input-epic-api-key"
                    />
                    <Button variant="outline" data-testid="button-test-epic">Test</Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="athena-credentials">athenahealth Client Credentials</Label>
                  <div className="space-y-2 mt-1">
                    <Input 
                      id="athena-client-id" 
                      placeholder="Client ID"
                      data-testid="input-athena-client-id"
                    />
                    <Input 
                      id="athena-client-secret" 
                      type="password" 
                      placeholder="Client Secret"
                      data-testid="input-athena-client-secret"
                    />
                    <Button variant="outline" className="w-full" data-testid="button-test-athena">Test Connection</Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="quickbooks-token">QuickBooks OAuth Token</Label>
                  <div className="flex gap-2 mt-1">
                    <Input 
                      id="quickbooks-token" 
                      type="password" 
                      placeholder="OAuth access token"
                      data-testid="input-quickbooks-token"
                    />
                    <Button variant="outline" data-testid="button-authorize-quickbooks">
                      <ExternalLink className="w-4 h-4 mr-1" />
                      Authorize
                    </Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="cerner-credentials">Cerner PowerChart Credentials</Label>
                  <div className="space-y-2 mt-1">
                    <Input 
                      id="cerner-client-id" 
                      placeholder="SMART on FHIR Client ID"
                      data-testid="input-cerner-client-id"
                    />
                    <Input 
                      id="cerner-secret" 
                      type="password" 
                      placeholder="Client Secret"
                      data-testid="input-cerner-secret"
                    />
                    <Button variant="outline" className="w-full" data-testid="button-test-cerner">Test FHIR Connection</Button>
                  </div>
                </div>
              </div>

              <Button className="w-full" data-testid="button-save-credentials">
                <Shield className="w-4 h-4 mr-2" />
                Save Encrypted Credentials
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}