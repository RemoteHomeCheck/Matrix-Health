Successfully updated NPM package to version 1.1.0 with latest improvements:

✅ Enhanced Revenue Display - Shows Distributor, Physician, and Manufacturer revenue
✅ Improved Navigation - Year toggles positioned in breakdown headers  
✅ Better UX - Faster switching between 1/3/5 year projections
✅ Professional Formatting - Color-coded revenue streams
✅ Updated Documentation - Comprehensive changelog and feature list

The package now includes all the recent improvements you requested and maintains full compatibility with the main application.
