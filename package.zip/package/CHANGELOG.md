# Changelog

All notable changes to the Matrix Health Calculator NPM package will be documented in this file.

## [1.3.0] - 2025-01-06

### Added
- **Enhanced UI Explanations**: Added clear explanations differentiating manual control vs automated optimization
- **Interactive Tooltips**: Added hover tooltips explaining when to use Marketing Mix Optimization
- **New Formatting Functions**: Added `formatROI()` and `formatPaybackPeriod()` with null handling
- **Configuration Constants**: Added `CALCULATION_CONSTANTS` export for centralizing adjustable parameters
- **Enhanced Edge Case Handling**: Improved null/Infinity value handling for UI compatibility

### Fixed
- **Revenue Split Validation**: Added mandatory 100% sum validation with descriptive error messages
- **Mathematical Accuracy**: All calculations now include proper validation and edge case protection
- **Division by Zero Protection**: Added safeguards for all division operations
- **Null Value Display**: All formatters now handle null values with business-appropriate labels

### Changed
- **Variable Naming**: Updated `patientRevenue` to `patientTreatmentReimbursement` for clarity
- **Return Values**: ROI and payback calculations now return null instead of Infinity for edge cases
- **Package Version**: Updated to 1.3.0 with comprehensive mathematical improvements

### Technical Improvements
- Added comprehensive revenue split verification
- Enhanced calculation error handling with descriptive messages
- Improved type safety with null-aware formatting functions
- Centralized configuration for marketing team adjustments

## [1.2.0] - 2025-01-05

### Added
- **Critical Mathematical Fixes**: Addressed 7 blocking mathematical issues
- **Year 3/5 Double-Counting Fix**: Corrected ~200% overstatement in multi-year projections
- **Enhanced Unit Testing**: Added comprehensive validation with error-throwing assertions
- **Professional UI Formatting**: Added formatters for null values with business-appropriate labels

### Fixed
- **Treatment Revenue Calculation**: CMS pays $40K per graft (one-time), not $240K over 6 weeks
- **Conversion Rates**: Updated to market benchmarks Q4-2024/Q1-2025
- **ROI Display**: Shows both percentage and multiple formats
- **Multi-Year Caps**: Added 3x maximum conversion ceiling

## [1.1.0] - 2024-12-15

### Added
- **Clinical Research Integration**: Built on Las Heras (2020) clinical data
- **Evidence-Based Foundation**: 30% chronic wound rate, 2.5% US population affected
- **Medicare Population Modeling**: 16.4% of beneficiaries with chronic wounds
- **Treatment Duration Updates**: 12-13 month average management duration

## [1.0.0] - 2024-12-01

### Added
- Initial release with core calculator functionality
- React component with TypeScript support
- Basic revenue modeling and ROI calculations
- CSV export functionality
- Custom hook for advanced implementations