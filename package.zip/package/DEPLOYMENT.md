# Matrix Health Calculator - Deployment Guide

## Ready-to-Use NPM Package

This package provides a complete Medicare wound care ROI calculator that you can integrate into any React application.

## Quick Integration Steps

### 1. Install the Package
```bash
# If published to NPM
npm install @matrix-health/calculator

# Or install from local package
npm install ./path/to/matrix-health-calculator-package
```

### 2. Basic Integration
```jsx
import React from 'react';
import { MatrixHealthCalculator } from '@matrix-health/calculator';

function App() {
  return (
    <div>
      <h1>My Healthcare Platform</h1>
      <MatrixHealthCalculator 
        defaultModel="physician_funded"
        onResultsChange={(results) => {
          // Handle calculator updates
          console.log('Patients per month:', results.totalPatients);
          console.log('Monthly revenue:', results.totalMonthlyRevenue);
        }}
      />
    </div>
  );
}
```

### 3. Custom UI Integration
```jsx
import { useCalculator, exportToCSV } from '@matrix-health/calculator';

function CustomCalculator() {
  const { state, results, updateState } = useCalculator();
  
  return (
    <div className="my-custom-calculator">
      <h2>Healthcare ROI Calculator</h2>
      
      {/* Key Metrics */}
      <div className="metrics-grid">
        <div>Patients: {results.totalPatients}</div>
        <div>Revenue: ${results.totalMonthlyRevenue.toLocaleString()}</div>
        <div>ROI: {results.blendedROI.toFixed(1)}%</div>
      </div>
      
      {/* Controls */}
      <input 
        placeholder="Monthly Ad Spend"
        value={state.digitalSpendOnImpressions}
        onChange={(e) => updateState({ digitalSpendOnImpressions: parseFloat(e.target.value) })}
      />
      
      <button onClick={() => exportToCSV(state, results)}>
        Export Data
      </button>
    </div>
  );
}
```

## Configuration Options

### Full Component Props
```typescript
interface MatrixHealthCalculatorProps {
  // Initial state
  initialState?: Partial<CalculatorState>;
  defaultModel?: 'physician_funded' | 'group_collective' | 'distributor_funded';
  
  // Callbacks
  onResultsChange?: (results: CalculatorResults) => void;
  onStateChange?: (state: CalculatorState) => void;
  
  // UI customization
  theme?: 'light' | 'dark' | 'auto';
  hiddenTabs?: Array<'revenue-calculator' | 'marketing-channels' | 'growth-strategy' | 'projections' | 'optimization'>;
  showModelSelector?: boolean;
  className?: string;
}
```

### Revenue Models
- **Physician-Funded**: Doctor pays $7,500/month, distributor gets 15% share
- **Group Collective**: Multiple doctors pool $10,000/month, same revenue splits
- **Distributor-Funded**: Distributor pays all costs, gets 25% share, doctor pays $0

## Key Features

✅ **Medicare-Compliant Calculations**: $42,500 per patient revenue (CMS rates)  
✅ **Dual Marketing Channels**: Digital ($8.35 CPM) and Out-of-Home ($12 CPM)  
✅ **Real-Time ROI Analysis**: Live calculations with industry benchmarks  
✅ **Growth Strategy Tools**: Optimization suggestions and bottleneck analysis  
✅ **Multi-Year Projections**: 1/3/5-year forecasting with growth modeling  
✅ **Data Export**: CSV export functionality for reporting  
✅ **Full TypeScript Support**: Complete type safety and IntelliSense  

## Integration Examples

### Dashboard Widget
```jsx
function Dashboard() {
  return (
    <div className="dashboard">
      <div className="widget">
        <MatrixHealthCalculator 
          hiddenTabs={['revenue-calculator']}
          showModelSelector={false}
          onResultsChange={(results) => updateDashboard(results)}
        />
      </div>
    </div>
  );
}
```

### Modal Integration
```jsx
function CalculatorModal({ isOpen, onClose }) {
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <MatrixHealthCalculator 
        onResultsChange={(results) => {
          if (results.totalPatients > 0) {
            // Auto-close when calculation complete
            setTimeout(onClose, 2000);
          }
        }}
      />
    </Modal>
  );
}
```

### Form Integration
```jsx
function ProviderOnboarding() {
  const [calculatorData, setCalculatorData] = useState(null);
  
  return (
    <form>
      <fieldset>
        <legend>Practice Information</legend>
        {/* Your form fields */}
      </fieldset>
      
      <fieldset>
        <legend>Revenue Analysis</legend>
        <MatrixHealthCalculator 
          onResultsChange={setCalculatorData}
          hiddenTabs={['projections']}
        />
      </fieldset>
      
      <button type="submit">
        Submit Application
        {calculatorData && (
          <span> (Projected: {calculatorData.totalPatients} patients/month)</span>
        )}
      </button>
    </form>
  );
}
```

## Styling Integration

### CSS Variables
```css
.matrix-health-calculator {
  --primary: 59 130 246;        /* Your brand blue */
  --secondary: 241 245 249;     /* Your light gray */
  --background: 255 255 255;    /* White background */
  --foreground: 15 23 42;       /* Dark text */
}
```

### Tailwind CSS
```jsx
<MatrixHealthCalculator 
  className="border border-gray-200 rounded-lg shadow-lg p-6"
  theme="auto"
/>
```

## Performance Optimization

### Lazy Loading
```jsx
const MatrixHealthCalculator = lazy(() => 
  import('@matrix-health/calculator').then(module => ({
    default: module.MatrixHealthCalculator
  }))
);

<Suspense fallback={<CalculatorSkeleton />}>
  <MatrixHealthCalculator />
</Suspense>
```

### Memoization
```jsx
const MemoizedCalculator = memo(MatrixHealthCalculator);

<MemoizedCalculator 
  initialState={stableState}
  onResultsChange={useCallback(handleResults, [])}
/>
```

## Build & Deployment

### Building the Package
```bash
cd package
npm install
npm run build
```

### Publishing to NPM
```bash
npm login
npm publish
```

### Local Testing
```bash
npm pack
# Install in your project
npm install ./matrix-health-calculator-1.0.0.tgz
```

## Support & Customization

The calculator is designed to be:
- **Drop-in ready**: Works immediately with minimal configuration
- **Highly customizable**: Extensive props and styling options
- **Data-driven**: Real Medicare rates and industry benchmarks
- **Production-ready**: Full TypeScript support and error handling

For custom integrations or specific requirements, the package can be extended or the source can be modified to fit your exact needs.