# Matrix Health Calculator - Integration Guide

## Quick Start

### 1. Installation
```bash
npm install @matrix-health/calculator
```

### 2. Basic Usage in Your App
```jsx
import React from 'react';
import { MatrixHealthCalculator } from '@matrix-health/calculator';

function App() {
  return (
    <div>
      <h1>My Healthcare App</h1>
      <MatrixHealthCalculator 
        defaultModel="physician_funded"
        onResultsChange={(results) => {
          console.log('Monthly patients:', results.totalPatients);
          console.log('Monthly revenue:', results.totalMonthlyRevenue);
        }}
      />
    </div>
  );
}
```

## Integration Options

### Option A: Full Calculator Component
**Best for:** Complete functionality with minimal setup

```jsx
import { MatrixHealthCalculator } from '@matrix-health/calculator';

<MatrixHealthCalculator 
  theme="light" 
  showModelSelector={true}
  hiddenTabs={['optimization']} // Hide specific tabs
  onResultsChange={(results) => saveToDatabase(results)}
/>
```

### Option B: Custom UI with Hook
**Best for:** Custom design but need calculation logic

```jsx
import { useCalculator } from '@matrix-health/calculator';

function CustomCalculator() {
  const { state, results, updateState } = useCalculator();
  
  return (
    <div className="my-custom-design">
      <h2>Patients: {results.totalPatients}</h2>
      <input 
        value={state.digitalCpm}
        onChange={(e) => updateState({ digitalCpm: parseFloat(e.target.value) })}
      />
      <div>ROI: {results.blendedROI}%</div>
    </div>
  );
}
```

### Option C: Calculation Utils Only
**Best for:** Your own UI, just need the math

```jsx
import { calculateResults } from '@matrix-health/calculator';

const myState = {
  treatmentLength: 4,
  treatmentWidth: 4,
  digitalImpressions: 500000,
  // ... other parameters
};

const results = calculateResults(myState);
console.log(`${results.totalPatients} patients per month`);
```

## Advanced Integration

### Syncing with Your State Management
```jsx
// Redux/Zustand integration
function ConnectedCalculator() {
  const calculatorData = useSelector(state => state.calculator);
  const dispatch = useDispatch();
  
  return (
    <MatrixHealthCalculator
      initialState={calculatorData}
      onStateChange={(state) => dispatch(updateCalculator(state))}
      onResultsChange={(results) => dispatch(updateResults(results))}
    />
  );
}
```

### Theming Integration
```jsx
// Match your app's theme
const isDark = useTheme() === 'dark';

<MatrixHealthCalculator 
  theme={isDark ? 'dark' : 'light'}
  className="my-app-styling"
/>
```

### Data Export Integration
```jsx
import { exportToCSV } from '@matrix-health/calculator';

function ExportButton({ calculatorState, calculatorResults }) {
  const handleExport = () => {
    exportToCSV(
      calculatorState, 
      calculatorResults, 
      `calculator-data-${new Date().toISOString().split('T')[0]}.csv`
    );
  };
  
  return <button onClick={handleExport}>Export Data</button>;
}
```

## API Reference

### MatrixHealthCalculator Props
```typescript
interface MatrixHealthCalculatorProps {
  // Initial state
  initialState?: Partial<CalculatorState>;
  defaultModel?: 'physician_funded' | 'group_collective' | 'distributor_funded';
  
  // Callbacks
  onResultsChange?: (results: CalculatorResults) => void;
  onStateChange?: (state: CalculatorState) => void;
  
  // UI Configuration
  theme?: 'light' | 'dark' | 'auto';
  hiddenTabs?: TabType[];
  showModelSelector?: boolean;
  className?: string;
}
```

### useCalculator Hook
```typescript
const {
  state,           // Current calculator state
  results,         // Calculated results
  updateState,     // Update state function
  resetToDefaults, // Reset to defaults
  applyRevenueModel, // Apply revenue model
  revenueModels    // Available models
} = useCalculator(initialState?);
```

### Key Types
```typescript
// Patient revenue calculation
interface CalculatorResults {
  totalPatients: number;        // Patients per month
  totalMonthlyRevenue: number;  // Total monthly revenue
  distributorRevenue: number;   // Your revenue per patient
  blendedROI: number;          // Overall ROI percentage
  // ... many more fields
}

// Configuration state
interface CalculatorState {
  treatmentLength: number;      // Graft length (cm)
  treatmentWidth: number;       // Graft width (cm)
  digitalImpressions: number;   // Digital marketing impressions
  digitalCpm: number;          // Digital CPM rate
  // ... many more fields
}
```

## Common Integration Patterns

### 1. Embed in Existing Form
```jsx
function ProviderOnboardingForm() {
  const [formData, setFormData] = useState({});
  const [calculatorData, setCalculatorData] = useState(null);
  
  return (
    <form>
      {/* Your existing form fields */}
      
      <div className="calculator-section">
        <h3>Revenue Analysis</h3>
        <MatrixHealthCalculator 
          onResultsChange={setCalculatorData}
          hiddenTabs={['projections', 'optimization']}
        />
      </div>
      
      <button type="submit">
        Submit (Projected: {calculatorData?.totalPatients} patients/month)
      </button>
    </form>
  );
}
```

### 2. Dashboard Integration
```jsx
function Dashboard() {
  return (
    <div className="dashboard-grid">
      <div className="metrics-panel">
        <KPICards />
      </div>
      
      <div className="calculator-panel">
        <MatrixHealthCalculator 
          theme="auto"
          hiddenTabs={['revenue-calculator']} // Show only analysis tabs
          onResultsChange={(results) => {
            trackAnalytics('calculator_updated', {
              patients: results.totalPatients,
              roi: results.blendedROI
            });
          }}
        />
      </div>
    </div>
  );
}
```

### 3. Modal/Popup Integration
```jsx
function CalculatorModal({ isOpen, onClose }) {
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="modal-content">
        <MatrixHealthCalculator 
          onResultsChange={(results) => {
            // Auto-close when user completes calculation
            if (results.totalPatients > 0) {
              setTimeout(onClose, 2000);
            }
          }}
        />
      </div>
    </Modal>
  );
}
```

## Styling Integration

### CSS Variables
```css
.matrix-health-calculator {
  --primary: 59 130 246;     /* Your brand blue */
  --secondary: 241 245 249;  /* Your light gray */
  /* Override any CSS variables */
}
```

### Tailwind Integration
```jsx
<MatrixHealthCalculator 
  className="border border-gray-200 rounded-lg shadow-lg"
/>
```

## Performance Considerations

### Lazy Loading
```jsx
import { lazy, Suspense } from 'react';

const MatrixHealthCalculator = lazy(() => 
  import('@matrix-health/calculator').then(module => ({
    default: module.MatrixHealthCalculator
  }))
);

function App() {
  return (
    <Suspense fallback={<div>Loading calculator...</div>}>
      <MatrixHealthCalculator />
    </Suspense>
  );
}
```

### Memoization
```jsx
import { memo } from 'react';

const MemoizedCalculator = memo(MatrixHealthCalculator);

// Only re-renders when props actually change
<MemoizedCalculator 
  initialState={stableInitialState}
  onResultsChange={useCallback(handleResults, [])}
/>
```

## Testing

### Unit Testing
```jsx
import { calculateResults } from '@matrix-health/calculator';

test('calculates correct patient revenue', () => {
  const state = {
    treatmentLength: 4,
    treatmentWidth: 4,
    reimbursementPerCm: 2500,
    // ... minimal required state
  };
  
  const results = calculateResults(state);
  expect(results.treatmentValue).toBe(40000); // 16 cm² × $2500
});
```

### Integration Testing
```jsx
import { render, fireEvent } from '@testing-library/react';
import { MatrixHealthCalculator } from '@matrix-health/calculator';

test('calculator updates results when CPM changes', () => {
  const handleResults = jest.fn();
  
  render(
    <MatrixHealthCalculator onResultsChange={handleResults} />
  );
  
  const cpmInput = screen.getByLabelText(/digital cpm/i);
  fireEvent.change(cpmInput, { target: { value: '10' } });
  
  expect(handleResults).toHaveBeenCalledWith(
    expect.objectContaining({
      digitalEffectiveCPM: 10
    })
  );
});
```

## Support

For additional integration help:
1. Check the TypeScript definitions for complete API documentation
2. Review the demo implementations in the package
3. Open an issue on GitHub for specific integration questions