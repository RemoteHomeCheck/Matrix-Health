# Quick Start - Matrix Health Calculator

## 🚀 Ready-to-Use Package for Your App

This calculator is designed to integrate seamlessly into your existing React application.

## Installation & Setup

### Step 1: Copy Package to Your Project
```bash
# Copy the package folder to your project
cp -r ./package ./your-project/matrix-health-calculator

# Navigate to your project
cd your-project

# Install the local package
npm install ./matrix-health-calculator
```

### Step 2: Basic Integration
```jsx
// In your App.js or any component
import React from 'react';
import { MatrixHealthCalculator } from './matrix-health-calculator';

function App() {
  return (
    <div>
      <h1>Your Healthcare Platform</h1>
      <MatrixHealthCalculator 
        defaultModel="physician_funded"
        onResultsChange={(results) => {
          console.log('Patients per month:', results.totalPatients);
          console.log('Monthly revenue:', results.totalMonthlyRevenue);
          console.log('Your distributor revenue:', results.totalDistributorRevenue);
          
          // Save to your database, trigger analytics, etc.
        }}
      />
    </div>
  );
}
```

## Integration Options

### Option A: Full Calculator (Recommended)
```jsx
import { MatrixHealthCalculator } from './matrix-health-calculator';

<MatrixHealthCalculator 
  defaultModel="physician_funded"
  theme="light"
  showModelSelector={true}
  onResultsChange={(results) => handleCalculatorUpdate(results)}
/>
```

### Option B: Custom UI with Calculator Logic
```jsx
import { useCalculator } from './matrix-health-calculator';

function MyCustomCalculator() {
  const { state, results, updateState } = useCalculator();
  
  return (
    <div className="my-design">
      <h2>ROI Calculator</h2>
      
      {/* Your custom form fields */}
      <input 
        placeholder="Monthly Ad Spend"
        value={state.digitalSpendOnImpressions}
        onChange={(e) => updateState({ digitalSpendOnImpressions: parseFloat(e.target.value) })}
      />
      
      {/* Display results */}
      <div>
        <h3>Results:</h3>
        <p>Patients per month: {Math.round(results.totalPatients)}</p>
        <p>Monthly revenue: ${results.totalMonthlyRevenue.toLocaleString()}</p>
        <p>Your revenue: ${results.totalDistributorRevenue.toLocaleString()}</p>
        <p>ROI: {Math.round(results.blendedROI)}%</p>
      </div>
    </div>
  );
}
```

### Option C: Export Data Integration
```jsx
import { exportToCSV } from './matrix-health-calculator';

function MyDashboard() {
  const { state, results } = useCalculator();
  
  const handleExport = () => {
    exportToCSV(state, results, 'healthcare-roi-analysis.csv');
  };
  
  return (
    <div>
      <MatrixHealthCalculator />
      <button onClick={handleExport}>Export Data</button>
    </div>
  );
}
```

## Key Features You Get

✅ **Medicare-Compliant**: $42,500 per patient revenue (CMS rates)  
✅ **Three Revenue Models**: Physician-funded, Group collective, Distributor-funded  
✅ **Marketing Channels**: Digital and Out-of-Home with real-time ROI  
✅ **Growth Strategy**: Optimization suggestions and bottleneck analysis  
✅ **Multi-Year Projections**: 1, 3, and 5-year forecasting  
✅ **Data Export**: CSV export for reporting and analysis  
✅ **TypeScript Support**: Full type safety and IntelliSense  

## Real-World Results

With typical settings:
- **$8,000/month marketing spend** → **4-30+ patients/month** (depending on optimization)
- **$42,500 revenue per patient** → **$170K-1.2M+ monthly revenue potential**
- **15-25% distributor share** → **$25K-300K+ monthly distributor revenue**

## Revenue Models Explained

1. **Physician-Funded Model**
   - Doctor pays $7,500/month marketing
   - Distributor gets 15% revenue share
   - Best for: Established practices with marketing budget

2. **Group Collective Model**
   - Multiple doctors pool $10,000/month
   - Same revenue splits as physician-funded
   - Best for: Small practices working together

3. **Distributor-Funded Model**
   - Distributor pays all marketing costs
   - Doctor pays $0, distributor gets 25% share
   - Best for: Risk-averse doctors, new market entry

## Customization

### Hide Specific Tabs
```jsx
<MatrixHealthCalculator 
  hiddenTabs={['optimization', 'projections']}
  // Shows only core calculator and marketing channels
/>
```

### Custom Styling
```css
.matrix-health-calculator {
  --primary: 59 130 246;     /* Your brand blue */
  --secondary: 241 245 249;  /* Your light gray */
}
```

### Custom Initial Values
```jsx
<MatrixHealthCalculator 
  initialState={{
    treatmentLength: 5,
    treatmentWidth: 5,
    digitalCpm: 10.00,
    reimbursementPerCm: 3000
  }}
/>
```

## Data Integration

The calculator provides real-time callbacks for integration with your systems:

```jsx
function IntegratedCalculator() {
  const handleResults = (results) => {
    // Save to database
    saveCalculatorData({
      userId: currentUser.id,
      patients: results.totalPatients,
      revenue: results.totalMonthlyRevenue,
      roi: results.blendedROI,
      timestamp: new Date()
    });
    
    // Trigger analytics
    analytics.track('calculator_updated', {
      patients: results.totalPatients,
      revenue: results.totalMonthlyRevenue
    });
    
    // Update dashboard
    setDashboardMetrics(results);
  };
  
  return (
    <MatrixHealthCalculator 
      onResultsChange={handleResults}
      onStateChange={(state) => saveCalculatorState(state)}
    />
  );
}
```

## Support

The calculator is production-ready and includes:
- Error handling and validation
- Performance optimization
- Responsive design
- Accessibility features
- Professional documentation

Simply copy the package to your project and start integrating!