# Matrix Health Calculator

A comprehensive Medicare wound care ROI calculator for healthcare providers based on clinical research data. Analyze financial impact of marketing budget allocation between Digital and Out-of-Home channels with three revenue models for solo practitioners.

**Clinical Foundation:** Built on research showing 30% of wounds are chronic, affecting 2.5% of the US population and 16.4% of Medicare beneficiaries, with average 12-13 month management duration.

## Features

- **Revenue Model Analysis**: Three funding models (Physician-Funded, Group Collective, Distributor-Funded)
- **Marketing Channel Optimization**: Digital and OOH marketing with real-time ROI analysis
- **Enhanced Revenue Display**: Shows Distributor, Physician, and Manufacturer revenue breakdown
- **Improved Navigation**: Year selection toggles positioned directly in breakdown headers
- **Growth Strategy Tools**: AI-powered bottleneck analysis with 6x patient acquisition improvements
- **Multi-Year Projections**: 1/3/5-year forecasting with growth caps and market saturation modeling
- **Professional Features**: CSV export, real-world data toggle, payback period analysis

## Installation

```bash
npm install @matrix-health/calculator
```

> **Note**: This package is currently in development. To build from source, see the INTEGRATION_GUIDE.md for detailed setup instructions.

## Basic Usage

```jsx
import React from 'react';
import { MatrixHealthCalculator } from '@matrix-health/calculator';

function App() {
  return (
    <div>
      <MatrixHealthCalculator 
        defaultModel="physician_funded"
        onResultsChange={(results) => console.log('Results:', results)}
      />
    </div>
  );
}
```

## Advanced Usage

### Custom Initial State

```jsx
import { MatrixHealthCalculator } from '@matrix-health/calculator';

const customState = {
  treatmentLength: 5,
  treatmentWidth: 5,
  digitalCpm: 10.00,
  oohCpm: 15.00
};

<MatrixHealthCalculator 
  initialState={customState}
  showModelSelector={false}
  hiddenTabs={['optimization']}
/>
```

### Using the Hook Directly

```jsx
import { useCalculator } from '@matrix-health/calculator';

function CustomCalculator() {
  const { state, results, updateState } = useCalculator();
  
  return (
    <div>
      <h2>Patients per month: {results.totalPatients}</h2>
      <input 
        type="number" 
        value={state.digitalCpm}
        onChange={(e) => updateState({ digitalCpm: parseFloat(e.target.value) })}
      />
    </div>
  );
}
```

### Export Data

```jsx
import { exportToCSV } from '@matrix-health/calculator';

function ExportButton({ state, results }) {
  const handleExport = () => {
    exportToCSV(state, results, 'my-calculator-data.csv');
  };
  
  return <button onClick={handleExport}>Export to CSV</button>;
}
```

## Props

### MatrixHealthCalculator

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `initialState` | `Partial<CalculatorState>` | - | Initial calculator state |
| `defaultModel` | `'physician_funded' \| 'group_collective' \| 'distributor_funded'` | `'physician_funded'` | Default revenue model |
| `onResultsChange` | `(results: CalculatorResults) => void` | - | Callback when results change |
| `onStateChange` | `(state: CalculatorState) => void` | - | Callback when state changes |
| `theme` | `'light' \| 'dark' \| 'auto'` | `'light'` | Theme customization |
| `hiddenTabs` | `TabType[]` | `[]` | Hide specific tabs |
| `className` | `string` | `''` | Custom CSS class |
| `showModelSelector` | `boolean` | `true` | Show/hide model selector |

## Revenue Models

### Physician-Funded Model
- Doctor pays $7,500/month marketing budget
- Distributor gets 15% revenue share
- Provider gets 50% revenue share
- Manufacturer gets 35% revenue share

### Group Collective Model  
- Multiple doctors pool $10,000/month collectively
- Same revenue sharing as Physician-Funded
- Higher marketing volume through collective spend

### Distributor-Funded Model
- Distributor pays all marketing costs
- Physician pays $0
- Distributor gets 25% revenue share (higher risk = higher reward)
- Provider gets 40% revenue share

## Key Metrics & Clinical Data

- **Patient Revenue**: $42,500 per patient (CMS-compliant)
- **Treatment Value**: $40,000 graft + follow-up care (avg 12-13 months)
- **Target Population**: 2.5% of US population (8.3M chronic wound patients)
- **Medicare Market**: 16.4% of beneficiaries affected (10.7M patients)
- **Treatment Duration**: Average 20 weeks active management (based on 12-13 month clinical data)
- **Recurrence Rate**: 60-70% require ongoing care
- **Digital CPM**: $8.35 (adjustable)
- **OOH CPM**: $12.00 (adjustable)

## TypeScript Support

Full TypeScript support with exported types:

```typescript
import type { 
  CalculatorState, 
  CalculatorResults, 
  RevenueModel,
  ProjectionData 
} from '@matrix-health/calculator';
```

## Styling

The calculator comes with built-in styles but can be customized:

```css
.matrix-health-calculator {
  /* Your custom styles */
}

.matrix-health-calculator.dark {
  /* Dark theme overrides */
}
```

## Requirements

- React >=17.0.0
- Modern browser with ES2020 support

## License

MIT

## Support

For questions and support, please open an issue on GitHub.