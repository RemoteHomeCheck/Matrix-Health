#!/bin/bash

# Matrix Health Calculator - NPM Package Builder
echo "Building Matrix Health Calculator NPM Package..."

# Install dependencies
echo "Installing dependencies..."
npm install

# Copy component files from main project
echo "Copying component files..."
cp -r ../client/src/components/* src/components/ 2>/dev/null || echo "Components will need to be manually copied"

# Build the package
echo "Building package..."
npm run build

echo "✅ Package built successfully!"
echo ""
echo "To publish:"
echo "1. npm login"
echo "2. npm publish"
echo ""
echo "To test locally:"
echo "1. npm pack"
echo "2. npm install ../path/to/matrix-health-calculator-1.0.0.tgz"