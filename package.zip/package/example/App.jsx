import React from 'react';
import { MatrixHealthCalculator, useCalculator, exportToCSV } from '@matrix-health/calculator';

// Example 1: Full Calculator Component
function FullCalculatorExample() {
  const handleResultsChange = (results) => {
    console.log('Calculator updated:', {
      patients: results.totalPatients,
      revenue: results.totalMonthlyRevenue,
      roi: results.blendedROI
    });
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Healthcare ROI Calculator</h1>
      <MatrixHealthCalculator 
        defaultModel="physician_funded"
        theme="light"
        onResultsChange={handleResultsChange}
        showModelSelector={true}
      />
    </div>
  );
}

// Example 2: Custom UI with Hook
function CustomCalculatorExample() {
  const { state, results, updateState, applyRevenueModel } = useCalculator();

  const handleExport = () => {
    exportToCSV(state, results, 'my-calculator-data.csv');
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-bold mb-4">Custom Healthcare Calculator</h2>
        
        {/* Revenue Model Selector */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">Funding Model:</label>
          <select 
            value={state.currentModel}
            onChange={(e) => applyRevenueModel(e.target.value)}
            className="w-full p-2 border rounded"
          >
            <option value="physician_funded">Physician-Funded ($7.5K/mo)</option>
            <option value="group_collective">Group Collective ($10K/mo)</option>
            <option value="distributor_funded">Distributor-Funded (Free to doctor)</option>
          </select>
        </div>

        {/* Key Metrics Dashboard */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-blue-50 p-4 rounded text-center">
            <div className="text-2xl font-bold text-blue-600">
              {Math.round(results.totalPatients)}
            </div>
            <div className="text-sm text-gray-600">Patients/Month</div>
          </div>
          
          <div className="bg-green-50 p-4 rounded text-center">
            <div className="text-2xl font-bold text-green-600">
              ${Math.round(results.totalMonthlyRevenue).toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Monthly Revenue</div>
          </div>
          
          <div className="bg-purple-50 p-4 rounded text-center">
            <div className="text-2xl font-bold text-purple-600">
              {Math.round(results.blendedROI)}%
            </div>
            <div className="text-sm text-gray-600">ROI</div>
          </div>
          
          <div className="bg-orange-50 p-4 rounded text-center">
            <div className="text-2xl font-bold text-orange-600">
              ${Math.round(results.totalDistributorRevenue).toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Your Revenue</div>
          </div>
        </div>

        {/* Quick Controls */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="font-semibold mb-3">Digital Marketing</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">Monthly Budget ($)</label>
                <input
                  type="number"
                  value={Math.round(state.digitalSpendOnImpressions)}
                  onChange={(e) => {
                    const spend = parseFloat(e.target.value) || 0;
                    const impressions = (spend * 1000) / state.digitalCpm;
                    updateState({ 
                      digitalSpendOnImpressions: spend,
                      digitalImpressions: Math.round(impressions)
                    });
                  }}
                  className="w-full p-2 border rounded"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">CPM ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={state.digitalCpm}
                  onChange={(e) => updateState({ digitalCpm: parseFloat(e.target.value) || 0 })}
                  className="w-full p-2 border rounded"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Lead Conversion (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={state.digitalLeadConv}
                  onChange={(e) => updateState({ digitalLeadConv: parseFloat(e.target.value) || 0 })}
                  className="w-full p-2 border rounded"
                />
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-3">Treatment Parameters</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">Graft Size (cm)</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    placeholder="Length"
                    value={state.treatmentLength}
                    onChange={(e) => updateState({ treatmentLength: parseFloat(e.target.value) || 0 })}
                    className="p-2 border rounded"
                  />
                  <input
                    type="number"
                    placeholder="Width"
                    value={state.treatmentWidth}
                    onChange={(e) => updateState({ treatmentWidth: parseFloat(e.target.value) || 0 })}
                    className="p-2 border rounded"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">CMS Rate ($/cm²)</label>
                <input
                  type="number"
                  value={state.reimbursementPerCm}
                  onChange={(e) => updateState({ reimbursementPerCm: parseFloat(e.target.value) || 0 })}
                  className="w-full p-2 border rounded"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-4">
          <button
            onClick={handleExport}
            className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Export Data
          </button>
          
          <button
            onClick={() => updateState({ 
              digitalLeadConv: Math.min(state.digitalLeadConv * 1.5, 5),
              digitalApptConv: Math.min(state.digitalApptConv * 1.3, 20)
            })}
            className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          >
            Apply Optimization
          </button>
        </div>
      </div>
    </div>
  );
}

// Example 3: Minimal Embedded Calculator
function EmbeddedCalculatorExample() {
  const { state, results, updateState } = useCalculator({
    treatmentLength: 4,
    treatmentWidth: 4,
    digitalImpressions: 500000
  });

  return (
    <div className="bg-gray-100 p-4 rounded">
      <h3 className="font-semibold mb-3">Quick ROI Estimate</h3>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <label className="block text-xs font-medium mb-1">Monthly Ad Spend</label>
          <input
            type="number"
            value={Math.round(state.digitalSpendOnImpressions)}
            onChange={(e) => {
              const spend = parseFloat(e.target.value) || 0;
              const impressions = (spend * 1000) / 8.35;
              updateState({ 
                digitalSpendOnImpressions: spend,
                digitalImpressions: Math.round(impressions)
              });
            }}
            className="w-full p-2 text-sm border rounded"
          />
        </div>
        
        <div>
          <label className="block text-xs font-medium mb-1">Lead Conversion %</label>
          <input
            type="number"
            step="0.1"
            value={state.digitalLeadConv}
            onChange={(e) => updateState({ digitalLeadConv: parseFloat(e.target.value) || 0 })}
            className="w-full p-2 text-sm border rounded"
          />
        </div>
      </div>

      <div className="bg-white p-3 rounded">
        <div className="text-center">
          <div className="text-lg font-bold text-blue-600">
            {Math.round(results.totalPatients)} patients/month
          </div>
          <div className="text-sm text-gray-600">
            ${Math.round(results.totalDistributorRevenue).toLocaleString()} revenue
          </div>
          <div className="text-sm text-gray-600">
            {Math.round(results.blendedROI)}% ROI
          </div>
        </div>
      </div>
    </div>
  );
}

// Main App - Choose which example to display
export default function App() {
  const [activeExample, setActiveExample] = React.useState('full');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Example Selector */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex space-x-4">
            <button
              onClick={() => setActiveExample('full')}
              className={`px-4 py-2 rounded ${activeExample === 'full' ? 'bg-blue-100 text-blue-800' : 'text-gray-600 hover:text-gray-800'}`}
            >
              Full Calculator
            </button>
            <button
              onClick={() => setActiveExample('custom')}
              className={`px-4 py-2 rounded ${activeExample === 'custom' ? 'bg-blue-100 text-blue-800' : 'text-gray-600 hover:text-gray-800'}`}
            >
              Custom UI
            </button>
            <button
              onClick={() => setActiveExample('embedded')}
              className={`px-4 py-2 rounded ${activeExample === 'embedded' ? 'bg-blue-100 text-blue-800' : 'text-gray-600 hover:text-gray-800'}`}
            >
              Embedded Widget
            </button>
          </div>
        </div>
      </nav>

      {/* Example Content */}
      <main>
        {activeExample === 'full' && <FullCalculatorExample />}
        {activeExample === 'custom' && <CustomCalculatorExample />}
        {activeExample === 'embedded' && (
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-6">Embedded Calculator Widget</h1>
            <div className="max-w-md">
              <EmbeddedCalculatorExample />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}