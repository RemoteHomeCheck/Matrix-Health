import React, { useState } from 'react';
import { Calculator, BarChart3, TrendingUp, Settings } from 'lucide-react';
import { useCalculator } from './hooks/useCalculator';
import { 
  RevenueCalculator, 
  MarketingChannels, 
  OptimizationSuggestions, 
  MultiYearProjections, 
  MixOptimization, 
  RevenueModelSelector 
} from './components/SimpleComponents';
import { CalculatorState, CalculatorResults } from './types/schema';
import './styles.css';

type TabType = 'revenue-calculator' | 'marketing-channels' | 'growth-strategy' | 'projections' | 'optimization';

export interface MatrixHealthCalculatorProps {
  /** Initial calculator state */
  initialState?: Partial<CalculatorState>;
  /** Default revenue model to load */
  defaultModel?: 'physician_funded' | 'group_collective' | 'distributor_funded';
  /** Callback when calculator results change */
  onResultsChange?: (results: CalculatorResults) => void;
  /** Callback when calculator state changes */
  onStateChange?: (state: CalculatorState) => void;
  /** Theme customization */
  theme?: 'light' | 'dark' | 'auto';
  /** Hide specific tabs */
  hiddenTabs?: TabType[];
  /** Custom CSS class for styling */
  className?: string;
  /** Show/hide revenue model selector */
  showModelSelector?: boolean;
}

export function MatrixHealthCalculator({
  initialState,
  defaultModel = 'physician_funded',
  onResultsChange,
  onStateChange,
  theme = 'light',
  hiddenTabs = [],
  className = '',
  showModelSelector = true
}: MatrixHealthCalculatorProps) {
  const [activeTab, setActiveTab] = useState<TabType>('revenue-calculator');
  const { state, results, updateState, resetToDefaults, applyRevenueModel, revenueModels } = useCalculator(initialState);

  // Apply default model on mount
  React.useEffect(() => {
    if (defaultModel && revenueModels[defaultModel]) {
      applyRevenueModel(defaultModel);
    }
  }, [defaultModel, applyRevenueModel, revenueModels]);

  // Notify parent of changes
  React.useEffect(() => {
    onResultsChange?.(results);
  }, [results, onResultsChange]);

  React.useEffect(() => {
    onStateChange?.(state);
  }, [state, onStateChange]);

  const tabs = [
    { id: 'revenue-calculator' as TabType, label: 'Revenue Calculator', icon: Calculator },
    { id: 'marketing-channels' as TabType, label: 'Marketing Channels', icon: BarChart3 },
    { id: 'growth-strategy' as TabType, label: 'Growth Strategy', icon: TrendingUp },
    { id: 'projections' as TabType, label: 'Multi-Year Projections', icon: TrendingUp },
    { id: 'optimization' as TabType, label: 'Mix Optimization', icon: Settings },
  ].filter(tab => !hiddenTabs.includes(tab.id));

  const renderTabContent = () => {
    switch (activeTab) {
      case 'revenue-calculator':
        return <RevenueCalculator state={state} results={results} onUpdate={updateState} />;
      case 'marketing-channels':
        return <MarketingChannels state={state} results={results} onUpdate={updateState} />;
      case 'growth-strategy':
        return <OptimizationSuggestions state={state} results={results} onUpdate={updateState} />;
      case 'projections':
        return <MultiYearProjections state={state} results={results} onUpdate={updateState} />;
      case 'optimization':
        return <MixOptimization state={state} results={results} onUpdate={updateState} />;
      default:
        return <RevenueCalculator state={state} results={results} onUpdate={updateState} />;
    }
  };

  return (
    <div className={`matrix-health-calculator ${theme} ${className}`}>
      <div className="max-w-7xl mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Matrix Health Calculator
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Medicare wound care ROI analysis for dermal patch treatments. 
            Optimize marketing spend and revenue projections for healthcare providers.
          </p>
        </div>

        {showModelSelector && (
          <div className="mb-8">
            <RevenueModelSelector
              currentModel={state.currentModel}
              models={revenueModels}
              onModelSelect={(model: string) => applyRevenueModel(model as keyof typeof revenueModels)}
              onReset={resetToDefaults}
            />
          </div>
        )}

        {/* Tab Navigation */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex justify-center space-x-8 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    flex items-center gap-2 py-3 px-4 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200
                    ${activeTab === tab.id
                      ? 'border-blue-500 text-blue-600 bg-blue-50'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 hover:bg-gray-50'
                    }
                    rounded-t-lg
                  `}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="tab-content">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
}