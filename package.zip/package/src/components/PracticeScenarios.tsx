// Practice Scenarios component for Matrix Health Calculator
import { CalculatorState, CalculatorResults } from '../types/schema';
import { formatCurrency, formatNumber } from '../utils/calculations';

interface PracticeScenariosProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export function PracticeScenarios({ state, results, onUpdate }: PracticeScenariosProps) {
  const scenarios = [
    {
      id: 'solo_practitioner',
      title: 'Solo Practitioner',
      subtitle: 'Independent physician practice',
      budget: 7175,
      description: 'Limited budget, focused targeting',
      digitalImpressions: 450000,
      oohImpressions: 450000,
      color: 'blue'
    },
    {
      id: 'small_group',
      title: 'Small Group Practice',
      subtitle: '2-5 physicians collaborative practice',
      budget: 21525,
      description: 'Moderate investment, balanced approach',
      digitalImpressions: 1350000,
      oohImpressions: 1350000,
      color: 'purple'
    },
    {
      id: 'hospital_system',
      title: 'Hospital System',
      subtitle: 'Large healthcare organization',
      budget: 65750,
      description: 'Substantial budget, comprehensive strategy',
      digitalImpressions: 4050000,
      oohImpressions: 4050000,
      color: 'green'
    }
  ];

  const applyScenario = (scenario: typeof scenarios[0]) => {
    onUpdate({
      digitalImpressions: scenario.digitalImpressions,
      oohImpressions: scenario.oohImpressions,
      digitalSpendOnImpressions: (scenario.digitalImpressions * state.digitalCpm) / 1000,
      oohSpendOnImpressions: (scenario.oohImpressions * state.oohCpm) / 1000
    });
  };

  return (
    <div className="p-6 bg-white rounded-lg border">
      <div className="flex justify-between items-start mb-6">
        <h2 className="text-xl font-bold">Practice Scenarios</h2>
        <div className="text-right text-xs text-gray-500">
          <div>Pre-loaded templates for different practice types</div>
          <div>Based on clinical research and industry benchmarks</div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {scenarios.map((scenario) => (
          <button
            key={scenario.id}
            onClick={() => applyScenario(scenario)}
            className={`text-left p-6 border-2 rounded-lg hover:shadow-lg transition-all ${
              scenario.color === 'blue'
                ? 'border-blue-200 hover:border-blue-400 bg-blue-50 hover:bg-blue-100'
                : scenario.color === 'purple'
                ? 'border-purple-200 hover:border-purple-400 bg-purple-50 hover:bg-purple-100'
                : 'border-green-200 hover:border-green-400 bg-green-50 hover:bg-green-100'
            }`}
          >
            <div className="mb-4">
              <h3 className={`font-semibold text-lg ${
                scenario.color === 'blue'
                  ? 'text-blue-800'
                  : scenario.color === 'purple'
                  ? 'text-purple-800'
                  : 'text-green-800'
              }`}>
                {scenario.title}
              </h3>
              <p className="text-sm text-gray-600">{scenario.subtitle}</p>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Monthly Budget:</span>
                <span className="font-semibold">{formatCurrency(scenario.budget)}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Impressions:</span>
                <span className="font-semibold">{formatNumber(scenario.digitalImpressions + scenario.oohImpressions)}</span>
              </div>
              <div className="flex justify-between">
                <span>Digital Spend:</span>
                <span className="font-semibold">{formatCurrency((scenario.digitalImpressions * state.digitalCpm) / 1000)}</span>
              </div>
              <div className="flex justify-between">
                <span>OOH Spend:</span>
                <span className="font-semibold">{formatCurrency((scenario.oohImpressions * state.oohCpm) / 1000)}</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t">
              <p className="text-xs text-gray-600">{scenario.description}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Current Scenario Display */}
      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold mb-2">Current Configuration</h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="font-medium">Monthly Marketing Costs:</span>
            <div className="ml-2">
              <div>Digital Spend: {formatCurrency(state.digitalSpendOnImpressions)}</div>
              <div>OOH Spend: {formatCurrency(state.oohSpendOnImpressions)}</div>
              <div className="font-semibold">Total: {formatCurrency(state.digitalSpendOnImpressions + state.oohSpendOnImpressions)}</div>
            </div>
          </div>
          <div>
            <span className="font-medium">Expected Performance:</span>
            <div className="ml-2">
              <div>Patients/Month: {formatNumber(results.totalPatients)}</div>
              <div>Monthly Revenue: {formatCurrency(results.totalMonthlyRevenue)}</div>
              <div>Distributor Revenue: {formatCurrency(results.totalDistributorRevenue)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Practice Type Comparison */}
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h4 className="font-medium text-blue-900 mb-2">Practice Type Comparison</h4>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div>
            <span className="font-medium text-blue-800">Solo Practitioner:</span>
            <ul className="text-blue-600 mt-1 space-y-1">
              <li>• Lower marketing budgets</li>
              <li>• Higher personal engagement rates</li>
              <li>• Focused local targeting</li>
              <li>• Conservative growth projections</li>
            </ul>
          </div>
          <div>
            <span className="font-medium text-purple-800">Small Group:</span>
            <ul className="text-purple-600 mt-1 space-y-1">
              <li>• Balanced marketing investment</li>
              <li>• Shared patient base</li>
              <li>• Regional market reach</li>
              <li>• Moderate optimization rates</li>
            </ul>
          </div>
          <div>
            <span className="font-medium text-green-800">Hospital System:</span>
            <ul className="text-green-600 mt-1 space-y-1">
              <li>• Large marketing budgets</li>
              <li>• Professional conversion rates</li>
              <li>• Multi-channel strategies</li>
              <li>• Aggressive optimization goals</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}