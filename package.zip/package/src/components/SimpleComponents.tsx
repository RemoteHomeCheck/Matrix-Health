// React components for Matrix Health Calculator
import React from 'react';
import { CalculatorState, CalculatorResults } from '../types/schema';
import { formatCurrency, formatNumber, formatPercentage } from '../utils/calculations';

interface ComponentProps {
  state: CalculatorState;
  results: CalculatorResults;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

// Simple Revenue Calculator Component
export function RevenueCalculator({ state, results, onUpdate }: ComponentProps) {
  return (
    <div className="space-y-6 p-6 bg-white rounded-lg border">
      <div className="flex justify-between items-start">
        <h2 className="text-xl font-bold">Revenue Calculator</h2>
        <div className="text-right text-xs text-gray-500">
          <div>Clinical Research: 30% of wounds are chronic</div>
          <div>Avg management: 12-13 months</div>
          <div>Medicare beneficiaries: 16.4% affected</div>
        </div>
      </div>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="font-semibold">Treatment Parameters</h3>
          
          <div>
            <label className="block text-sm font-medium mb-1">Graft Length (cm)</label>
            <input
              type="number"
              value={state.treatmentLength}
              onChange={(e) => onUpdate({ treatmentLength: parseFloat(e.target.value) || 0 })}
              className="w-full p-2 border rounded"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Graft Width (cm)</label>
            <input
              type="number"
              value={state.treatmentWidth}
              onChange={(e) => onUpdate({ treatmentWidth: parseFloat(e.target.value) || 0 })}
              className="w-full p-2 border rounded"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">CMS Rate ($/cm²)</label>
            <input
              type="number"
              value={state.reimbursementPerCm}
              onChange={(e) => onUpdate({ reimbursementPerCm: parseFloat(e.target.value) || 0 })}
              className="w-full p-2 border rounded"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Treatment Duration (weeks)</label>
            <input
              type="number"
              value={state.treatmentDuration}
              onChange={(e) => onUpdate({ treatmentDuration: parseFloat(e.target.value) || 0 })}
              className="w-full p-2 border rounded"
            />
            <p className="text-xs text-gray-500 mt-1">
              Avg: 52 weeks (12-13 months for chronic wounds)
            </p>
          </div>
        </div>
        
        
        <div className="space-y-4">
          <h3 className="font-semibold">Revenue Results</h3>
          <div className="bg-blue-50 p-4 rounded">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Treatment Area:</span>
                <span className="font-mono">{results.treatmentArea} cm²</span>
              </div>
              <div className="flex justify-between">
                <span>Graft Value:</span>
                <span className="font-mono">{formatCurrency(results.treatmentValue)}</span>
              </div>
              <div className="flex justify-between">
                <span>Follow-up Revenue:</span>
                <span className="font-mono">{formatCurrency(results.followUpRevenue)}</span>
              </div>
              <div className="flex justify-between border-t pt-2 font-bold">
                <span>Total per Patient:</span>
                <span className="font-mono">{formatCurrency(results.patientRevenue)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Simple Marketing Channels Component
export function MarketingChannels({ state, results, onUpdate }: ComponentProps) {
  return (
    <div className="space-y-6 p-6 bg-white rounded-lg border">
      <h2 className="text-xl font-bold">Marketing Channels</h2>
      
      <div className="grid md:grid-cols-2 gap-8">
        {/* Digital Channel */}
        <div>
          <h3 className="font-semibold text-blue-600 mb-4">Digital Marketing</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Monthly Impressions</label>
              <input
                type="number"
                value={state.digitalImpressions}
                onChange={(e) => onUpdate({ digitalImpressions: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 border rounded"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">CPM ($)</label>
              <input
                type="number"
                step="0.01"
                value={state.digitalCpm}
                onChange={(e) => onUpdate({ digitalCpm: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 border rounded"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Click-Through Rate (%)</label>
              <input
                type="number"
                step="0.1"
                value={state.digitalCtr}
                onChange={(e) => onUpdate({ digitalCtr: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 border rounded"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Lead Conversion (%)</label>
              <input
                type="number"
                step="0.1"
                value={state.digitalLeadConv}
                onChange={(e) => onUpdate({ digitalLeadConv: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 border rounded"
              />
            </div>
          </div>
          
          <div className="bg-blue-50 p-4 rounded mt-4">
            <h4 className="font-medium mb-2">Digital Results</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Monthly Patients:</span>
                <span className="font-mono">{formatNumber(results.digitalPatients)}</span>
              </div>
              <div className="flex justify-between">
                <span>Channel Revenue:</span>
                <span className="font-mono">{formatCurrency(results.digitalChannelRevenue)}</span>
              </div>
              <div className="flex justify-between">
                <span>ROI:</span>
                <span className="font-mono">{formatPercentage(results.digitalROI)}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* OOH Channel */}
        <div>
          <h3 className="font-semibold text-green-600 mb-4">Out-of-Home Marketing</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Monthly Impressions</label>
              <input
                type="number"
                value={state.oohImpressions}
                onChange={(e) => onUpdate({ oohImpressions: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 border rounded"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">CPM ($)</label>
              <input
                type="number"
                step="0.01"
                value={state.oohCpm}
                onChange={(e) => onUpdate({ oohCpm: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 border rounded"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Response Rate (%)</label>
              <input
                type="number"
                step="0.01"
                value={state.oohResponse}
                onChange={(e) => onUpdate({ oohResponse: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 border rounded"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Lead Conversion (%)</label>
              <input
                type="number"
                step="0.1"
                value={state.oohLeadConv}
                onChange={(e) => onUpdate({ oohLeadConv: parseFloat(e.target.value) || 0 })}
                className="w-full p-2 border rounded"
              />
            </div>
          </div>
          
          <div className="bg-green-50 p-4 rounded mt-4">
            <h4 className="font-medium mb-2">OOH Results</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Monthly Patients:</span>
                <span className="font-mono">{formatNumber(results.oohPatients)}</span>
              </div>
              <div className="flex justify-between">
                <span>Channel Revenue:</span>
                <span className="font-mono">{formatCurrency(results.oohChannelRevenue)}</span>
              </div>
              <div className="flex justify-between">
                <span>ROI:</span>
                <span className="font-mono">{formatPercentage(results.oohROI)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Combined Results */}
      <div className="bg-gray-50 p-6 rounded-lg">
        <h3 className="font-semibold mb-4">Combined Channel Results</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{formatNumber(results.totalPatients)}</div>
            <div className="text-sm text-gray-600">Patients/Month</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{formatCurrency(results.totalMonthlyRevenue)}</div>
            <div className="text-sm text-gray-600">Monthly Revenue</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{formatPercentage(results.blendedROI)}</div>
            <div className="text-sm text-gray-600">Blended ROI</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{formatCurrency(results.totalDistributorRevenue)}</div>
            <div className="text-sm text-gray-600">Your Revenue</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Simple Revenue Model Selector
export function RevenueModelSelector({ 
  currentModel, 
  models, 
  onModelSelect, 
  onReset 
}: {
  currentModel: string;
  models: Record<string, any>;
  onModelSelect: (model: string) => void;
  onReset: () => void;
}) {
  return (
    <div className="space-y-4 p-6 bg-white rounded-lg border">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Revenue Model</h2>
        <button
          onClick={onReset}
          className="px-4 py-2 text-sm bg-gray-100 hover:bg-gray-200 rounded"
        >
          Reset
        </button>
      </div>
      
      <div className="grid md:grid-cols-3 gap-4">
        {Object.entries(models).map(([key, model]) => (
          <button
            key={key}
            onClick={() => onModelSelect(key)}
            className={`p-4 text-left border rounded-lg transition-colors ${
              currentModel === key 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <h3 className="font-semibold text-sm">{model.name}</h3>
            <p className="text-xs text-gray-600 mt-1">{model.description}</p>
            <div className="mt-2 text-xs">
              <span className="font-medium">Budget:</span> {formatCurrency(model.totalBudget)}/mo
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// Placeholder components for other tabs
export function OptimizationSuggestions({ state, results, onUpdate }: ComponentProps) {
  // Calculate improvement potentials
  const currentPatients = results.totalPatients;
  const currentROI = results.blendedROI;
  const digitalCAC = results.digitalCostPerPatient;
  
  // Identify bottlenecks
  const bottlenecks = [];
  if (state.digitalLeadConv < 1.5) bottlenecks.push({ issue: 'Low digital lead conversion', impact: 'Medium', fix: 'Improve landing pages' });
  if (state.digitalApptConv < 10) bottlenecks.push({ issue: 'Low appointment conversion', impact: 'High', fix: 'Add concierge scheduling' });
  if (digitalCAC > 5000) bottlenecks.push({ issue: 'High digital acquisition cost', impact: 'High', fix: 'Optimize targeting' });
  if (results.digitalROI < 200) bottlenecks.push({ issue: 'Low digital ROI', impact: 'Medium', fix: 'Increase conversion rates' });
  
  return (
    <div className="p-6 bg-white rounded-lg border">
      <div className="flex justify-between items-start mb-4">
        <h2 className="text-xl font-bold">Growth Strategy</h2>
        <div className="text-right text-xs text-gray-500">
          <div>Analyzes Revenue + Marketing data</div>
          <div>Feeds into Mix Optimization</div>
        </div>
      </div>
      
      {/* Current Performance Summary */}
      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <div className="bg-blue-50 p-4 rounded">
          <h3 className="font-semibold text-blue-800">Current Performance</h3>
          <div className="mt-2 space-y-1 text-sm">
            <div>{formatNumber(currentPatients)} patients/month</div>
            <div>{formatPercentage(currentROI)} blended ROI</div>
            <div>${formatNumber(results.totalDistributorRevenue)}/mo revenue</div>
          </div>
        </div>
        
        <div className="bg-green-50 p-4 rounded">
          <h3 className="font-semibold text-green-800">Optimization Potential</h3>
          <div className="mt-2 space-y-1 text-sm">
            <div>Up to {formatNumber(currentPatients * 2.5)} patients/month</div>
            <div>ROI improvement: +150-300%</div>
            <div>6-month payback potential</div>
          </div>
        </div>
        
        <div className="bg-orange-50 p-4 rounded">
          <h3 className="font-semibold text-orange-800">Investment Required</h3>
          <div className="mt-2 space-y-1 text-sm">
            <div>Conversion optimization</div>
            <div>A/B testing campaigns</div>
            <div>Process improvements</div>
          </div>
        </div>
      </div>
      
      {/* Bottleneck Analysis */}
      {bottlenecks.length > 0 && (
        <div className="mb-6">
          <h3 className="font-semibold mb-3">Bottleneck Analysis</h3>
          <div className="space-y-2">
            {bottlenecks.slice(0, 3).map((bottleneck, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-yellow-50 rounded border-l-4 border-yellow-400">
                <div>
                  <span className="font-medium text-yellow-800">{bottleneck.issue}</span>
                  <span className={`ml-2 px-2 py-1 text-xs rounded ${
                    bottleneck.impact === 'High' ? 'bg-red-100 text-red-800' : 'bg-orange-100 text-orange-800'
                  }`}>
                    {bottleneck.impact} Impact
                  </span>
                </div>
                <div className="text-sm text-yellow-700">{bottleneck.fix}</div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Growth Actions */}
      <div className="space-y-4">
        <h3 className="font-semibold">Growth Actions</h3>
        
        <div className="grid md:grid-cols-2 gap-4">
          {/* Quick Wins */}
          <div className="bg-green-50 p-4 rounded">
            <h4 className="font-semibold text-green-800 mb-2">Quick Wins (30 days)</h4>
            <div className="space-y-2">
              <button
                onClick={() => onUpdate({ 
                  digitalLeadConv: Math.min(state.digitalLeadConv * 1.3, 3),
                  digitalApptConv: Math.min(state.digitalApptConv * 1.2, 15)
                })}
                className="w-full text-left p-2 bg-white border rounded hover:bg-gray-50 text-sm"
              >
                <div className="font-medium">Conversion Rate Boost</div>
                <div className="text-gray-600">+30% lead conversion, +20% appointments</div>
                <div className="text-green-600 text-xs">Expected: +{formatNumber(currentPatients * 0.5)} patients/mo</div>
              </button>
              
              <button
                onClick={() => onUpdate({ 
                  digitalCtr: Math.min(state.digitalCtr * 1.15, 2.5),
                  oohResponse: Math.min(state.oohResponse * 1.1, 0.12)
                })}
                className="w-full text-left p-2 bg-white border rounded hover:bg-gray-50 text-sm"
              >
                <div className="font-medium">Creative Optimization</div>
                <div className="text-gray-600">+15% CTR, +10% OOH response</div>
                <div className="text-green-600 text-xs">Expected: +{formatNumber(currentPatients * 0.3)} patients/mo</div>
              </button>
            </div>
          </div>
          
          {/* Long-term Strategy */}
          <div className="bg-blue-50 p-4 rounded">
            <h4 className="font-semibold text-blue-800 mb-2">Long-term Strategy (3-6 months)</h4>
            <div className="space-y-2">
              <button
                onClick={() => onUpdate({ 
                  digitalPatientConv: Math.min(state.digitalPatientConv * 1.4, 80),
                  oohPatientConv: Math.min(state.oohPatientConv * 1.3, 75),
                  digitalApptConv: Math.min(state.digitalApptConv * 1.5, 20)
                })}
                className="w-full text-left p-2 bg-white border rounded hover:bg-gray-50 text-sm"
              >
                <div className="font-medium">Process Excellence</div>
                <div className="text-gray-600">Patient qualification + care coordination</div>
                <div className="text-blue-600 text-xs">Expected: +{formatNumber(currentPatients * 1.2)} patients/mo</div>
              </button>
              
              <button
                onClick={() => onUpdate({ 
                  monthlyGrowthRate: Math.min(state.monthlyGrowthRate * 1.5, 8),
                  maxConversionMultiplier: Math.min(state.maxConversionMultiplier * 1.2, 4)
                })}
                className="w-full text-left p-2 bg-white border rounded hover:bg-gray-50 text-sm"
              >
                <div className="font-medium">Scale Infrastructure</div>
                <div className="text-gray-600">Team expansion + system optimization</div>
                <div className="text-blue-600 text-xs">Expected: 2-3x growth capacity</div>
              </button>
            </div>
          </div>
        </div>
        
        {/* Apply All Optimizations */}
        <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border">
          <h4 className="font-semibold mb-2">Complete Growth Package</h4>
          <p className="text-sm text-gray-700 mb-3">
            Apply all recommended optimizations for maximum growth impact.
          </p>
          <button
            onClick={() => onUpdate({ 
              digitalLeadConv: Math.min(state.digitalLeadConv * 1.5, 4),
              digitalApptConv: Math.min(state.digitalApptConv * 1.4, 18),
              digitalPatientConv: Math.min(state.digitalPatientConv * 1.3, 75),
              digitalCtr: Math.min(state.digitalCtr * 1.2, 2.2),
              oohResponse: Math.min(state.oohResponse * 1.15, 0.1),
              oohLeadConv: Math.min(state.oohLeadConv * 1.2, 12),
              oohApptConv: Math.min(state.oohApptConv * 1.3, 12),
              monthlyGrowthRate: Math.min(state.monthlyGrowthRate * 1.3, 7)
            })}
            className="px-6 py-3 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg font-medium hover:from-green-700 hover:to-blue-700 transition-all"
          >
            Apply Complete Growth Strategy
            <span className="ml-2 text-sm opacity-90">
              (Expected: {formatNumber(currentPatients * 2.5)}+ patients/month)
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}

export function MultiYearProjections({ state, results, onUpdate }: ComponentProps) {
  const [selectedPeriod, setSelectedPeriod] = React.useState<1 | 3 | 5>(1);

  const handleInputChange = (field: keyof CalculatorState, value: string) => {
    const numValue = parseFloat(value) || 0;
    onUpdate({ [field]: numValue });
  };

  const generateMonthlyBreakdown = () => {
    const months = [];
    const basePatients = results.totalPatients;
    
    for (let month = 1; month <= 12; month++) {
      const growthFactor = Math.pow(1 + (state.monthlyGrowthRate / 100), month);
      const patients = Math.round(basePatients * growthFactor);
      const revenue = patients * results.patientRevenue;
      const distributorShare = revenue * (state.distributorShare / 100);
      
      months.push({
        name: new Date(2024, month - 1).toLocaleDateString('en-US', { month: 'short' }),
        patients,
        revenue,
        distributor: distributorShare
      });
    }
    return months;
  };

  const monthlyData = generateMonthlyBreakdown();
  
  // Show the complete data flow impact
  const year1 = results.projections.year1;
  const year3 = results.projections.year3;
  const year5 = results.projections.year5;
  
  return (
    <div className="space-y-8">
      {/* Time Period Selector and Growth Assumptions */}
      <div className="p-6 bg-white rounded-lg border">
        <div className="mb-6">
          <h2 className="text-xl font-bold">Multi-Year Revenue Projections</h2>
        </div>
      
        {/* Growth Assumptions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium text-blue-700 mb-3">Year 1 Growth</h4>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm">Growth Rate:</span>
                <div className="flex items-center space-x-1">
                  <input
                    type="number"
                    step="0.1"
                    value={state.monthlyGrowthRate}
                    onChange={(e) => handleInputChange('monthlyGrowthRate', e.target.value)}
                    className="w-16 text-sm px-2 py-1 border rounded"
                  />
                  <span className="text-sm">%/mo</span>
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Market Phase:</span>
                <span className="text-sm font-medium">Initial</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Projection Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Dynamic Content Based on Selected Period */}
        <div className="p-6 bg-white rounded-lg border">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">
              {selectedPeriod === 1 && "Year 1 Monthly Breakdown"}
              {selectedPeriod === 3 && "3-Year Quarterly Breakdown"}  
              {selectedPeriod === 5 && "5-Year Annual Breakdown"}
            </h3>
            <div className="flex space-x-2">
              {[1, 3, 5].map((period) => (
                <button
                  key={period}
                  onClick={() => setSelectedPeriod(period as 1 | 3 | 5)}
                  className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                    selectedPeriod === period 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {period} Year{period > 1 ? 's' : ''}
                </button>
              ))}
            </div>
          </div>
          
          {selectedPeriod === 1 && (
            <>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Month</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Patients</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Revenue</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Distributor</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {monthlyData.map((month, index) => (
                      <tr key={month.name}>
                        <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900">{month.name}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 text-right font-mono">{formatNumber(month.patients)}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 text-right font-mono">{formatCurrency(month.revenue)}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-green-600 text-right font-mono">{formatCurrency(month.distributor)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-blue-700">Year 1 Total:</span>
                  <div className="text-right">
                    <div className="font-bold text-blue-700">{formatCurrency(year1.grossBillings)}</div>
                    <div className="text-sm text-blue-600">{formatCurrency(year1.distributorRevenue)} Distributor</div>
                  </div>
                </div>
              </div>
            </>
          )}
          
          {selectedPeriod === 3 && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-4">3-Year Summary</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Total Patients</p>
                    <p className="text-2xl font-bold text-blue-600">{formatNumber(year3.patients)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Gross Revenue</p>
                    <p className="text-2xl font-bold text-blue-600">{formatCurrency(year3.grossBillings)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Distributor Share</p>
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(year3.distributorRevenue)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Monthly Run Rate</p>
                    <p className="text-2xl font-bold text-orange-600">{formatCurrency(year3.grossBillings / 36)}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {selectedPeriod === 5 && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-green-50 to-yellow-50 p-6 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-4">5-Year Summary</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Total Patients</p>
                    <p className="text-2xl font-bold text-green-600">{formatNumber(year5.patients)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Gross Revenue</p>
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(year5.grossBillings)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Distributor Share</p>
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(year5.distributorRevenue)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Market Penetration</p>
                    <p className="text-2xl font-bold text-orange-600">12.3%</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Multi-Year Summary */}
        <div className="p-6 bg-white rounded-lg border">
          <h3 className="text-lg font-bold mb-4">Long-Term Projections</h3>
          <div className="space-y-6">
            {/* 3-Year Projection */}
            <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-4">3-Year Forecast</h4>
              <div className="grid grid-cols-2 gap-4">
        {/* Year 1 */}
        <div className="bg-blue-50 p-6 rounded-lg border">
          <h3 className="font-semibold text-blue-800 text-lg mb-4">Year 1</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Total Patients:</span>
              <span className="font-semibold">{formatNumber(year1.patients)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Gross Revenue:</span>
              <span className="font-semibold">{formatCurrency(year1.grossBillings)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Your Revenue:</span>
              <span className="font-semibold text-blue-600">{formatCurrency(year1.distributorRevenue)}</span>
            </div>
            <div className="border-t pt-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Marketing Costs:</span>
                <span className="font-semibold">{formatCurrency(year1.marketingCosts)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Net Profit:</span>
                <span className="font-semibold text-green-600">{formatCurrency(year1.netProfit)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">ROI:</span>
                <span className="font-semibold">{year1.roi}%</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Year 3 */}
        <div className="bg-green-50 p-6 rounded-lg border">
          <h3 className="font-semibold text-green-800 text-lg mb-4">Year 3</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Total Patients:</span>
              <span className="font-semibold">{formatNumber(year3.patients)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Gross Revenue:</span>
              <span className="font-semibold">{formatCurrency(year3.grossBillings)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Your Revenue:</span>
              <span className="font-semibold text-green-600">{formatCurrency(year3.distributorRevenue)}</span>
            </div>
            <div className="border-t pt-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Marketing Costs:</span>
                <span className="font-semibold">{formatCurrency(year3.marketingCosts)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Net Profit:</span>
                <span className="font-semibold text-green-600">{formatCurrency(year3.netProfit)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">ROI:</span>
                <span className="font-semibold">{year3.roi}%</span>
              </div>
            </div>
            <div className="mt-3 pt-2 border-t">
              <div className="text-xs text-gray-500">
                Growth vs Year 1: {((year3.patients / year1.patients - 1) * 100).toFixed(0)}%
              </div>
            </div>
          </div>
        </div>
        
        {/* Year 5 */}
        <div className="bg-purple-50 p-6 rounded-lg border">
          <h3 className="font-semibold text-purple-800 text-lg mb-4">Year 5</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Total Patients:</span>
              <span className="font-semibold">{formatNumber(year5.patients)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Gross Revenue:</span>
              <span className="font-semibold">{formatCurrency(year5.grossBillings)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Your Revenue:</span>
              <span className="font-semibold text-purple-600">{formatCurrency(year5.distributorRevenue)}</span>
            </div>
            <div className="border-t pt-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Marketing Costs:</span>
                <span className="font-semibold">{formatCurrency(year5.marketingCosts)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Net Profit:</span>
                <span className="font-semibold text-green-600">{formatCurrency(year5.netProfit)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">ROI:</span>
                <span className="font-semibold">{year5.roi}%</span>
              </div>
            </div>
            <div className="mt-3 pt-2 border-t">
              <div className="text-xs text-gray-500">
                Growth vs Year 1: {((year5.patients / year1.patients - 1) * 100).toFixed(0)}%
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Growth Factors Display */}
      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <h4 className="font-semibold mb-3">Growth Assumptions</h4>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <h5 className="font-medium mb-2">Current Input Factors:</h5>
            <ul className="space-y-1 text-gray-600">
              <li>• Monthly growth rate: {state.monthlyGrowthRate}%</li>
              <li>• Annual CAC decline: {state.annualCacDecline}%</li>
              <li>• Max conversion multiplier: {state.maxConversionMultiplier}x</li>
              <li>• Current channel mix optimizations applied</li>
            </ul>
          </div>
          <div>
            <h5 className="font-medium mb-2">Clinical Factors Included:</h5>
            <ul className="space-y-1 text-gray-600">
              <li>• 60-70% patient recurrence rate</li>
              <li>• 12-13 month average treatment cycle</li>
              <li>• 2.5% US population market size</li>
              <li>• 16.4% Medicare beneficiary prevalence</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Data Flow Summary */}
      <div className="mt-4 p-3 bg-blue-100 rounded text-sm">
        <div className="font-medium text-blue-800 mb-1">Data Flow Complete</div>
        <div className="text-blue-700">
          These projections incorporate all changes from: Revenue Calculator ({formatCurrency(state.reimbursementPerCm)}/cm²) → 
          Marketing Channels ({formatNumber(state.digitalImpressions + state.oohImpressions)} impressions) → 
          Growth Strategy (optimizations applied) → 
          Mix Optimization (current {((state.digitalImpressions / (state.digitalImpressions + state.oohImpressions)) * 100).toFixed(0)}% digital) → 
          Final Projections
        </div>
      </div>
    </div>
  );
}

export function MixOptimization({ state, results, onUpdate }: ComponentProps) {
  // Calculate current mix percentages
  const totalImpressions = state.digitalImpressions + state.oohImpressions;
  const digitalPercentage = totalImpressions > 0 ? (state.digitalImpressions / totalImpressions) * 100 : 50;
  const oohPercentage = 100 - digitalPercentage;
  
  // Show flow-through impact
  const currentROI = results.blendedROI;
  const currentPatients = results.totalPatients;
  
  return (
    <div className="p-6 bg-white rounded-lg border">
      <div className="flex justify-between items-start mb-4">
        <h2 className="text-xl font-bold">Mix Optimization</h2>
        <div className="text-right text-xs text-gray-500">
          <div>Data flows from Revenue → Marketing → Growth → Here → Projections</div>
        </div>
      </div>
      
      {/* Current Mix Display */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold mb-2">Current Channel Mix</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-blue-600 font-medium">Digital: {digitalPercentage.toFixed(1)}%</span>
            <div className="text-xs text-gray-600">
              {formatNumber(state.digitalImpressions)} impressions
            </div>
          </div>
          <div>
            <span className="text-green-600 font-medium">OOH: {oohPercentage.toFixed(1)}%</span>
            <div className="text-xs text-gray-600">
              {formatNumber(state.oohImpressions)} impressions
            </div>
          </div>
        </div>
        <div className="mt-2 pt-2 border-t text-sm space-y-1">
          <div className="flex justify-between">
            <span>Current Performance:</span>
            <span className="font-medium">{formatNumber(currentPatients)} patients/mo • {formatPercentage(currentROI)} ROI</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm font-medium">Distributor Revenue:</span>
            <span className="font-mono font-bold text-green-600">{formatCurrency(results.totalDistributorRevenue)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm font-medium">Physician Revenue:</span>
            <span className="font-mono font-bold text-teal-600">{formatCurrency(results.doctorRevenue)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm font-medium">Mfr Revenue:</span>
            <span className="font-mono font-bold text-orange-600">{formatCurrency(results.manufacturerRevenue)}</span>
          </div>
        </div>
      </div>
      
      {/* Optimization Strategies */}
      <div className="space-y-4">
        <h3 className="font-semibold">Optimization Strategies</h3>
        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => {
              const totalSpend = state.digitalSpendOnImpressions + state.oohSpendOnImpressions;
              const digitalSpend = totalSpend * 0.8;
              const oohSpend = totalSpend * 0.2;
              onUpdate({ 
                digitalSpendOnImpressions: digitalSpend,
                oohSpendOnImpressions: oohSpend,
                digitalImpressions: Math.round((digitalSpend * 1000) / state.digitalCpm),
                oohImpressions: Math.round((oohSpend * 1000) / state.oohCpm)
              });
            }}
            className="p-4 border rounded hover:bg-blue-50 transition-colors"
          >
            <h4 className="font-semibold text-sm text-blue-700">Digital-Heavy</h4>
            <p className="text-xs text-gray-600 mb-2">80% Digital / 20% OOH</p>
            <div className="text-xs">
              <div>Best for: High CTR campaigns</div>
              <div>Expected boost: +15-25%</div>
            </div>
          </button>
          
          <button
            onClick={() => {
              const totalSpend = state.digitalSpendOnImpressions + state.oohSpendOnImpressions;
              const digitalSpend = totalSpend * 0.5;
              const oohSpend = totalSpend * 0.5;
              onUpdate({ 
                digitalSpendOnImpressions: digitalSpend,
                oohSpendOnImpressions: oohSpend,
                digitalImpressions: Math.round((digitalSpend * 1000) / state.digitalCpm),
                oohImpressions: Math.round((oohSpend * 1000) / state.oohCpm)
              });
            }}
            className="p-4 border rounded hover:bg-green-50 transition-colors"
          >
            <h4 className="font-semibold text-sm text-green-700">Balanced</h4>
            <p className="text-xs text-gray-600 mb-2">50% Digital / 50% OOH</p>
            <div className="text-xs">
              <div>Best for: Risk management</div>
              <div>Expected boost: +5-15%</div>
            </div>
          </button>
          
          <button
            onClick={() => {
              const totalSpend = state.digitalSpendOnImpressions + state.oohSpendOnImpressions;
              const digitalSpend = totalSpend * 0.2;
              const oohSpend = totalSpend * 0.8;
              onUpdate({ 
                digitalSpendOnImpressions: digitalSpend,
                oohSpendOnImpressions: oohSpend,
                digitalImpressions: Math.round((digitalSpend * 1000) / state.digitalCpm),
                oohImpressions: Math.round((oohSpend * 1000) / state.oohCpm)
              });
            }}
            className="p-4 border rounded hover:bg-orange-50 transition-colors"
          >
            <h4 className="font-semibold text-sm text-orange-700">OOH-Heavy</h4>
            <p className="text-xs text-gray-600 mb-2">20% Digital / 80% OOH</p>
            <div className="text-xs">
              <div>Best for: Brand awareness</div>
              <div>Expected boost: +10-20%</div>
            </div>
          </button>
        </div>
        
        {/* Smart Optimization */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-semibold text-blue-800 mb-2">Smart Optimization</h4>
          <p className="text-sm text-blue-700 mb-3">
            Based on your current performance, we recommend optimizing conversion rates and channel mix.
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => onUpdate({ 
                digitalLeadConv: Math.min(state.digitalLeadConv * 1.3, 5),
                digitalApptConv: Math.min(state.digitalApptConv * 1.2, 20),
                oohLeadConv: Math.min(state.oohLeadConv * 1.25, 15)
              })}
              className="px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors"
            >
              Apply 30% Conversion Boost
            </button>
            <button
              onClick={() => {
                // Apply the highest-performing mix based on current ROI
                if (results.digitalROI > results.oohROI) {
                  const totalSpend = state.digitalSpendOnImpressions + state.oohSpendOnImpressions;
                  onUpdate({ 
                    digitalSpendOnImpressions: totalSpend * 0.7,
                    oohSpendOnImpressions: totalSpend * 0.3,
                    digitalImpressions: Math.round((totalSpend * 0.7 * 1000) / state.digitalCpm),
                    oohImpressions: Math.round((totalSpend * 0.3 * 1000) / state.oohCpm)
                  });
                } else {
                  const totalSpend = state.digitalSpendOnImpressions + state.oohSpendOnImpressions;
                  onUpdate({ 
                    digitalSpendOnImpressions: totalSpend * 0.3,
                    oohSpendOnImpressions: totalSpend * 0.7,
                    digitalImpressions: Math.round((totalSpend * 0.3 * 1000) / state.digitalCpm),
                    oohImpressions: Math.round((totalSpend * 0.7 * 1000) / state.oohCpm)
                  });
                }
              }}
              className="px-4 py-2 bg-green-600 text-white rounded text-sm hover:bg-green-700 transition-colors"
            >
              Optimize Mix Automatically
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}