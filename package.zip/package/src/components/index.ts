// Export simplified UI components for the NPM package
export { 
  RevenueCalculator,
  MarketingChannels,
  OptimizationSuggestions,
  MultiYearProjections,
  MixOptimization,
  RevenueModelSelector
} from './SimpleComponents';