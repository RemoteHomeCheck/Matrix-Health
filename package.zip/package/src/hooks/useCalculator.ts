import { useState, useCallback } from "react";
import { CalculatorState } from "../types/schema";
import { calculateResults } from "../utils/calculations";

// Revenue models for solo practitioners with different funding structures
const REVENUE_MODELS = {
  physician_funded: {
    name: "Physician-Funded Model",
    description: "Solo practitioner pays $7,500/mo, distributor gets 15%",
    digitalImpressions: 450000, // $7,500 split across channels
    digitalSpendOnImpressions: 3758, // 450k × $8.35 CPM
    oohImpressions: 450000,
    oohSpendOnImpressions: 5400, // 450k × $12.00 CPM
    totalBudget: 7500,
    digitalAllocation: 41,
    distributorShare: 15,
    providerShare: 50,
    manufacturerShare: 35,
    digitalCtr: 1.2,
    oohResponse: 0.07,
    digitalLeadConv: 1.0,
    oohLeadConv: 8.5,
    digitalApptConv: 7.5,
    oohApptConv: 7.5,
    digitalPatientConv: 60,
    oohPatientConv: 55
  },
  group_collective: {
    name: "Group Collective Model", 
    description: "Solo practitioners pool together for $10,000/mo collective spend",
    digitalImpressions: 598000, // $10,000 split across channels
    digitalSpendOnImpressions: 4993, // 598k × $8.35 CPM
    oohImpressions: 598000,
    oohSpendOnImpressions: 7176, // 598k × $12.00 CPM
    totalBudget: 10000,
    digitalAllocation: 41,
    distributorShare: 15,
    providerShare: 50,
    manufacturerShare: 35,
    digitalCtr: 1.2,
    oohResponse: 0.07,
    digitalLeadConv: 1.0,
    oohLeadConv: 8.5,
    digitalApptConv: 7.5,
    oohApptConv: 7.5,
    digitalPatientConv: 60,
    oohPatientConv: 55
  },
  distributor_funded: {
    name: "Distributor-Funded Model",
    description: "Distributor pays all marketing, physician pays $0, distributor gets 25%",
    digitalImpressions: 450000, // Same volume as physician-funded
    digitalSpendOnImpressions: 3758,
    oohImpressions: 450000,
    oohSpendOnImpressions: 5400,
    totalBudget: 7500,
    digitalAllocation: 41,
    distributorShare: 25, // Higher share for taking marketing risk
    providerShare: 40, // Reduced since they pay nothing
    manufacturerShare: 35,
    digitalCtr: 1.2,
    oohResponse: 0.07,
    digitalLeadConv: 1.0,
    oohLeadConv: 8.5,
    digitalApptConv: 7.5,
    oohApptConv: 7.5,
    digitalPatientConv: 60,
    oohPatientConv: 55
  }
};

// Default calculator state
const DEFAULT_STATE: CalculatorState = {
  currentModel: 'physician_funded',
  
  // Treatment Parameters (Based on clinical research: chronic wounds affect 30% of all wounds)
  treatmentLength: 4,
  treatmentWidth: 4,
  treatmentDuration: 20, // weeks - reflects 12-13 month average management duration
  reimbursementPerCm: 2500, // CMS rate per cm²
  includeFollowUp: true,
  
  // Revenue Shares (must sum to 100%)
  distributorShare: 15, // Your distributor share
  providerShare: 50, // Healthcare provider share
  manufacturerShare: 35, // Manufacturer share
  
  // Digital Marketing Parameters (Targeting chronic wound population: 2.5% US population, 16.4% Medicare beneficiaries)
  digitalImpressions: 300000, // $2,500 ÷ $8.35 CPM = ~300k impressions
  digitalCtr: 1.2, // Market benchmark: 0.8-1.5% for healthcare digital
  digitalLeadConv: 1.0, // Conservative: chronic wound patients are highly motivated
  digitalApptConv: 7.5, // Higher conversion for chronic conditions requiring ongoing care
  digitalPatientConv: 60, // Qualified chronic wound patients: 50-70% suitable for dermal grafts
  digitalCpm: 8.35, // Digital marketing CPM (adjustable)
  
  // OOH Marketing Parameters
  oohImpressions: 250000, // $3,000 ÷ $12 CPM = 250k impressions
  oohResponse: 0.07, // Market benchmark: 0.04-0.1% for health-targeted OOH
  oohLeadConv: 8.5, // Higher conversion rate from OOH responses
  oohApptConv: 7.5, // Same appointment rate as digital
  oohPatientConv: 55, // Slightly lower due to less pre-qualification
  oohCpm: 12.00, // OOH marketing CPM (adjustable)
  
  // Calculated spend fields (these get updated dynamically)
  digitalSpendOnImpressions: 2505, // 300k ÷ 1000 × $8.35
  oohSpendOnImpressions: 3000, // 250k ÷ 1000 × $12.00
  
  // Multi-year Growth Parameters
  monthlyGrowthRate: 5, // 5% monthly growth default
  maxConversionMultiplier: 3, // Maximum 3x improvement over baseline
  annualCacDecline: 12 // 12% annual decline in customer acquisition cost
};

export function useCalculator(initialState?: Partial<CalculatorState>) {
  const [state, setState] = useState<CalculatorState>(() => ({
    ...DEFAULT_STATE,
    ...initialState
  }));
  
  const results = calculateResults(state);
  
  const updateState = useCallback((updates: Partial<CalculatorState>) => {
    setState(current => ({ ...current, ...updates }));
  }, []);
  
  const resetToDefaults = useCallback(() => {
    setState(DEFAULT_STATE);
  }, []);
  
  const applyRevenueModel = useCallback((modelKey: keyof typeof REVENUE_MODELS) => {
    const model = REVENUE_MODELS[modelKey];
    if (!model) return;
    
    setState(current => ({
      ...current,
      currentModel: modelKey,
      digitalImpressions: model.digitalImpressions,
      digitalSpendOnImpressions: model.digitalSpendOnImpressions,
      oohImpressions: model.oohImpressions,
      oohSpendOnImpressions: model.oohSpendOnImpressions,
      distributorShare: model.distributorShare,
      providerShare: model.providerShare,
      manufacturerShare: model.manufacturerShare,
      digitalCtr: model.digitalCtr,
      oohResponse: model.oohResponse,
      digitalLeadConv: model.digitalLeadConv,
      oohLeadConv: model.oohLeadConv,
      digitalApptConv: model.digitalApptConv,
      oohApptConv: model.oohApptConv,
      digitalPatientConv: model.digitalPatientConv,
      oohPatientConv: model.oohPatientConv
    }));
  }, []);
  
  return {
    state,
    results,
    updateState,
    resetToDefaults,
    applyRevenueModel,
    revenueModels: REVENUE_MODELS
  };
}