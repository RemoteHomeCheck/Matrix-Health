// Main calculator component export
export { MatrixHealthCalculator } from './MatrixHealthCalculator';

// Hook exports for advanced usage
export { useCalculator } from './hooks/useCalculator';

// Type exports for TypeScript users
export type {
  CalculatorState,
  CalculatorResults,
  RevenueModel,
  MarketingChannel,
  ProjectionData
} from './types/schema';

// Utility exports
export {
  calculateResults,
  formatCurrency,
  formatNumber,
  formatPercentage,
  formatLargeNumber,
  formatROI,
  formatPaybackPeriod
} from './utils/calculations';

export { CALCULATION_CONSTANTS } from './utils/constants';

export { exportToCSV } from './utils/csvExport';

// Clinical research data exports
export { 
  CLINICAL_RESEARCH_DATA, 
  CLINICAL_CONTEXT,
  calculateChronicWoundPopulation,
  calculateMedicareCronicWounds,
  getAverageManagementDuration,
  getRecurrenceAdjustedPatients
} from './utils/clinicalData';

// Component exports for custom implementation
export { PracticeScenarios } from './components/PracticeScenarios';