// Core calculator state interface
// Based on clinical research: 30% of wounds are chronic (Las Heras 2020)
// Chronic wounds affect 2.5% of US population, 16.4% of Medicare beneficiaries
export interface CalculatorState {
  // Revenue Model
  currentModel: 'physician_funded' | 'group_collective' | 'distributor_funded';
  
  // Treatment Parameters (Chronic wound management: avg 12-13 months)
  treatmentLength: number;
  treatmentWidth: number;
  treatmentDuration: number; // weeks of active management (12-13 months typical)
  reimbursementPerCm: number; // CMS reimbursement rate
  includeFollowUp: boolean; // Include long-term wound management
  
  // Revenue Shares (must sum to 100%)
  distributorShare: number;
  providerShare: number;
  manufacturerShare: number;
  
  // Digital Marketing Parameters
  digitalImpressions: number;
  digitalCtr: number;
  digitalLeadConv: number;
  digitalApptConv: number;
  digitalPatientConv: number;
  digitalCpm: number;
  digitalSpendOnImpressions: number;
  
  // OOH Marketing Parameters
  oohImpressions: number;
  oohResponse: number;
  oohLeadConv: number;
  oohApptConv: number;
  oohPatientConv: number;
  oohCpm: number;
  oohSpendOnImpressions: number;
  
  // Multi-year Growth Parameters
  monthlyGrowthRate: number;
  maxConversionMultiplier: number;
  annualCacDecline: number;
}

// Calculator results interface
export interface CalculatorResults {
  // Treatment financials
  treatmentArea: number;
  treatmentValue: number;
  followUpRevenue: number;
  patientRevenue: number;
  grossRevenue: number;
  
  // Revenue distribution
  distributorRevenue: number;
  doctorRevenue: number;
  manufacturerRevenue: number;
  
  // Digital channel results
  digitalClicks: number;
  digitalLeads: number;
  digitalAppointments: number;
  digitalPatients: number;
  digitalChannelRevenue: number;
  digitalCostPerPatient: number;
  digitalROI: number;
  digitalEffectiveCPM: number;
  digitalPaybackMonths: number;
  
  // OOH channel results
  oohResponses: number;
  oohLeads: number;
  oohAppointments: number;
  oohPatients: number;
  oohChannelRevenue: number;
  oohCostPerPatient: number;
  oohROI: number;
  oohEffectiveCPM: number;
  oohPaybackMonths: number;
  
  // Combined results
  totalPatients: number;
  totalMonthlyRevenue: number;
  totalDistributorRevenue: number;
  blendedROI: number;
  blendedPaybackMonths: number;
  
  // Multi-year projections
  projections: {
    year1: ProjectionData;
    year3: ProjectionData;
    year5: ProjectionData;
  };
}

// Multi-year projection data
export interface ProjectionData {
  patients: number;
  grossBillings: number;
  distributorRevenue: number;
  marketingCosts: number;
  netProfit: number;
  roi: number;
  costPerPatient: number;
}

// Revenue model configuration
export interface RevenueModel {
  name: string;
  description: string;
  digitalImpressions: number;
  digitalSpendOnImpressions: number;
  oohImpressions: number;
  oohSpendOnImpressions: number;
  totalBudget: number;
  digitalAllocation: number;
  distributorShare: number;
  providerShare: number;
  manufacturerShare: number;
  digitalCtr: number;
  oohResponse: number;
  digitalLeadConv: number;
  oohLeadConv: number;
  digitalApptConv: number;
  oohApptConv: number;
  digitalPatientConv: number;
  oohPatientConv: number;
}

// Marketing channel data
export interface MarketingChannel {
  name: string;
  impressions: number;
  spend: number;
  cpm: number;
  patients: number;
  revenue: number;
  roi: number;
  costPerPatient: number;
}