import { CalculatorState, CalculatorResults } from "../types/schema";
import { CALCULATION_CONSTANTS } from "./constants";

export const calculateResults = (state: CalculatorState): CalculatorResults => {
  // 1. Revenue Split Validation - must sum to 100%
  const pctSum = state.distributorShare + state.providerShare + state.manufacturerShare;
  if (Math.abs(pctSum - 100) > CALCULATION_CONSTANTS.REVENUE_SPLIT_TOLERANCE) {
    throw new Error(`Revenue shares must add to 100% (currently ${pctSum.toFixed(1)}%)`);
  }

  // Treatment Value Calculations with Clinical Research Integration
  // Based on Las Heras (2020): 30% of wounds are chronic, affecting 2.5% of US population
  // Average treatment duration: 12-13 months for chronic lower extremity ulcers
  const treatmentArea = state.treatmentLength * state.treatmentWidth;
  const treatmentValue = treatmentArea * state.reimbursementPerCm; // One-time graft payment
  const followUpDressingFee = CALCULATION_CONSTANTS.FOLLOW_UP_DRESSING_FEE;
  
  // Clinical reality: Average 12-13 months active management with 60-70% recurrence rate
  // Treatment duration reflects real-world chronic wound management patterns
  const followUpWeeks = Math.max(0, Math.min(state.treatmentDuration - 1, CALCULATION_CONSTANTS.MAX_FOLLOW_UP_WEEKS));
  const followUpRevenue = state.includeFollowUp ? followUpDressingFee * followUpWeeks : 0;
  const patientTreatmentReimbursement = treatmentValue + followUpRevenue; // Total per patient
  const grossRevenue = patientTreatmentReimbursement;
  
  // Revenue Shares
  const distributorRevenue = patientTreatmentReimbursement * (state.distributorShare / 100);
  const doctorRevenue = patientTreatmentReimbursement * (state.providerShare / 100);
  const manufacturerRevenue = patientTreatmentReimbursement * (state.manufacturerShare / 100);
  
  // FIXED: Verification that total split equals Patient Treatment Reimbursement
  const totalSplit = distributorRevenue + doctorRevenue + manufacturerRevenue;
  if (Math.abs(totalSplit - patientTreatmentReimbursement) > CALCULATION_CONSTANTS.CALCULATION_EPSILON) {
    throw new Error(`Revenue split calculation error: ${totalSplit.toFixed(2)} ≠ ${patientTreatmentReimbursement.toFixed(2)}`);
  }
  
  // Digital Channel Calculations
  const digitalClicks = state.digitalImpressions * (state.digitalCtr / 100);
  const digitalLeads = digitalClicks * (state.digitalLeadConv / 100);
  const digitalAppointments = digitalLeads * (state.digitalApptConv / 100);
  const digitalPatients = digitalAppointments * (state.digitalPatientConv / 100);
  const digitalChannelRevenue = digitalPatients * patientTreatmentReimbursement;
  
  // OOH Channel Calculations
  const oohResponses = state.oohImpressions * (state.oohResponse / 100);
  const oohLeads = oohResponses * (state.oohLeadConv / 100);
  const oohAppointments = oohLeads * (state.oohApptConv / 100);
  const oohPatients = oohAppointments * (state.oohPatientConv / 100);
  const oohChannelRevenue = oohPatients * patientTreatmentReimbursement;
  
  // Combined Results
  const totalPatients = digitalPatients + oohPatients;
  const totalMonthlyRevenue = digitalChannelRevenue + oohChannelRevenue;
  const totalDistributorRevenue = totalMonthlyRevenue * (state.distributorShare / 100);
  
  // Cost Analysis (using actual spend on impressions)
  const digitalCost = state.digitalSpendOnImpressions;
  const oohCost = state.oohSpendOnImpressions;
  
  // Calculate effective CPM rates from spend
  const digitalEffectiveCPM = (digitalCost / (state.digitalImpressions / 1000));
  const oohEffectiveCPM = (oohCost / (state.oohImpressions / 1000));
  
  const digitalCostPerPatient = digitalPatients > 0 ? digitalCost / digitalPatients : 0;
  const oohCostPerPatient = oohPatients > 0 ? oohCost / oohPatients : 0;
  
  // ROI calculations with divide-by-zero protection
  const digitalROI = digitalCost > 0 ? ((digitalChannelRevenue - digitalCost) / digitalCost) * 100 : 0;
  const oohROI = oohCost > 0 ? ((oohChannelRevenue - oohCost) / oohCost) * 100 : 0;
  const blendedROI = (digitalCost + oohCost) > 0 ? ((totalMonthlyRevenue - digitalCost - oohCost) / (digitalCost + oohCost)) * 100 : 0;
  
  // Payback period calculation (months to break-even)
  const digitalPaybackMonths = digitalCost > 0 && digitalChannelRevenue > digitalCost ? 
    digitalCost / (digitalChannelRevenue - digitalCost) : Infinity;
  const oohPaybackMonths = oohCost > 0 && oohChannelRevenue > oohCost ? 
    oohCost / (oohChannelRevenue - oohCost) : Infinity;
  const blendedPaybackMonths = (digitalCost + oohCost) > 0 && totalMonthlyRevenue > (digitalCost + oohCost) ? 
    (digitalCost + oohCost) / (totalMonthlyRevenue - digitalCost - oohCost) : Infinity;
  
  // Multi-Year Projections with Optimization
  const baseMonthlyPatients = totalPatients;
  let cumulativeYear1Patients = 0;
  let cumulativeYear3Patients = 0;
  let cumulativeYear5Patients = 0;
  
  // Year 1 Projections (months 1-12)
  for (let month = 1; month <= 12; month++) {
    const growthFactor = Math.pow(1 + state.monthlyGrowthRate / 100, month - 1);
    const conversionImprovement = Math.min(1 + (month / 12) * 0.5, state.maxConversionMultiplier); // 50% improvement by year end, capped
    const monthlyPatients = baseMonthlyPatients * growthFactor * conversionImprovement;
    cumulativeYear1Patients += monthlyPatients;
  }
  
  // Year 3 Projections (cumulative through month 36)
  for (let month = 1; month <= 36; month++) {
    const growthFactor = Math.pow(1 + state.monthlyGrowthRate / 100, month - 1);
    const conversionImprovement = Math.min(1 + (month / 36) * 2.0, state.maxConversionMultiplier); // 200% improvement by year 3, capped
    const monthlyPatients = baseMonthlyPatients * growthFactor * conversionImprovement;
    cumulativeYear3Patients += monthlyPatients;
  }
  
  // Year 5 Projections (cumulative through month 60)
  for (let month = 1; month <= 60; month++) {
    const growthFactor = Math.pow(1 + state.monthlyGrowthRate / 100, month - 1);
    const conversionImprovement = Math.min(1 + (month / 60) * 2.5, state.maxConversionMultiplier); // 250% improvement by year 5, capped at max
    const monthlyPatients = baseMonthlyPatients * growthFactor * conversionImprovement;
    cumulativeYear5Patients += monthlyPatients;
  }
  
  // Calculate costs with annual decline in CAC
  const baseCostPerPatient = totalPatients > 0 ? (digitalCost + oohCost) / totalPatients : 0;
  const year1CostPerPatient = baseCostPerPatient;
  const year3CostPerPatient = baseCostPerPatient * Math.pow(1 - state.annualCacDecline / 100, 3);
  const year5CostPerPatient = baseCostPerPatient * Math.pow(1 - state.annualCacDecline / 100, 5);
  
  return {
    // Treatment financials
    treatmentArea,
    treatmentValue,
    followUpRevenue,
    patientRevenue,
    grossRevenue,
    
    // Revenue distribution
    distributorRevenue,
    doctorRevenue,
    manufacturerRevenue,
    
    // Digital channel results
    digitalClicks,
    digitalLeads,
    digitalAppointments,
    digitalPatients,
    digitalChannelRevenue,
    digitalCostPerPatient,
    digitalROI,
    digitalEffectiveCPM,
    digitalPaybackMonths,
    
    // OOH channel results
    oohResponses,
    oohLeads,
    oohAppointments,
    oohPatients,
    oohChannelRevenue,
    oohCostPerPatient,
    oohROI,
    oohEffectiveCPM,
    oohPaybackMonths,
    
    // Combined results
    totalPatients,
    totalMonthlyRevenue,
    totalDistributorRevenue,
    blendedROI,
    blendedPaybackMonths,
    
    // Multi-year projections
    projections: {
      year1: {
        patients: Math.round(cumulativeYear1Patients),
        grossBillings: Math.round(cumulativeYear1Patients * patientRevenue),
        distributorRevenue: Math.round(cumulativeYear1Patients * distributorRevenue),
        marketingCosts: Math.round(cumulativeYear1Patients * year1CostPerPatient),
        netProfit: Math.round(cumulativeYear1Patients * (distributorRevenue - year1CostPerPatient)),
        roi: year1CostPerPatient > 0 ? Math.round(((distributorRevenue - year1CostPerPatient) / year1CostPerPatient) * 100) : 0,
        costPerPatient: Math.round(year1CostPerPatient)
      },
      year3: {
        patients: Math.round(cumulativeYear3Patients),
        grossBillings: Math.round(cumulativeYear3Patients * patientRevenue),
        distributorRevenue: Math.round(cumulativeYear3Patients * distributorRevenue),
        marketingCosts: Math.round(cumulativeYear3Patients * year3CostPerPatient),
        netProfit: Math.round(cumulativeYear3Patients * (distributorRevenue - year3CostPerPatient)),
        roi: year3CostPerPatient > 0 ? Math.round(((distributorRevenue - year3CostPerPatient) / year3CostPerPatient) * 100) : 0,
        costPerPatient: Math.round(year3CostPerPatient)
      },
      year5: {
        patients: Math.round(cumulativeYear5Patients),
        grossBillings: Math.round(cumulativeYear5Patients * patientRevenue),
        distributorRevenue: Math.round(cumulativeYear5Patients * distributorRevenue),
        marketingCosts: Math.round(cumulativeYear5Patients * year5CostPerPatient),
        netProfit: Math.round(cumulativeYear5Patients * (distributorRevenue - year5CostPerPatient)),
        roi: year5CostPerPatient > 0 ? Math.round(((distributorRevenue - year5CostPerPatient) / year5CostPerPatient) * 100) : 0,
        costPerPatient: Math.round(year5CostPerPatient)
      }
    }
  };
};

// Enhanced formatting functions with null handling for UI compatibility
export const formatCurrency = (amount: number | null): string => {
  if (amount === null || !isFinite(amount)) return "N/A";
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatNumber = (num: number | null): string => {
  if (num === null || !isFinite(num)) return "N/A";
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 1,
  }).format(num);
};

export const formatPercentage = (num: number | null): string => {
  if (num === null || !isFinite(num)) return "N/A";
  return `${num.toFixed(1)}%`;
};

export const formatLargeNumber = (num: number | null): string => {
  if (num === null || !isFinite(num)) return "N/A";
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  } else if (num >= 1000) {
    return `${(num / 1000).toFixed(0)}K`;
  }
  return num.toString();
};

export const formatROI = (roi: number | null): string => {
  if (roi === null || !isFinite(roi)) return "N/A";
  if (roi === 0) return "0% (0×)";
  const percentage = `${roi.toFixed(1)}%`;
  const multiple = `${(roi / 100 + 1).toFixed(1)}×`;
  return `${percentage} (${multiple})`;
};

export const formatPaybackPeriod = (months: number | null): string => {
  if (months === null || !isFinite(months)) return "Never";
  if (months === 0) return "Immediate";
  if (months < 1) return "< 1 month";
  if (months > 120) return "Never"; // > 10 years considered never
  return `${months.toFixed(1)} months`;
};