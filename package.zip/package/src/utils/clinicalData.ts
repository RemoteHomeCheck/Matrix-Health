// Clinical Research Data Integration
// Based on Las Heras (2020) and recent wound management studies

export const CLINICAL_RESEARCH_DATA = {
  // Wound prevalence data
  woundPrevalence: {
    chronicWoundPercentage: 30, // 30% of all wounds are chronic
    acuteWoundsPer1000: 10.55,
    chronicWoundsPer1000: 4.48,
    totalUSPopulationAffected: 2.5, // 2.5% of US population has chronic wounds
    medicarePopulationAffected: 16.4 // 16.4% of Medicare beneficiaries have chronic wounds
  },

  // Treatment duration data
  treatmentDuration: {
    averageManagementMonths: 12.5, // 12-13 months average
    averageManagementWeeks: 54, // ~12.5 months in weeks
    recurrenceRate: 65, // 60-70% recurrence rate
    chronicDefinitionWeeks: 12 // Wound considered chronic if not healing after 12 weeks
  },

  // Healing rates by wound type
  healingRates: {
    venousUlcers: {
      success24Weeks: 45, // 30-60% range, using middle
      success1Year: 77.5, // 70-85% range, using middle
      acuteHealingRate: 75.5, // 71-80% range for acute ulcers
      chronicHealingRate: 22 // 22% for chronic ulcers after 6 months
    },
    diabeticFootUlcers: {
      standardAssessmentWeeks: 12,
      optimalCareWeeks: 6, // 4-6 weeks before considering adjunctive treatments
      typicalManagementMonths: 4.5 // 3-6 months range, using middle
    },
    pressureUlcers: {
      criticalCarePrevalence: 22, // 22% of critical care patients
      variableHealingMonths: 6 // Highly variable, using conservative estimate
    }
  },

  // Population targeting data
  targetPopulation: {
    totalUSPopulation: 331000000, // Approximate current US population
    chronicWoundPatients: 8275000, // 2.5% of US population
    medicareEligible: 65000000, // Approximate Medicare population
    medicareChronicWounds: 10660000 // 16.4% of Medicare beneficiaries
  },

  // Treatment economics
  economics: {
    disproportionateResourceConsumption: true, // Chronic wounds consume disproportionate resources
    longTermCareModel: true, // Management is long-term relationship, not discrete episode
    maintenanceCareRequired: true,
    preventionStrategiesNeeded: true
  }
};

// Helper functions for clinical calculations
export const calculateChronicWoundPopulation = (totalPopulation: number) => {
  return totalPopulation * (CLINICAL_RESEARCH_DATA.woundPrevalence.totalUSPopulationAffected / 100);
};

export const calculateMedicareCronicWounds = (medicarePopulation: number) => {
  return medicarePopulation * (CLINICAL_RESEARCH_DATA.woundPrevalence.medicarePopulationAffected / 100);
};

export const getAverageManagementDuration = () => {
  return CLINICAL_RESEARCH_DATA.treatmentDuration.averageManagementWeeks;
};

export const getRecurrenceAdjustedPatients = (basePatients: number) => {
  // Account for 60-70% recurrence rate in long-term projections
  const recurrenceRate = CLINICAL_RESEARCH_DATA.treatmentDuration.recurrenceRate / 100;
  return basePatients * (1 + recurrenceRate * 0.5); // Conservative recurrence impact
};

// Clinical context for UI display
export const CLINICAL_CONTEXT = {
  woundTypes: [
    'Diabetic foot ulcers',
    'Venous leg ulcers', 
    'Pressure ulcers',
    'Arterial ulcers'
  ],
  keyFactors: [
    'Aging population increasing prevalence',
    'Rising diabetes rates',
    'Obesity epidemic impact',
    'Complex, long-term treatment requirements'
  ],
  clinicalMilestones: [
    '4-12 weeks: Chronic wound determination',
    '4-6 weeks: Adjunctive treatment consideration',
    '12-13 months: Average active management period',
    '60-70%: Recurrence rate requiring ongoing care'
  ]
};