// Constants for Matrix Health Calculator NPM Package
// Centralizes configuration values that marketing and growth teams can adjust

export const CALCULATION_CONSTANTS = {
  // Revenue Configuration
  FOLLOW_UP_DRESSING_FEE: 500, // Weekly dressing fee in dollars
  MAX_FOLLOW_UP_WEEKS: 12, // Maximum reasonable follow-up duration
  
  // Market Saturation Caps
  MAX_MONTHLY_PATIENT_MULTIPLIER: 10, // Maximum 10x base monthly patients
  DIGITAL_MARKET_CAP_PERCENTAGE: 80, // Max % of addressable market for digital
  OOH_MARKET_CAP_PERCENTAGE: 60, // Max % of addressable market for OOH
  
  // Validation Tolerances
  REVENUE_SPLIT_TOLERANCE: 0.01, // Allow ±0.01% in revenue split validation
  CALCULATION_EPSILON: 0.01, // General floating-point tolerance
  
  // Growth Rate Limits
  MAX_ANNUAL_GROWTH_RATE: 300, // 300% max annual growth
  MIN_GROWTH_RATE: -50, // -50% minimum (market contraction)
  
  // Conversion Rate Bounds
  MAX_CTR: 5.0, // 5% maximum click-through rate
  MAX_CONVERSION_RATE: 50.0, // 50% maximum conversion rate
  MIN_CONVERSION_RATE: 0.01, // 0.01% minimum conversion rate
} as const;

export type CalculationConstants = typeof CALCULATION_CONSTANTS;