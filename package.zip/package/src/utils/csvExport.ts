import { CalculatorState, CalculatorResults } from "../types/schema";

export function exportToCSV(state: CalculatorState, results: CalculatorResults, filename: string = 'matrix-health-calculator.csv'): void {
  const csvContent = generateCSVContent(state, results);
  downloadCSV(csvContent, filename);
}

function generateCSVContent(state: CalculatorState, results: CalculatorResults): string {
  const rows: string[][] = [
    ['Matrix Health Calculator - Export'],
    ['Generated:', new Date().toLocaleString()],
    [''],
    
    // Treatment Parameters
    ['TREATMENT PARAMETERS'],
    ['Treatment Length (cm)', state.treatmentLength.toString()],
    ['Treatment Width (cm)', state.treatmentWidth.toString()],
    ['Treatment Area (cm²)', results.treatmentArea.toString()],
    ['Treatment Duration (weeks)', state.treatmentDuration.toString()],
    ['CMS Reimbursement ($/cm²)', state.reimbursementPerCm.toString()],
    ['Include Follow-up Care', state.includeFollowUp ? 'Yes' : 'No'],
    [''],
    
    // Revenue Model
    ['REVENUE MODEL'],
    ['Model Type', state.currentModel.replace('_', ' ').toUpperCase()],
    ['Distributor Share (%)', state.distributorShare.toString()],
    ['Provider Share (%)', state.providerShare.toString()],
    ['Manufacturer Share (%)', state.manufacturerShare.toString()],
    [''],
    
    // Financial Results
    ['FINANCIAL RESULTS'],
    ['Treatment Value', results.treatmentValue.toString()],
    ['Follow-up Revenue', results.followUpRevenue.toString()],
    ['Total Patient Revenue', results.patientRevenue.toString()],
    ['Distributor Revenue per Patient', results.distributorRevenue.toString()],
    ['Provider Revenue per Patient', results.doctorRevenue.toString()],
    ['Manufacturer Revenue per Patient', results.manufacturerRevenue.toString()],
    [''],
    
    // Digital Marketing
    ['DIGITAL MARKETING'],
    ['Digital Impressions', state.digitalImpressions.toString()],
    ['Digital CPM', state.digitalCpm.toString()],
    ['Digital Spend', state.digitalSpendOnImpressions.toString()],
    ['Click-Through Rate (%)', state.digitalCtr.toString()],
    ['Lead Conversion Rate (%)', state.digitalLeadConv.toString()],
    ['Appointment Conversion (%)', state.digitalApptConv.toString()],
    ['Patient Conversion (%)', state.digitalPatientConv.toString()],
    ['Digital Clicks', results.digitalClicks.toString()],
    ['Digital Leads', results.digitalLeads.toString()],
    ['Digital Appointments', results.digitalAppointments.toString()],
    ['Digital Patients', results.digitalPatients.toString()],
    ['Digital Channel Revenue', results.digitalChannelRevenue.toString()],
    ['Digital Cost per Patient', results.digitalCostPerPatient.toString()],
    ['Digital ROI (%)', results.digitalROI.toString()],
    ['Digital Payback (months)', results.digitalPaybackMonths === Infinity ? 'N/A' : results.digitalPaybackMonths.toString()],
    [''],
    
    // OOH Marketing
    ['OUT-OF-HOME MARKETING'],
    ['OOH Impressions', state.oohImpressions.toString()],
    ['OOH CPM', state.oohCpm.toString()],
    ['OOH Spend', state.oohSpendOnImpressions.toString()],
    ['OOH Response Rate (%)', state.oohResponse.toString()],
    ['OOH Lead Conversion Rate (%)', state.oohLeadConv.toString()],
    ['OOH Appointment Conversion (%)', state.oohApptConv.toString()],
    ['OOH Patient Conversion (%)', state.oohPatientConv.toString()],
    ['OOH Responses', results.oohResponses.toString()],
    ['OOH Leads', results.oohLeads.toString()],
    ['OOH Appointments', results.oohAppointments.toString()],
    ['OOH Patients', results.oohPatients.toString()],
    ['OOH Channel Revenue', results.oohChannelRevenue.toString()],
    ['OOH Cost per Patient', results.oohCostPerPatient.toString()],
    ['OOH ROI (%)', results.oohROI.toString()],
    ['OOH Payback (months)', results.oohPaybackMonths === Infinity ? 'N/A' : results.oohPaybackMonths.toString()],
    [''],
    
    // Combined Results
    ['COMBINED RESULTS'],
    ['Total Monthly Patients', results.totalPatients.toString()],
    ['Total Monthly Revenue', results.totalMonthlyRevenue.toString()],
    ['Total Distributor Revenue', results.totalDistributorRevenue.toString()],
    ['Blended ROI (%)', results.blendedROI.toString()],
    ['Blended Payback (months)', results.blendedPaybackMonths === Infinity ? 'N/A' : results.blendedPaybackMonths.toString()],
    [''],
    
    // Multi-Year Projections
    ['MULTI-YEAR PROJECTIONS'],
    ['Growth Parameters'],
    ['Monthly Growth Rate (%)', state.monthlyGrowthRate.toString()],
    ['Max Conversion Multiplier', state.maxConversionMultiplier.toString()],
    ['Annual CAC Decline (%)', state.annualCacDecline.toString()],
    [''],
    
    ['Year 1 Projections'],
    ['Patients', results.projections.year1.patients.toString()],
    ['Gross Billings', results.projections.year1.grossBillings.toString()],
    ['Distributor Revenue', results.projections.year1.distributorRevenue.toString()],
    ['Marketing Costs', results.projections.year1.marketingCosts.toString()],
    ['Net Profit', results.projections.year1.netProfit.toString()],
    ['ROI (%)', results.projections.year1.roi.toString()],
    ['Cost per Patient', results.projections.year1.costPerPatient.toString()],
    [''],
    
    ['Year 3 Projections'],
    ['Patients', results.projections.year3.patients.toString()],
    ['Gross Billings', results.projections.year3.grossBillings.toString()],
    ['Distributor Revenue', results.projections.year3.distributorRevenue.toString()],
    ['Marketing Costs', results.projections.year3.marketingCosts.toString()],
    ['Net Profit', results.projections.year3.netProfit.toString()],
    ['ROI (%)', results.projections.year3.roi.toString()],
    ['Cost per Patient', results.projections.year3.costPerPatient.toString()],
    [''],
    
    ['Year 5 Projections'],
    ['Patients', results.projections.year5.patients.toString()],
    ['Gross Billings', results.projections.year5.grossBillings.toString()],
    ['Distributor Revenue', results.projections.year5.distributorRevenue.toString()],
    ['Marketing Costs', results.projections.year5.marketingCosts.toString()],
    ['Net Profit', results.projections.year5.netProfit.toString()],
    ['ROI (%)', results.projections.year5.roi.toString()],
    ['Cost per Patient', results.projections.year5.costPerPatient.toString()],
  ];

  return rows.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
}

function downloadCSV(csvContent: string, filename: string): void {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}