// Mathematical utility functions for the Matrix Health Calculator NPM Package

/**
 * Calculates the sum of a geometric series
 * @param firstTerm - The first term of the series
 * @param ratio - The common ratio between terms
 * @param numTerms - The number of terms to sum
 * @returns The sum of the geometric series
 */
export function sumGeometric(firstTerm: number, ratio: number, numTerms: number): number {
  if (numTerms === 0) return 0;
  if (ratio === 1) return firstTerm * numTerms;
  if (Math.abs(ratio) >= 1) {
    // For ratio >= 1, calculate term by term to avoid numerical issues
    let sum = 0;
    let currentTerm = firstTerm;
    for (let i = 0; i < numTerms; i++) {
      sum += currentTerm;
      currentTerm *= ratio;
    }
    return sum;
  }
  
  // Standard geometric series formula: a(1-r^n)/(1-r)
  return firstTerm * (1 - Math.pow(ratio, numTerms)) / (1 - ratio);
}

/**
 * Safely divides two numbers, returning null for division by zero
 * @param numerator - The numerator
 * @param denominator - The denominator
 * @returns The quotient or null if denominator is zero
 */
export function safeDivide(numerator: number, denominator: number): number | null {
  if (denominator === 0) return null;
  const result = numerator / denominator;
  return isFinite(result) ? result : null;
}

/**
 * Clamps a value between min and max bounds
 * @param value - The value to clamp
 * @param min - The minimum allowed value
 * @param max - The maximum allowed value
 * @returns The clamped value
 */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

/**
 * Converts annual growth rate to monthly growth rate using compound formula
 * @param annualRate - Annual growth rate as percentage (e.g., 60 for 60%)
 * @returns Monthly growth rate as percentage
 */
export function annualToMonthlyGrowthRate(annualRate: number): number {
  return (Math.pow(1 + annualRate / 100, 1/12) - 1) * 100;
}