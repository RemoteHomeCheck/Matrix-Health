import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { sendReportCompletionSMS, sendReportErrorSMS, testSMSConnection } from "./sms";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // SMS testing endpoint
  app.post('/api/sms/test', async (req, res) => {
    try {
      const { phoneNumber } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: 'Phone number is required' });
      }
      
      const success = await testSMSConnection(phoneNumber);
      
      if (success) {
        res.json({ message: 'Test SMS sent successfully' });
      } else {
        res.status(500).json({ message: 'Failed to send test SMS' });
      }
    } catch (error) {
      console.error('SMS test error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Report completion notification endpoint
  app.post('/api/reports/notify', async (req, res) => {
    try {
      const { phoneNumber, reportName, reportType, email } = req.body;
      
      if (!phoneNumber && !email) {
        return res.status(400).json({ message: 'Phone number or email is required' });
      }
      
      const results = [];
      
      if (phoneNumber) {
        const smsSuccess = await sendReportCompletionSMS(
          phoneNumber,
          reportName,
          reportType,
          new Date().toLocaleString()
        );
        results.push({ type: 'sms', success: smsSuccess });
      }
      
      // Email notification would be implemented here
      if (email) {
        // For now, just log that email would be sent
        console.log(`Email notification would be sent to: ${email}`);
        results.push({ type: 'email', success: true });
      }
      
      res.json({ 
        message: 'Notifications processed',
        results
      });
    } catch (error) {
      console.error('Notification error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Report error notification endpoint  
  app.post('/api/reports/error', async (req, res) => {
    try {
      const { phoneNumber, reportName, error } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: 'Phone number is required' });
      }
      
      const success = await sendReportErrorSMS(phoneNumber, reportName, error);
      
      if (success) {
        res.json({ message: 'Error notification sent successfully' });
      } else {
        res.status(500).json({ message: 'Failed to send error notification' });
      }
    } catch (error) {
      console.error('Error notification error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  // Calculator session endpoints
  app.get("/api/calculator/session/:id", async (req, res) => {
    try {
      const session = await storage.getCalculatorSession(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve session" });
    }
  });

  app.post("/api/calculator/session", async (req, res) => {
    try {
      const { sessionData } = req.body;
      if (!sessionData) {
        return res.status(400).json({ error: "Session data is required" });
      }
      
      const session = await storage.saveCalculatorSession({ sessionData });
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to save session" });
    }
  });

  app.put("/api/calculator/session/:id", async (req, res) => {
    try {
      const { sessionData } = req.body;
      if (!sessionData) {
        return res.status(400).json({ error: "Session data is required" });
      }
      
      const session = await storage.updateCalculatorSession(req.params.id, { sessionData });
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to update session" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      service: "Medicare Wound Care ROI Calculator"
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
