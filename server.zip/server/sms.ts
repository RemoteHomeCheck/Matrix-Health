import twilio from 'twilio';

// Initialize Twilio client
const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

export interface SMSConfig {
  to: string;
  message: string;
}

export async function sendSMS(config: SMSConfig): Promise<boolean> {
  try {
    if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE_NUMBER) {
      console.error('Twilio credentials not configured');
      return false;
    }

    const message = await client.messages.create({
      body: config.message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: config.to
    });

    console.log(`SMS sent successfully: ${message.sid}`);
    return true;
  } catch (error) {
    console.error('Failed to send SMS:', error);
    return false;
  }
}

export async function sendReportCompletionSMS(
  phoneNumber: string,
  reportName: string,
  reportType: string,
  generatedAt: string
): Promise<boolean> {
  const message = `Matrix Health Report Complete: ${reportName} (${reportType}) generated at ${generatedAt}. Check your email for the full report.`;
  
  return await sendSMS({
    to: phoneNumber,
    message
  });
}

export async function sendReportErrorSMS(
  phoneNumber: string,
  reportName: string,
  error: string
): Promise<boolean> {
  const message = `Matrix Health Report Error: ${reportName} failed to generate. Error: ${error}. Please check your settings.`;
  
  return await sendSMS({
    to: phoneNumber,
    message
  });
}

export async function testSMSConnection(phoneNumber: string): Promise<boolean> {
  const message = 'Matrix Health Calculator: SMS alerts are now configured and working correctly.';
  
  return await sendSMS({
    to: phoneNumber,
    message
  });
}