import { type CalculatorSession, type InsertCalculatorSession } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getCalculatorSession(id: string): Promise<CalculatorSession | undefined>;
  saveCalculatorSession(session: InsertCalculatorSession): Promise<CalculatorSession>;
  updateCalculatorSession(id: string, updates: Partial<InsertCalculatorSession>): Promise<CalculatorSession | undefined>;
}

export class MemStorage implements IStorage {
  private calculatorSessions: Map<string, CalculatorSession>;

  constructor() {
    this.calculatorSessions = new Map();
  }

  async getCalculatorSession(id: string): Promise<CalculatorSession | undefined> {
    return this.calculatorSessions.get(id);
  }

  async saveCalculatorSession(insertSession: InsertCalculatorSession): Promise<CalculatorSession> {
    const id = randomUUID();
    const now = new Date();
    const session: CalculatorSession = { 
      ...insertSession, 
      id,
      createdAt: now,
      updatedAt: now
    };
    this.calculatorSessions.set(id, session);
    return session;
  }

  async updateCalculatorSession(id: string, updates: Partial<InsertCalculatorSession>): Promise<CalculatorSession | undefined> {
    const existingSession = this.calculatorSessions.get(id);
    if (!existingSession) {
      return undefined;
    }

    const updatedSession: CalculatorSession = {
      ...existingSession,
      ...updates,
      updatedAt: new Date()
    };
    
    this.calculatorSessions.set(id, updatedSession);
    return updatedSession;
  }
}

export const storage = new MemStorage();
