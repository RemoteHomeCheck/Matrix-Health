import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const calculatorSessions = pgTable("calculator_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionData: text("session_data").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCalculatorSessionSchema = createInsertSchema(calculatorSessions).pick({
  sessionData: true,
});

export type InsertCalculatorSession = z.infer<typeof insertCalculatorSessionSchema>;
export type CalculatorSession = typeof calculatorSessions.$inferSelect;

// Real-time performance tracking schema
export interface MonthlyPerformanceData {
  id?: string;
  month: number; // 1-12
  year: number;
  
  // Actual performance metrics
  actualDigitalSpend: number;
  actualOohSpend: number;
  actualDigitalClicks: number;
  actualDigitalLeads: number;
  actualDigitalAppointments: number;
  actualDigitalPatients: number;
  actualOohResponses: number;
  actualOohLeads: number;
  actualOohAppointments: number;
  actualOohPatients: number;
  
  // Calculated actuals
  actualTotalPatients: number;
  actualRevenue: number;
  actualDigitalCAC: number | null;
  actualOohCAC: number | null;
  actualBlendedCAC: number | null;
  
  // Performance notes (optional)
  notes?: string;
  
  // Variance analysis (calculated fields)
  projectedPatients?: number;
  projectedRevenue?: number;
  patientsVariance?: number; // % difference from projection
  revenueVariance?: number; // % difference from projection
}

// Calculator data types
export interface CalculatorState {
  // Medicare Treatment Parameters
  reimbursementPerCm: number;
  treatmentLength: number;
  treatmentWidth: number;
  treatmentDuration: number;
  includeFollowUp: boolean; // Whether to include follow-up dressing fees
  
  // Revenue Share Parameters
  distributorShare: number;
  providerShare: number;
  manufacturerShare: number;
  

  
  // Digital Marketing Parameters
  digitalImpressions: number;
  digitalCtr: number;
  digitalLeadConv: number;
  digitalApptConv: number;
  digitalPatientConv: number;
  digitalCpm: number; // Cost per mille (CPM) for digital marketing
  
  // OOH Marketing Parameters
  oohImpressions: number;
  oohResponse: number;
  oohLeadConv: number;
  oohApptConv: number;
  oohPatientConv: number;
  oohCpm: number; // Cost per mille (CPM) for OOH marketing
  
  // Multi-Year Growth Assumptions
  growthYear1: number;
  growthYear23: number;
  growthYear45: number;
  
  // Optimization Over Time
  conversionOptimization: number; // Annual improvement in conversion rates
  cacImprovementRate: number; // Annual CAC improvement rate
  maxConversionCeiling: number; // Maximum conversion rate ceiling (prevents unrealistic projections)
  
  // Revenue Model Presets (all for solo practitioners)
  revenueModel: 'physician_funded' | 'group_collective' | 'distributor_funded' | 'custom';
  
  // Group Collective Parameters
  groupSize: number; // Number of doctors in the collective
  
  // Data Source Toggle (Ken's actual vs market benchmarks)
  useKenData: boolean;
  
  // Budget Optimization
  totalBudget: number;
  digitalAllocation: number;
  
  // Impression Spend Tracking
  digitalSpendOnImpressions: number;
  oohSpendOnImpressions: number;
  
  // Real-Time Performance Tracking
  enablePerformanceTracking: boolean;
  actualPerformanceData: MonthlyPerformanceData[];
}

export interface CalculatorResults {
  // Treatment Calculations
  treatmentValue: number;
  patientRevenue: number; // Total patient revenue (for compatibility)
  patientTreatmentReimbursement: number;
  distributorRevenue: number;
  grossRevenue: number;
  doctorRevenue: number;
  manufacturerRevenue: number;
  
  // Digital Channel Results
  digitalClicks: number;
  digitalLeads: number;
  digitalAppointments: number;
  digitalPatients: number;
  digitalChannelRevenue: number;
  
  // OOH Channel Results
  oohResponses: number;
  oohLeads: number;
  oohAppointments: number;
  oohPatients: number;
  oohChannelRevenue: number;
  
  // Combined Results
  totalPatients: number;
  totalMonthlyRevenue: number;
  totalDistributorRevenue: number;
  
  // Multi-Year Projections
  year1Revenue: number;
  year3Revenue: number;
  year5Revenue: number;
  year1Patients: number;
  year3Patients: number;
  year5Patients: number;
  
  // Cost Analysis - FIXED: Allow null for edge cases
  digitalCostPerPatient: number | null;
  oohCostPerPatient: number | null;
  digitalROI: number | null;
  oohROI: number | null;
  blendedROI: number | null;
  
  // Payback Period Analysis - Enhanced: Support break-even vs loss distinction
  // null = N/A (break-even), undefined = Never (loss), number = months
  digitalPaybackMonths: number | null | undefined;
  oohPaybackMonths: number | null | undefined;
  blendedPaybackMonths: number | null | undefined;
  
  // Effective CPM rates - NEW: Added to return object
  digitalEffectiveCPM: number | null;
  oohEffectiveCPM: number | null;
  
  // CAC Analysis - FIXED: Add missing CAC properties
  digitalCAC: number | null;
  oohCAC: number | null;
  blendedCAC: number | null;
  
  // Multi-year projection breakdown for UI
  projections?: {
    year1: {
      patients: number;
      grossBillings: number;
      distributorRevenue: number;
      netProfit: number;
      roi: number | null;
    };
    year3: {
      patients: number;
      grossBillings: number;
      distributorRevenue: number;
      netProfit: number;
      roi: number | null;
    };
    year5: {
      patients: number;
      grossBillings: number;
      distributorRevenue: number;
      netProfit: number;
      roi: number | null;
    };
  };
}
